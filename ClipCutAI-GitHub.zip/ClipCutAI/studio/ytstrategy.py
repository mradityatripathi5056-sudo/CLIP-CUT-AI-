"""The YouTube growth strategy from "The YouTube agent skill" by Jake Schincariol (MIT,
github.com/Jakeschincariol/youtube-agent-skill, commit a2feb21), built into Clip Cut AI:

- yt-seo: every clip gets the three search queries it should win, a title and the first two description lines
  that contain those queries' words, up to 15 tags used only for disambiguation (game, streamer, spellings,
  abbreviations) and a few hashtags. "The query test" is checked before posting.
- yt-package: ten titles are written and linted (60 characters for desktop search, the subject inside the first
  40 for mobile, at most two all-caps words, no vague hype words, a number/name/date when there is a real one, the
  subject up front); the best one is kept. Its title.py rules are ported below.
- yt-viral: videos in the niche are ranked by how far each beat ITS OWN CHANNEL's median (at least four videos per
  channel, or the channel is skipped), and the title formula of each outlier is named from the skill's 21 hook
  formulas (studio/ytskill/hooks.json). The formulas working right now steer the titles.
- yt-plan: post when the channel's own numbers say (best hours from your views), or at fixed times, or instantly.
- yt-comment: comments are sorted into questions, corrections, praise and bait (bait gets no reply), replies stay
  under 30 words, answer the question first and never promise a video; one comment per video is suggested to pin.
- yt-audit: a channel check that ends in ONE fix, three things that already work and what not to do yet.

The skill's own rule "never invent a number" is kept: titles may only use numbers, names and dates that the clip
itself contains. Its rule "nothing publishes" is the one difference: here you chose to let the app post."""
import json
import re
import statistics
import time
from pathlib import Path

HOOKS = json.loads((Path(__file__).parent / "ytskill" / "hooks.json").read_text(encoding="utf-8"))["hooks"]

# ------------------------------------------------------------------ title.py (yt-package), ported
DESKTOP, MOBILE, HARD = 60, 40, 100
VAGUE = {"amazing", "incredible", "insane", "crazy", "huge", "massive", "ultimate", "best", "powerful",
         "secret", "revolutionary", "mindblowing", "epic", "perfect", "complete", "everything"}
STOP = {"the", "a", "an", "of", "for", "to", "in", "on", "and", "or", "is", "are", "with", "your", "you", "my", "i",
        "this", "that", "it", "how", "what", "why", "ka", "ki", "ke", "ne", "hai", "se", "ko", "me", "mein", "ye", "kya"}


def words(t):
    return [re.sub(r"'s$", "", w).strip("'") for w in re.findall(r"[a-z0-9']+", (t or "").lower())]


def lint_title(title: str, thumb: str = None) -> dict:
    t = re.sub(r"\s+", " ", title or "").strip()
    n = len(t)
    issues, good = [], []
    if n > HARD:
        issues.append(("length", f"{n} characters: YouTube's hard limit is {HARD}"))
    elif n > DESKTOP:
        issues.append(("length", f"{n} characters: desktop search cuts near {DESKTOP}"))
    else:
        good.append(f"{n} characters, inside the {DESKTOP}-character desktop cut")
    if n > MOBILE:
        head = t[:MOBILE].rsplit(" ", 1)[0]
        issues.append(("mobile", f'a mobile feed shows about "{head}...": check the subject survives'))
    caps = [w for w in t.split() if len(w) > 2 and w.isupper()]
    if len(caps) > 2:
        issues.append(("shouting", f"{len(caps)} all-caps words: two is the ceiling before it reads as spam"))
    elif caps:
        good.append(f"{len(caps)} all-caps word for emphasis")
    v = [w for w in words(t) if w in VAGUE]
    if v:
        issues.append(("vague", f"{', '.join(sorted(set(v)))}: swap for a number, a name or a date"))
    nums = re.findall(r"\d[\d,.]*%?", t)
    if nums:
        good.append(f"carries a concrete figure ({', '.join(nums[:3])})")
    else:
        issues.append(("no-number", "no number, date or name: the most reliable single fix"))
    if t.endswith("?"):
        good.append("open question in the title")
    if not [w for w in words(t)[:3] if w not in STOP]:
        issues.append(("front-load", "the first three words are all filler: move the subject forward"))
    if thumb:
        shared = (set(words(t)) - STOP) & (set(words(thumb)) - STOP)
        if shared:
            issues.append(("duplicate", f"thumbnail repeats the title on {', '.join(sorted(shared))}"))
        else:
            good.append("thumbnail and title carry different words")
        if len(words(thumb)) > 4:
            issues.append(("thumb-length", f"{len(words(thumb))} words on the thumbnail: three is the ceiling"))
    score = max(0, min(100, 100 - 14 * len(issues) + 4 * len(good)))
    return {"title": t, "chars": n, "score": score, "issues": issues, "good": good}


# ------------------------------------------------------------------ swipe.py (yt-viral), ported
def classify(title: str) -> str:
    scored = []
    for f in HOOKS:
        n = sum(1 for p in f["match"] if re.search(p, title or "", re.I))
        if n:
            scored.append((n, f["name"]))
    scored.sort(reverse=True)
    return scored[0][1] if scored else "Unclassified"


def outliers(videos: list, lo: float = 2.0) -> dict:
    """Videos ranked by views as a multiple of their own channel's median (channels with under 4 videos skipped)."""
    by = {}
    for v in videos:
        by.setdefault(v.get("channel") or "?", []).append(v)
    out, thin = [], []
    for ch, vids in by.items():
        if len(vids) < 4:
            thin.append((ch, len(vids)))
            continue
        med = statistics.median([float(v.get("views") or 0) for v in vids])
        for v in vids:
            m = (float(v.get("views") or 0) / med) if med else 0
            if m >= lo:
                out.append({"channel": ch, "title": v.get("title", ""), "views": int(v.get("views") or 0), "median": int(med),
                            "multiple": round(m, 2), "formula": classify(v.get("title", "")), "url": v.get("url", "")})
    out.sort(key=lambda r: -r["multiple"])
    counts = {}
    for r in out:
        counts[r["formula"]] = counts.get(r["formula"], 0) + 1
    return {"outliers": out, "formulas": sorted(counts.items(), key=lambda x: -x[1]), "skipped_thin": thin}


def working_formulas(game: str = "", read=None) -> list:
    """Hook formulas behind the niche's current outliers (competitor pages you watch, plus trending), cached 12 h."""
    from . import accounts
    cache = accounts._read("ytstrategy.json", {})
    key = (game or "").lower()
    hit = (cache.get("formulas") or {}).get(key)
    if hit and time.time() - hit["at"] < 12 * 3600:
        return hit["list"]
    vids = []
    try:
        from . import autopilot
        for pg in autopilot.competitors(list_feed=read):
            for v in pg.get("all", pg.get("videos", [])):
                vids.append(dict(v, channel=pg["page"]))
    except Exception:  # noqa: BLE001
        pass
    if game:
        try:
            from . import trends
            vids += trends.trending(game)
        except Exception:  # noqa: BLE001
            pass
    found = [f for f, _ in outliers(vids)["formulas"] if f != "Unclassified"][:3]
    cache.setdefault("formulas", {})[key] = {"at": time.time(), "list": found}
    accounts._write("ytstrategy.json", cache)
    return found


# ------------------------------------------------------------------ yt-seo + yt-package for one clip
SCHEMA = {"type": "OBJECT", "properties": {
    "queries": {"type": "ARRAY", "items": {"type": "STRING"}},
    "titles": {"type": "ARRAY", "items": {"type": "STRING"}},
    "first_lines": {"type": "STRING"},
    "tags": {"type": "ARRAY", "items": {"type": "STRING"}},
    "hashtags": {"type": "ARRAY", "items": {"type": "STRING"}}},
    "required": ["queries", "titles", "first_lines", "tags", "hashtags"]}


def spoken(job, clip) -> str:
    """What is said during the clip (from the video's transcript), for the search words."""
    try:
        ws = json.loads((Path(job["dir"]) / "words.json").read_text(encoding="utf-8"))
        return " ".join(w["w"] for w in ws if clip["start"] <= w.get("s", 0) <= clip["end"])[:600]
    except Exception:  # noqa: BLE001 - live recordings keep their words elsewhere; the description is enough
        return ""


def _prompt(clip, creator, formulas, said=""):
    from . import brain
    shapes = [f"- {h['name']}: {h['shape']}" for h in HOOKS if h["name"] in formulas]
    aud = brain.AUDIENCE_RULES.get(creator.get("audience", "india"), "")
    return f"""You do YouTube SEO and packaging for a gaming Shorts/Reels page that posts clips of the streamer {brain._safe(creator.get('name', ''), 60)}.
Game: {brain._safe(creator.get('game', '') or 'not given', 60)}
What happens in the clip: {brain._safe(clip.get('description', ''), 500)}
Its current title: {brain._safe(clip.get('title') or clip.get('hook') or '', 120)}
What is said in it: {brain._safe(said, 500) or 'not available'}
{aud}
1. queries: the THREE search queries a real person would type that this clip should win (the words they would type, e.g. the game, the streamer, the moment).
2. titles: TEN different titles. Each under 60 characters, the subject in the first 40, at most two ALL-CAPS words, no vague hype words (amazing, insane, crazy, epic, ultimate, best, secret...) - use the specific thing instead. Use a number, a name or a date only if the clip really has it: NEVER invent a number, a result or a source. Each title should contain words from the queries.
{('Titles beating their own channel in this niche right now use these formulas; use them where they fit honestly:' + chr(10) + chr(10).join(shapes)) if shapes else ''}
3. first_lines: the first two lines of the description (they show above "...more" and are the search snippet): say what the viewer gets, in the words of the queries. Under 200 characters.
4. tags: up to 15, only for disambiguation: the game name and how people spell/abbreviate it, the streamer's name and spellings, the moment type. No unrelated or stuffed tags.
5. hashtags: 3 to 5, without the # sign, matching the queries.
No links and no @ names anywhere."""


def query_test(queries, title, first_lines) -> float:
    """Share of the queries whose main words appear in the title or the first two description lines."""
    have = set(words(f"{title} {first_lines}"))
    hits = 0
    for q in queries:
        main = [w for w in words(q) if w not in STOP]
        if main and sum(1 for w in main if w in have) >= max(1, len(main) // 2):
            hits += 1
    return hits / len(queries) if queries else 0.0


def seo_for(job, clip, creator, ask=None) -> dict:
    """The clip's search package, made once and kept on the clip."""
    from . import brain
    if clip.get("seo") and clip["seo"].get("v") == 1:
        return clip["seo"]
    formulas = []
    try:
        formulas = working_formulas(creator.get("game", ""))
    except Exception:  # noqa: BLE001
        pass
    if ask is None:
        said = spoken(job, clip)
        ask = lambda: brain.ask_ai(_prompt(clip, creator, formulas, said), schema=SCHEMA, purpose="YouTube SEO")[0]  # noqa: E731
    out = ask()
    queries = [brain._text(q, 80) for q in out.get("queries", []) if str(q).strip()][:3]
    first = brain._text(out.get("first_lines", ""), 220)
    ranked = []
    for t in out.get("titles", [])[:10]:
        t = brain._text(t, 100)
        if not t:
            continue
        r = lint_title(t)
        r["query_hit"] = query_test(queries, t, first)
        r["title_hits"] = round(query_test(queries, t, "") * len(queries))   # the title itself carries the query words
        r["total"] = r["score"] + 10 * r["title_hits"]
        ranked.append(r)
    if not ranked:
        raise ValueError("no titles came back")
    ranked.sort(key=lambda r: -r["total"])
    best = ranked[0]
    tags = []
    for t in out.get("tags", []):
        t = brain._text(t, 30).strip("# ")
        if t and t.lower() not in {x.lower() for x in tags}:
            tags.append(t)
    hashtags = []
    for h in out.get("hashtags", []):
        h = re.sub(r"[^\w]", "", str(h))[:30]
        if h and h.lower() not in {x.lower() for x in hashtags} and h.lower() != "shorts":
            hashtags.append(h)
    seo = {"v": 1, "title": best["title"], "first_lines": first, "queries": queries, "tags": tags[:15], "hashtags": hashtags[:5],
           "score": best["score"], "query_hit": best["query_hit"], "issues": [m for _, m in best["issues"]],
           "formula": classify(best["title"]), "runners_up": [r["title"] for r in ranked[1:3]], "at": time.time()}
    clip["seo"] = seo
    try:
        from . import jobs
        jobs.save(job)
    except Exception:  # noqa: BLE001
        pass
    try:
        from . import creators
        creators.log(creator["id"], f"SEO for \"{seo['title']}\": title score {seo['score']}/100, "
                                    f"search queries: {'; '.join(queries)}")
    except Exception:  # noqa: BLE001
        pass
    return seo


def apply(clip: dict, seo: dict) -> dict:
    """The clip as the post should see it: the SEO title, the two search lines first, the SEO hashtags."""
    desc = clip.get("description", "")
    lines = seo.get("first_lines", "")
    return dict(clip, title=seo["title"], description="\n\n".join(x for x in (lines, desc) if x),
                hashtags=list(dict.fromkeys(seo.get("hashtags", []) + list(clip.get("hashtags", []))))[:5])


# ------------------------------------------------------------------ yt-plan: when to post
def best_days(account_ids=None) -> list:
    """Weekdays by average views (Monday=0), from your own posts."""
    from . import growth
    by = {}
    for p in growth._posted(account_ids):
        by.setdefault(time.localtime(p["posted_at"]).tm_wday, []).append(p["views"] or 0)
    return sorted(({"day": d, "avg": round(sum(v) / len(v)), "posts": len(v)} for d, v in by.items()), key=lambda x: -x["avg"])


# ------------------------------------------------------------------ yt-audit: ONE fix
DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]


def audit(account_id: str) -> dict:
    """The channel check: the last ten titles as a set, upload rhythm, then ONE fix, three things that work, and
    what not to do yet. Only from what the app knows (no invented numbers)."""
    from . import posting
    ps = sorted((p for p in posting._mine() if p["account"] == account_id and p["status"] == "posted"),
                key=lambda p: -(p.get("posted_at") or 0))
    last = ps[:10]
    if len(last) < 3:
        return {"enough": False, "posts": len(last)}
    lints = [lint_title(p.get("title", "")) for p in last]
    forms = [classify(p.get("title", "")) for p in last]
    same = max(forms.count(f) for f in set(forms))
    gaps = [(a.get("posted_at") or 0) - (b.get("posted_at") or 0) for a, b in zip(last, last[1:])]
    gaps_h = [g / 3600 for g in gaps if g > 0]
    findings = []
    long_ = sum(1 for r in lints if r["chars"] > DESKTOP)
    vague = sum(1 for r in lints if any(k == "vague" for k, _ in r["issues"]))
    if gaps_h and max(gaps_h) > 4 * (statistics.median(gaps_h) or 1) and max(gaps_h) > 48:
        findings.append((3, "Upload rhythm", f"there was a gap of {max(gaps_h) / 24:.0f} days between posts. "
                         "Consistency beats volume: a steady daily plan that never stops is worth more than bursts."))
    if long_ >= 4:
        findings.append((2, "Titles too long", f"{long_} of the last {len(last)} titles are over {DESKTOP} characters, so search cuts them. "
                         "Keep the subject in the first 40 characters."))
    if vague >= 4:
        findings.append((2, "Vague titles", f"{vague} of the last {len(last)} titles lean on hype words (insane, crazy, epic). "
                         "Name the specific thing: the streamer, the game, the moment."))
    if same >= 7 and forms[0] != "Unclassified":
        findings.append((1, "Same shape every time", f"{same} of the last {len(last)} titles use the same formula ({forms[0]}). "
                         "A channel where every title has one shape has a format problem, not a title problem."))
    working = []
    if not long_:
        working.append("Every recent title fits inside the desktop search cut.")
    if gaps_h and max(gaps_h) <= 48:
        working.append("Posting is steady: no gap longer than two days.")
    if sum(1 for r in lints if r["score"] >= 70) >= len(lints) // 2:
        working.append("Most titles pass the packaging check (70+ out of 100).")
    if not vague:
        working.append("Titles name specific things instead of hype words.")
    findings.sort(key=lambda f: -f[0])
    fix = findings[0] if findings else (0, "Keep going", "Nothing stands out in titles or rhythm. Let the views build up and check again next week.")
    return {"enough": True, "posts": len(last), "fix": {"title": fix[1], "what": fix[2]}, "working": working[:3],
            "not_yet": "Don't change everything at once, and don't chase tags: YouTube says tags barely matter. Fix the one thing above first.",
            "titles": [{"title": r["title"], "score": r["score"], "formula": f} for r, f in zip(lints, forms)]}
