"""Alerts on your phone's lock screen (web push), from the installed Clip Cut AI app: no Telegram needed.
Works on Android (Chrome), and on iPhone once the app is added to the Home Screen (iOS 16.4+). Needs https
(PUBLIC_URL) or the app opened on this computer; push is sent through the phone maker's push service."""
import base64
import json
import threading

from . import accounts, config, ctx

_lock = threading.Lock()


def _keys() -> dict:
    """This server's VAPID key pair, made once."""
    f = config.DATA_DIR / "vapid.json"
    with _lock:
        try:
            return json.loads(f.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            pass
        from cryptography.hazmat.primitives import serialization
        from cryptography.hazmat.primitives.asymmetric import ec
        k = ec.generate_private_key(ec.SECP256R1())
        pem = k.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8,
                              serialization.NoEncryption()).decode()
        pub = k.public_key().public_bytes(serialization.Encoding.X962, serialization.PublicFormat.UncompressedPoint)
        d = {"private_pem": pem, "public": base64.urlsafe_b64encode(pub).decode().rstrip("=")}
        f.write_text(json.dumps(d), encoding="utf-8")
        try:
            import os
            os.chmod(f, 0o600)
        except OSError:
            pass
        return d


def public_key() -> str:
    return _keys()["public"]


def subs() -> list:
    return accounts._read("push.json", [])


def add(sub: dict):
    ep = str((sub or {}).get("endpoint", ""))
    keys = (sub or {}).get("keys") or {}
    if not ep.startswith("https://") or not keys.get("p256dh") or not keys.get("auth"):
        raise ValueError("This browser didn't give a push address.")
    rows = [s for s in subs() if s["endpoint"] != ep] + [{"endpoint": ep, "keys": {"p256dh": keys["p256dh"], "auth": keys["auth"]}}]
    accounts._write("push.json", rows[-10:])


def remove(endpoint: str):
    accounts._write("push.json", [s for s in subs() if s["endpoint"] != endpoint])


def send(text: str, link: str = "/") -> int:
    """Push to every phone of the current user; drops phones that unsubscribed. Returns how many got it."""
    rows = subs()
    if not rows:
        return 0
    try:
        from pywebpush import WebPushException, webpush
    except ImportError:
        return 0
    from py_vapid import Vapid
    v = Vapid.from_pem(_keys()["private_pem"].encode())
    sent, gone = 0, []
    for s in rows:
        try:
            webpush(s, json.dumps({"title": "Clip Cut AI", "body": text[:180], "url": link or "/"}), vapid_private_key=v,
                    vapid_claims={"sub": "mailto:" + (config.MAIL_FROM or "admin@clipcut.local")}, timeout=15)
            sent += 1
        except WebPushException as e:
            if getattr(e, "response", None) is not None and e.response.status_code in (404, 410):
                gone.append(s["endpoint"])
        except Exception:  # noqa: BLE001
            pass
    for ep in gone:
        remove(ep)
    return sent


def notify_async(text: str, link: str = ""):
    if subs():
        threading.Thread(target=ctx.bind(send), args=(text, link), daemon=True).start()
