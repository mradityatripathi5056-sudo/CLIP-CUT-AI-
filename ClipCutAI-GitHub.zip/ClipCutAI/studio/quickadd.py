"""Add a creator by pasting their YouTube (or Twitch) channel: the app makes the creator, turns on new uploads,
picks every connected account and decides how many Reels a day and at what times, from the audience
(India or the rest of the world) and how much the channel uploads."""
import datetime as dt
import re
from zoneinfo import ZoneInfo

from . import accounts, creators

IST = ZoneInfo("Asia/Kolkata")
# Times in India time. India: lunch break, after college/office, late night scrolling.
# Rest of the world: evening in the US (early morning in India), evening in Europe/Gulf.
PLANS = {"india": ["12:30", "15:30", "18:30", "21:00", "22:30"],
         "global": ["06:30", "08:30", "20:00", "23:30", "02:00"]}


def channel_name(url: str) -> str:
    m = re.search(r"(?:youtube\.com/(?:@|c/|user/)|twitch\.tv/)([\w.\-]+)", url or "")
    return m.group(1) if m else ""


def per_day(videos: list) -> int:
    """More clips a day for channels with lots of long videos/streams; never spammy (2 to 5)."""
    if not videos:
        return 3
    long_ = sum(1 for v in videos if v.get("duration", 0) >= 20 * 60 or v.get("live"))
    if long_ >= 6:
        return 5
    if long_ >= 3:
        return 4
    return 3 if len(videos) >= 4 else 2


def to_server_time(hhmm: str) -> str:
    """The app posts by this computer's clock; the plans are written in India time."""
    h, m = (int(x) for x in hhmm.split(":"))
    today = dt.datetime.now(IST).replace(hour=h, minute=m, second=0, microsecond=0)
    return today.astimezone().strftime("%H:%M")


def plan(audience: str, n: int) -> dict:
    times_ist = sorted(PLANS["global" if audience == "global" else "india"][:n], key=lambda t: (t < "05:00", t))
    return {"per_day": n, "times_india": times_ist, "times": [to_server_time(t) for t in times_ist]}


def quick_add(url: str, audience: str = "india", name: str = "", read_feed=None) -> dict:
    url = (url or "").strip()
    if not re.match(r"https://(www\.|m\.)?(youtube\.com/(@|c/|channel/|user/)|twitch\.tv/)[\w.\-]+", url):
        raise ValueError("Paste a channel link like https://www.youtube.com/@name")
    url = re.sub(r"(youtube\.com/@[\w.\-]+).*", r"\1", url.replace("m.youtube", "www.youtube"))
    audience = "global" if audience == "global" else "india"
    for c in creators.all_creators():
        if url.rstrip("/").lower() in [v.rstrip("/").lower() for v in c.get("channels", {}).values()]:
            raise ValueError(f"{c['name']} already has this channel.")
    videos = []
    if read_feed:
        try:
            videos = read_feed(url.rstrip("/") + "/videos", 10) if "youtube" in url else read_feed(url.rstrip("/") + "/videos", 10)
        except Exception:  # noqa: BLE001 - the plan still works without it
            videos = []
    p = plan(audience, per_day(videos))
    accs = [a["id"] for a in accounts.list_accounts()]
    c = creators.create({"name": name or channel_name(url) or "New creator", "channel": url, "audience": audience,
                         "auto_uploads": True, "autopost": bool(accs), "accounts": accs, "daily_cap": p["per_day"],
                         "post_times": ", ".join(p["times"]), "auto_times": True, "post_mode": "strategy", "trend_tags": True,
                         "caption_style": "hype", "brand_on": True})
    return {"creator": c, "plan": p, "accounts": len(accs), "videos_seen": len(videos)}
