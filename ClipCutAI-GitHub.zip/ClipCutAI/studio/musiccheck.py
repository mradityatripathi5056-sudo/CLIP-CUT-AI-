"""Is there a known song in this clip? Streamers often play music on stream, and a Reel or Short with a
copyrighted song gets muted, blocked or claimed. Uses AudD (audd.io, free trial then paid; paste the API token
in Settings, Apps). A 12-second piece from the middle of the clip is sent; nothing else."""
import subprocess
import tempfile
from pathlib import Path

import httpx

from . import accounts

API = "https://api.audd.io/"


def ready() -> bool:
    return bool(accounts.settings().get("audd_token"))


def song_in(path: Path, at: float = 0.0):
    """'Artist - Title' when a song is recognised, else None."""
    token = accounts.settings().get("audd_token")
    if not token:
        return None
    with tempfile.TemporaryDirectory() as d:
        piece = Path(d) / "p.mp3"
        subprocess.run(["ffmpeg", "-v", "error", "-y", "-ss", f"{max(0.0, at):.2f}", "-t", "12", "-i", str(path), "-vn",
                        "-ac", "1", "-ar", "22050", "-b:a", "64k", str(piece)], capture_output=True, timeout=120)
        if not piece.is_file() or piece.stat().st_size < 2000:
            return None
        with open(piece, "rb") as fh:
            r = httpx.post(API, data={"api_token": token}, files={"file": ("p.mp3", fh, "audio/mpeg")}, timeout=60)
    d = r.json() if r.status_code < 400 else {}
    res = d.get("result") if isinstance(d, dict) else None
    if not res:
        return None
    return f"{str(res.get('artist', ''))[:60]} - {str(res.get('title', ''))[:80]}".strip(" -") or None


def check_clip(job, clip):
    """Checks the rendered clip once and keeps the answer on the clip ("" means no song found)."""
    if "music_song" in clip:
        return clip["music_song"] or None
    path = Path(job["dir"]) / "clips" / clip["file"]
    dur = float(clip.get("end", 0)) - float(clip.get("start", 0))
    song = song_in(path, max(0.0, dur / 2 - 6))
    clip["music_song"] = song or ""
    from . import jobs
    jobs.save(job)
    return song
