"""A daily limit per account: "at most 3 Reels a day on this YouTube channel" (you can raise or lower it).

The count for a date is everything that went live on that page that day, in India time: the app's own posts AND
anything you (or another tool) posted by hand, read from YouTube or Instagram every 2 hours. When the app opens
again after being closed, it checks first and only then posts. A post that would go over the limit moves to the
next day at the same time."""
import datetime as dt
import threading
import time
from zoneinfo import ZoneInfo

import httpx

from . import accounts, auth, ctx

IST = ZoneInfo("Asia/Kolkata")
DEFAULTS = {"youtube": 3}            # a new YouTube channel starts at 3 a day; others have no limit (0) until set
EVERY = 2 * 3600
_checked_now: dict = {}               # (user, account) -> when it was checked since this app started
_lock = threading.Lock()


def day(ts: float) -> str:
    return dt.datetime.fromtimestamp(ts, IST).strftime("%Y-%m-%d")


def limit_of(acc) -> int:
    v = acc.get("daily_limit")
    return int(v) if v is not None else DEFAULTS.get(acc["platform"], 0)


def _state() -> dict:
    return accounts._read("limits.json", {})


def _save(d):
    accounts._write("limits.json", d)


# ------------------------------------------------------------------ what's on the page itself
def _youtube_ids(acc, days: set) -> list:
    tok = accounts._yt_token(acc)
    h = {"Authorization": f"Bearer {tok}"}
    ch = accounts._check(httpx.get("https://www.googleapis.com/youtube/v3/channels", params={"part": "contentDetails", "mine": "true"},
                                   headers=h, timeout=30), "Reading the channel").json()
    up = (((ch.get("items") or [{}])[0].get("contentDetails") or {}).get("relatedPlaylists") or {}).get("uploads")
    if not up:
        return []
    r = accounts._check(httpx.get("https://www.googleapis.com/youtube/v3/playlistItems",
                                  params={"part": "contentDetails", "playlistId": up, "maxResults": 50}, headers=h, timeout=30),
                        "Reading the uploads").json()
    out = []
    for it in r.get("items", []):
        cd = it.get("contentDetails") or {}
        when = cd.get("videoPublishedAt")
        if when:
            ts = dt.datetime.fromisoformat(when.replace("Z", "+00:00")).timestamp()
            if day(ts) in days:
                out.append((cd["videoId"], day(ts)))
    return out


def _instagram_ids(acc, days: set) -> list:
    host = accounts.FB if acc.get("via") == "facebook" else accounts.IG
    r = httpx.get(f"{host}/{acc.get('user_id') or 'me'}/media", params={"fields": "id,timestamp,media_product_type", "limit": 50},
                  headers={"Authorization": f"Bearer {accounts._ig_token(acc)}"}, timeout=30)
    if r.status_code >= 400:
        raise RuntimeError(f"Instagram said {r.status_code}")
    out = []
    for m in r.json().get("data", []):
        if m.get("media_product_type") not in (None, "REELS"):
            continue
        ts = dt.datetime.strptime(m["timestamp"], "%Y-%m-%dT%H:%M:%S%z").timestamp()
        if day(ts) in days:
            out.append((m["id"], day(ts)))
    return out


READERS = {"youtube": _youtube_ids, "instagram": _instagram_ids}


def check(aid, now=None) -> dict:
    """Read today's and yesterday's posts from the page itself (YouTube and Instagram)."""
    now = now or time.time()
    acc = accounts.get(aid)
    if not acc:
        return {}
    days = {day(now), day(now - 86400)}
    row = {"checked": now, "days": {}, "error": ""}
    reader = READERS.get(acc["platform"])
    if reader:
        try:
            for vid, d in reader(acc, days):
                row["days"].setdefault(d, []).append(vid)
        except Exception as e:  # noqa: BLE001 - keep what was read last time; the app's own posts still count
            row["error"] = str(e)[:150]
            row["days"] = {d: v for d, v in ((_state().get(aid) or {}).get("days") or {}).items() if d in days}
    with _lock:
        s = _state()
        s[aid] = row
        _save(s)
        _checked_now[(ctx.uid(), aid)] = now
    return row


def check_all():
    for a in accounts.list_accounts():
        if limit_of(accounts.get(a["id"]) or a):
            check(a["id"])


# ------------------------------------------------------------------ counting and holding
def used(aid, d: str) -> int:
    """Posts live (or going out right now) on this page on date d: the page's own list plus the app's posts."""
    from . import posting
    ids = set((_state().get(aid) or {}).get("days", {}).get(d, []))
    extra = 0
    for p in posting._mine():
        if p["account"] != aid:
            continue
        if p["status"] == "posted" and day(p.get("posted_at") or p["due_at"]) == d:
            if p.get("remote_id"):
                ids.add(p["remote_id"])
            else:
                extra += 1
        elif p["status"] == "posting" and day(max(time.time(), p["due_at"])) == d:
            extra += 1
    return len(ids) + extra


def hold(p) -> bool:
    """Called just before a post goes out. True (and the post moved to the next day) when that day is full."""
    acc = accounts.get(p["account"])
    if not acc:
        return False
    lim = limit_of(acc)
    if not lim:
        return False
    if time.time() - _checked_now.get((ctx.uid(), p["account"]), 0) > EVERY:
        check(p["account"])                 # first post since the app opened (or 2 hours on): look at the page first
    d = day(max(time.time(), p["due_at"]))
    n = used(p["account"], d)
    if n < lim:
        return False
    p["due_at"] = max(p["due_at"], time.time()) + 86400
    p["note"] = f"{acc['name']} already has {n} post{'s' if n != 1 else ''} on {d} (limit {lim}). Moved to the next day."
    return True


def status() -> list:
    s = _state()
    today = day(time.time())
    out = []
    for a in accounts.list_accounts():
        acc = accounts.get(a["id"]) or a
        row = s.get(a["id"]) or {}
        out.append({"id": a["id"], "name": a["name"], "platform": a["platform"], "limit": limit_of(acc),
                    "today": used(a["id"], today), "checked": row.get("checked"), "error": row.get("error", ""),
                    "reads_page": a["platform"] in READERS})
    return out


# ------------------------------------------------------------------ every 2 hours, and right after the app opens
def _loop():
    time.sleep(20)
    while True:
        for uid in auth.user_ids():
            try:
                with ctx.as_user(uid):
                    check_all()
            except Exception:  # noqa: BLE001
                pass
        time.sleep(EVERY)


def start():
    threading.Thread(target=_loop, daemon=True).start()
