"""Running Clip Cut AI from Telegram, with buttons.

With the Telegram bot set up (Settings: bot token and chat id) and "Control from Telegram" on:
  - each new clip arrives as a photo with its title, with buttons: Post now, Add to queue, Skip;
  - each reply the AI wrote for a comment (when replies wait for approval) arrives with: Send reply, Skip;
  - the bot answers /status (today's numbers), /pause and /resume (all posting).
Only messages from the chat saved in Settings are obeyed. Buttons carry a random key, never the clip itself, and
each key works once."""
import json
import secrets
import threading
import time
from pathlib import Path

import httpx

from . import accounts, auth, ctx

FILE = "telegram.json"
_lock = threading.RLock()


def _api(token: str, method: str) -> str:
    return f"https://api.telegram.org/bot{token}/{method}"


def on() -> bool:
    s = accounts.settings()
    return bool(s.get("tg_control") and s["telegram_token"] and s["telegram_chat"])


def _state() -> dict:
    d = accounts._read(FILE, {})
    d.setdefault("offset", 0)
    d.setdefault("keys", {})
    return d


def _save(d):
    if len(d["keys"]) > 400:                       # oldest buttons stop working first
        for k in sorted(d["keys"], key=lambda k: d["keys"][k].get("at", 0))[:len(d["keys"]) - 400]:
            d["keys"].pop(k, None)
    accounts._write(FILE, d)


def _key(d, what: dict) -> str:
    k = secrets.token_hex(5)
    d["keys"][k] = {**what, "at": time.time()}
    return k


def _send(method: str, data: dict, files=None):
    s = accounts.settings()
    try:
        r = httpx.post(_api(s["telegram_token"], method), data=data, files=files, timeout=30)
        return r.json() if r.status_code < 400 else None
    except Exception:  # noqa: BLE001 - the bot token is never put into an error
        return None


# ------------------------------------------------------------------ offers sent to the phone
def offer_clip(job, clip):
    """A new clip, as a photo with Post now / Add to queue / Skip."""
    from . import creators
    if not on():
        return
    c = creators.get(job.get("creator")) if job.get("creator") else None
    accs = (c or {}).get("accounts") or []
    with _lock:
        d = _state()
        rows = []
        if accs:
            rows.append([{"text": "🚀 Post now", "callback_data": "k:" + _key(d, {"t": "post", "job": job["id"], "clip": clip["id"], "now": True})},
                         {"text": "🕒 Add to queue", "callback_data": "k:" + _key(d, {"t": "post", "job": job["id"], "clip": clip["id"], "now": False})}])
        rows.append([{"text": "🗑 Skip", "callback_data": "k:" + _key(d, {"t": "skipclip", "job": job["id"], "clip": clip["id"]})}])
        _save(d)
    who = c["name"] if c else "No creator"
    text = (f"🎬 New clip · {who}\n{clip.get('title') or clip.get('hook') or 'Clip'}\nScore {clip.get('score', 0)}"
            + ("" if accs else "\nPick accounts in this creator's Setup to post from here."))
    s = accounts.settings()
    cover = Path(job["dir"]) / "clips" / (clip.get("cover") or "")
    markup = json.dumps({"inline_keyboard": rows})
    if clip.get("cover") and cover.is_file():
        with cover.open("rb") as f:
            _send("sendPhoto", {"chat_id": s["telegram_chat"], "caption": text[:1000], "reply_markup": markup}, files={"photo": f})
    else:
        _send("sendMessage", {"chat_id": s["telegram_chat"], "text": text, "reply_markup": markup})


def offer_reply(item: dict):
    """A reply the AI wrote for a comment, with Send reply / Skip."""
    if not on():
        return
    with _lock:
        d = _state()
        rows = [[{"text": "✅ Send reply", "callback_data": "k:" + _key(d, {"t": "reply", "id": item["id"]})},
                 {"text": "Skip", "callback_data": "k:" + _key(d, {"t": "skipreply", "id": item["id"]})}]]
        _save(d)
    s = accounts.settings()
    text = f"💬 {item['author']} on {item['post_title'][:60]}:\n“{item['text'][:300]}”\n\nAI reply:\n{item['reply']}"
    _send("sendMessage", {"chat_id": s["telegram_chat"], "text": text, "reply_markup": json.dumps({"inline_keyboard": rows})})


# ------------------------------------------------------------------ what the buttons and commands do
def _do(what: dict) -> str:
    from . import creators, jobs, posting, replies
    t = what.get("t")
    if t in ("post", "skipclip"):
        job = jobs.get(what["job"])
        clip = next((c for c in job["clips"] if c["id"] == what["clip"]), None) if job else None
        if not clip or clip.get("status") != "done":
            return "That clip is gone."
        if t == "skipclip":
            return "Skipped."
        c = creators.get(job.get("creator")) if job.get("creator") else None
        made = posting.enqueue(job, clip, (c or {}).get("accounts") or [], now=bool(what.get("now")))
        if not made:
            return "Already posted or queued there."
        return "Posting now 🚀" if what.get("now") else f"Queued for {time.strftime('%d %b %H:%M', time.localtime(made[0]['due_at']))} 🕒"
    if t == "reply":
        try:
            replies.send(what["id"])
            return "Reply sent ✅"
        except ValueError as e:
            return str(e)[:150]
    if t == "skipreply":
        try:
            replies.skip(what["id"])
        except ValueError:
            pass
        return "Skipped."
    return "That button is no longer used."


def _command(text: str) -> str:
    from . import posting
    cmd = text.strip().split()[0].lower().split("@")[0] if text.strip() else ""
    if cmd == "/status":
        return posting.digest_text()
    if cmd == "/pause":
        accounts.save_settings({"paused": True})
        return "Posting paused ⏸. Send /resume to start again."
    if cmd == "/resume":
        accounts.save_settings({"paused": False})
        return "Posting is back on ▶️"
    if cmd in ("/start", "/help"):
        return ("Clip Cut AI is connected. New clips and comment replies come here with buttons.\n/status: today's numbers\n"
                "/pause and /resume: all posting\nOr just write to the Manager, like: aaj kitne views aaye?")
    return ""


def handle(update: dict):
    """One update from Telegram, for the signed-in user. Anything not from their own chat is ignored."""
    s = accounts.settings()
    chat = str(s["telegram_chat"]).strip()
    cb = update.get("callback_query")
    if cb:
        msg = cb.get("message") or {}
        if str((msg.get("chat") or {}).get("id")) != chat:
            return
        data = str(cb.get("data") or "")
        with _lock:
            d = _state()
            what = d["keys"].pop(data[2:], None) if data.startswith("k:") else None
            _save(d)
        answer = _do(what) if what else "This button was already used."
        _send("answerCallbackQuery", {"callback_query_id": cb.get("id", ""), "text": answer[:190]})
        _send("editMessageReplyMarkup", {"chat_id": chat, "message_id": msg.get("message_id", 0),
                                          "reply_markup": json.dumps({"inline_keyboard": [[{"text": answer[:60], "callback_data": "done"}]]})})
        return
    msg = update.get("message") or {}
    if str((msg.get("chat") or {}).get("id")) != chat or not msg.get("text"):
        return
    out = _command(msg["text"])
    if not out and not msg["text"].startswith("/"):
        from . import manager                        # anything else is a message for the Manager
        try:
            out = manager.chat(msg["text"], source="telegram")
        except Exception as e:  # noqa: BLE001
            out = str(e)[:300]
    if out:
        _send("sendMessage", {"chat_id": chat, "text": out[:3900]})


def poll_once():
    """Read new updates for the signed-in user and act on them."""
    s = accounts.settings()
    with _lock:
        d = _state()
        offset = d["offset"]
    try:
        r = httpx.get(_api(s["telegram_token"], "getUpdates"),
                      params={"offset": offset, "timeout": 0, "allowed_updates": json.dumps(["message", "callback_query"])}, timeout=20)
        ups = r.json().get("result", []) if r.status_code == 200 else []
    except Exception:  # noqa: BLE001
        return
    for u in ups:
        with _lock:
            d = _state()
            d["offset"] = max(d["offset"], int(u.get("update_id", 0)) + 1)
            _save(d)
        try:
            handle(u)
        except Exception:  # noqa: BLE001
            pass


def _loop():
    time.sleep(30)
    while True:
        for uid in auth.user_ids():
            try:
                with ctx.as_user(uid):
                    if on():
                        poll_once()
            except Exception:  # noqa: BLE001
                pass
        time.sleep(4)


def _clip_ready(job, clip):
    """A new clip: offer it on Telegram, unless it is already being posted by itself."""
    from . import creators
    try:
        c = creators.get(job.get("creator")) if job.get("creator") else None
        if c and c.get("autopost") and c.get("accounts") and clip.get("score", 0) >= c.get("post_min_score", 75):
            return
        threading.Thread(target=ctx.bind(offer_clip), args=(job, clip), daemon=True).start()
    except Exception:  # noqa: BLE001
        pass


def start():
    from . import jobs
    jobs.on_clip_ready.append(_clip_ready)
    threading.Thread(target=_loop, daemon=True).start()
