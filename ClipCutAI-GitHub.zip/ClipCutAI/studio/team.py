"""A shared workspace: the owner adds a teammate's email, and once that person signs in (or signs up) with it, they
work in the owner's workspace: the same creators, videos, clips, connected accounts, calendar and comments.

Each person keeps their own login, password and profile. Server settings (AI key, connected-app setup, storage)
stay with admins. A teammate cannot add other people, and the owner can remove them at any time. Only works with
sign-in on (CLIPCUT_ACCOUNTS=1).

Kept in team.json in the data folder: {"members": {teammate id: owner id}, "invites": {email: owner id}}."""
import json
import threading

from . import auth, config

_lock = threading.RLock()
_mem = {"at": None, "data": None}
MAX_MEMBERS = 10


def _file():
    return config.DATA_DIR / "team.json"


def _load() -> dict:
    f = _file()
    try:
        at = f.stat().st_mtime_ns
    except OSError:
        at = 0
    if _mem["at"] != at or _mem["data"] is None:
        try:
            d = json.loads(f.read_text(encoding="utf-8")) if at else {}
        except (OSError, ValueError):
            d = {}
        d.setdefault("members", {})
        d.setdefault("invites", {})
        _mem.update(at=at, data=d)
    return _mem["data"]


def _save(d):
    f = _file()
    tmp = f.with_suffix(".tmp")
    tmp.write_text(json.dumps(d), encoding="utf-8")
    tmp.replace(f)
    _mem["at"] = None


def workspace_of(user) -> str:
    """Whose workspace this signed-in person works in: their own, or the owner who added them."""
    if user is None:
        return None
    d = _load()
    owner = d["members"].get(user.id)
    if owner:
        return owner
    email = (user.email or "").lower()
    if email in d["invites"]:
        with _lock:
            d = _load()
            owner = d["invites"].pop(email, None)
            if owner and owner != user.id and not d["members"].get(owner):
                d["members"][user.id] = owner
                r = d.setdefault("roles", {}).pop("invite:" + email, None)
                if r:
                    d["roles"][user.id] = r
                _save(d)
                return owner
            _save(d)
    return user.id


def is_member(user) -> bool:
    return bool(user and _load()["members"].get(user.id))


ROLES = ("manager", "editor")
# manager: everything the owner can do in the workspace. editor: makes, reviews and posts clips, and sees the
# calendar, but can't change settings, connected accounts, creators' setup, the AI Manager, the team or money.
EDITOR_BLOCKED = ("/api/manager", "/api/backups", "/api/owner-login", "/api/mail-setup", "/api/sponsors", "/api/money",
                  "/api/affiliate", "/api/admin", "/api/push-test")
EDITOR_BLOCKED_WRITES = ("/api/settings", "/api/accounts", "/api/apps", "/api/connect", "/api/creators", "/api/quick-add",
                         "/api/music", "/api/bio", "/api/team")   # may look, not change (POST/PUT/DELETE)


def role_of(user) -> str:
    """'owner' for someone in their own workspace, else the teammate's role."""
    if not user:
        return "owner"
    d = _load()
    if not d["members"].get(user.id):
        return "owner"
    r = d.get("roles", {}).get(user.id, "manager")
    return r if r in ROLES else "manager"


def allowed(user, path: str, method: str) -> bool:
    if role_of(user) != "editor":
        return True
    if path.startswith(EDITOR_BLOCKED):
        return False
    if method not in ("GET", "HEAD") and path.startswith(EDITOR_BLOCKED_WRITES) and path != "/api/team/leave":
        return False
    return True


def set_role(owner, who: str, role: str) -> dict:
    if role not in ROLES:
        raise ValueError("Pick manager or editor.")
    who = (who or "").strip().lower()
    with _lock:
        d = _load()
        roles = d.setdefault("roles", {})
        hit = False
        for m, o in d["members"].items():
            u = auth.get_user(m) if o == owner.id else None
            if u and (u.email or "").lower() == who:
                roles[m], hit = role, True
        for e, o in d["invites"].items():
            if o == owner.id and e == who:
                roles["invite:" + e], hit = role, True
        if not hit:
            raise ValueError("That person isn't in your team.")
        _save(d)
    return listing(owner)


def invite(owner, email: str, role: str = "manager") -> dict:
    email = (email or "").strip().lower()
    role = role if role in ROLES else "manager"
    if not auth.EMAIL_RE.match(email):
        raise ValueError("Enter a valid email address.")
    if is_member(owner):
        raise ValueError("Only the workspace owner can add people.")
    if email == (owner.email or "").lower():
        raise ValueError("That is your own email.")
    with _lock:
        d = _load()
        mine = [m for m, o in d["members"].items() if o == owner.id] + [e for e, o in d["invites"].items() if o == owner.id]
        if len(mine) >= MAX_MEMBERS:
            raise ValueError(f"A workspace can have up to {MAX_MEMBERS} teammates.")
        with auth.db.engine.connect() as c:
            row = c.execute(auth.sa.select(auth.db.users.c.id).where(auth.db.users.c.email == email)).first()
        if row and row[0] in d["members"]:
            raise ValueError("That person is already in a workspace.")
        if row and any(o == row[0] for o in d["members"].values()):
            raise ValueError("That person has their own team. They need to remove their teammates first.")
        if row:
            d["members"][row[0]] = owner.id
            d.setdefault("roles", {})[row[0]] = role
        else:
            d["invites"][email] = owner.id
            d.setdefault("roles", {})["invite:" + email] = role
        _save(d)
    return listing(owner)


def remove(owner, who: str):
    """Remove a teammate (by email) or an invite."""
    who = (who or "").strip().lower()
    with _lock:
        d = _load()
        d["invites"] = {e: o for e, o in d["invites"].items() if not (e == who and o == owner.id)}
        for m, o in list(d["members"].items()):
            if o != owner.id:
                continue
            u = auth.get_user(m)
            if (u and (u.email or "").lower() == who) or m == who:
                d["members"].pop(m, None)
        _save(d)
    return listing(owner)


def leave(user):
    with _lock:
        d = _load()
        d["members"].pop(user.id, None)
        _save(d)


def listing(user) -> dict:
    d = _load()
    owner_id = d["members"].get(user.id)
    if owner_id:
        o = auth.get_user(owner_id)
        return {"member_of": {"email": o.email if o else "", "name": (o.name if o else "") or ""}, "people": [],
                "role": role_of(user)}
    people = []
    for m, o in d["members"].items():
        if o == user.id:
            u = auth.get_user(m)
            if u:
                people.append({"email": u.email, "name": u.name or u.email.split("@")[0], "joined": True,
                               "role": d.get("roles", {}).get(m, "manager")})
    people += [{"email": e, "name": "", "joined": False, "role": d.get("roles", {}).get("invite:" + e, "manager")}
               for e, o in d["invites"].items() if o == user.id]
    return {"member_of": None, "people": people, "accounts_on": bool(config.ACCOUNTS), "role": "owner"}


def forget(uid: str):
    """A deleted account: out of every team, and its own team dissolved."""
    with _lock:
        d = _load()
        d["members"] = {m: o for m, o in d["members"].items() if m != uid and o != uid}
        d["invites"] = {e: o for e, o in d["invites"].items() if o != uid}
        _save(d)
