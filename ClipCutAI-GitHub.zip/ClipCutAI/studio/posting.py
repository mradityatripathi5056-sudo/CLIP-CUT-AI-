"""Post queue: decides when each finished clip goes to which account, posts it, and tracks views.
Clips go out spread by a gap, at a creator's fixed posting times, or at the exact time the person picked."""
import re
import secrets
import threading
import time
from pathlib import Path

import json

from . import accounts, alerts, config, creators, ctx, jobs, live

_lock = threading.RLock()
_FILE = config.DATA_DIR / "posts.json"
try:
    _posts: list = json.loads(_FILE.read_text(encoding="utf-8")) if _FILE.exists() else []
except ValueError:
    _posts = []


def _mine() -> list:
    u = ctx.uid()
    return [p for p in _posts if p.get("user") == u]
OPEN = ("scheduled", "posting")


def _save():
    with _lock:
        tmp = _FILE.with_suffix(".tmp")
        tmp.write_text(json.dumps(_posts, indent=1), encoding="utf-8")
        tmp.replace(_FILE)


def forget(uid: str):
    """Drop everything queued or recorded for a deleted account, so nothing is posted or retried for it any more."""
    with _lock:
        for p in _posts:
            if p.get("user") == uid:
                p["status"] = "deleted"          # the posting loop may be holding this one already: it then skips it
        _posts[:] = [p for p in _posts if p.get("user") != uid]
        _save()


def _day(t):
    return time.strftime("%Y-%m-%d", time.localtime(t))


def _mirror(p):
    """Copy the post's state onto its clip so the clip card can show it."""
    job = jobs.get(p["job"])
    clip = next((c for c in job["clips"] if c["id"] == p["clip"]), None) if job else None
    if clip is not None:
        clip.setdefault("posts", {})[p["id"]] = {k: p.get(k) for k in ("account_name", "platform", "status", "url", "due_at", "error")}
        jobs.save(job)


def _at(y, mo, d, h, mi):
    return time.mktime((y, mo, d, h, mi, 0, 0, 0, -1))


def _next_fixed(mine, times, cap):
    """The next of the creator's posting times (like 10:00, 14:30, 19:00) that this account has free, today or later,
    keeping to the daily cap."""
    now = time.time()
    taken = {round(p["due_at"] / 60) for p in mine if p["status"] in OPEN}
    for day in range(60):
        lt = time.localtime(now + 86400 * day)
        y, mo, d = lt.tm_year, lt.tm_mon, lt.tm_mday
        on_day = sum(1 for p in mine if _day(p.get("posted_at") or p["due_at"]) == _day(_at(y, mo, d, 12, 0)))
        for h, mi in times:
            t = _at(y, mo, d, h, mi)
            if on_day >= cap:
                break
            if t > now + 30 and round(t / 60) not in taken:
                return t
    return now + 3600


def _next_slot(account_id, gap_min, cap, times=None):
    """Earliest time that respects the gap between posts and the daily cap for this account
    (or the creator's fixed posting times, when it has some)."""
    mine = [p for p in _mine() if p["account"] == account_id and p["status"] in OPEN + ("posted",)]
    acc = accounts.get(account_id)
    if acc:                                   # the page's own daily limit, when lower than the creator's cap
        from . import limits
        lim = limits.limit_of(acc)
        cap = min(cap, lim) if lim else cap
    if times:
        return _next_fixed(mine, times, cap)
    t = max(time.time(), max((p.get("posted_at") or p["due_at"] for p in mine), default=0) + gap_min * 60)
    for _ in range(30):
        if sum(1 for p in mine if _day(p.get("posted_at") or p["due_at"]) == _day(t)) < cap:
            break
        lt = time.localtime(t + 86400)
        t = time.mktime((lt.tm_year, lt.tm_mon, lt.tm_mday, 9, 0, 0, 0, 0, -1))  # 9:00 next day
    return t


def enqueue(job, clip, account_ids, now=False, at=None, repeat_of=None, text=None) -> list:
    """Queue a clip for these accounts: now, at a picked time (`at`, seconds since 1970), or at the next free slot."""
    c = creators.get(job["creator"]) or creators.DEFAULTS
    if at is not None:
        at = float(at)
        if at < time.time() - 120:
            raise ValueError("That time has already passed. Pick a time in the future.")
        if at > time.time() + 366 * 86400:
            raise ValueError("Pick a time within the next year.")
    made = []
    with _lock:
        for aid in account_ids:
            acc = accounts.get(aid)
            if not acc:
                continue
            if any(p["job"] == job["id"] and p["clip"] == clip["id"] and p["account"] == aid
                   and (p["status"] in OPEN or (p["status"] == "posted" and not repeat_of)) for p in _mine()):
                continue  # never post the same clip to the same account twice (a planned repost of a hit aside)
            if not repeat_of and c.get("no_duplicates", True) and job.get("clips"):
                try:
                    from . import autopilot
                    if autopilot.is_duplicate(job, clip, aid):
                        creators.log(job["creator"], f"Not queued for {acc['name']}: the same moment already went there.")
                        continue
                except Exception:  # noqa: BLE001
                    pass
            due = time.time() if now else max(time.time(), at) if at is not None else \
                _next_slot(aid, c["post_gap_min"], c["daily_cap"], creators.times_of(c))
            p = {"id": secrets.token_hex(8), "user": ctx.uid(), "job": job["id"], "clip": clip["id"], "creator": job["creator"],
                 "account": aid, "account_name": acc["name"], "platform": acc["platform"], "status": "scheduled",
                 "due_at": due, "created": time.time(), "title": clip.get("title") or clip.get("hook") or "Clip",
                 "score": clip.get("score", 0), "tries": 0, "url": "", "remote_id": "", "error": None, "views": None}
            if repeat_of:
                p["recycle_of"] = repeat_of
            if text:
                p.update(title=text.get("title") or p["title"], title_override=text.get("title", ""),
                         desc_override=text.get("description", ""))
            _posts.append(p)
            made.append(p)
        _save()
    for p in made:
        _mirror(p)
    return made


def _post_top(job, clip) -> bool:
    """'Make clips and post the best N now' (asked of the Manager): post this clip at once if it is one of them."""
    n = int(job.get("post_top") or 0)
    if not n or clip.get("status") != "done":
        return False
    best = sorted((k for k in job.get("clips", []) if k.get("status") != "error"), key=lambda k: -(k.get("score") or 0))[:n]
    if clip["id"] not in {k["id"] for k in best} or clip["id"] in job.setdefault("posted_top", []):
        return False
    c = creators.get(job.get("creator")) if job.get("creator") else None
    targets = (c or {}).get("accounts") or []
    if not targets:
        return False
    job["posted_top"].append(clip["id"])
    try:
        jobs.save(job)
    except Exception:  # noqa: BLE001
        pass
    made = enqueue(job, clip, targets, now=True)
    if c:
        creators.log(c["id"], f"Posting now, as asked: {clip.get('title') or clip.get('hook')} ({len(made)} account(s))")
    return True


def on_clip_ready(job, clip):
    """Called once when a clip first finishes rendering."""
    if _post_top(job, clip):
        return
    c = creators.get(job["creator"])
    if not c or not c["autopost"] or not c["accounts"]:
        return
    if clip.get("score", 0) < c["post_min_score"]:
        return  # includes hand-made clips (score 0): those wait for you to press Post
    if c.get("only_with_permission") and c.get("permission") != "allowed":
        creators.log(c["id"], "Not posted on its own: this streamer hasn't allowed clipping yet (creator, Permission).")
        return
    if c.get("music_check"):
        try:
            from . import musiccheck
            song = musiccheck.check_clip(job, clip)
        except Exception:  # noqa: BLE001 - the check is a help, not a gate that breaks posting
            song = None
        if song:
            creators.log(c["id"], f"Held for you to look at: it has the song \"{song}\" (copyright claims are likely).")
            alerts.notify(f"clip held: it contains the song \"{song}\". Post it yourself if you're sure.", kind="post")
            return
    targets = c["accounts"]
    if c.get("rotate") and len(targets) > 1:
        # one account per clip, in turn, so several pages each get their own clips
        i = int(c.get("rotate_next", 0)) % len(targets)
        targets = [targets[i]]
        creators.update(c["id"], {"rotate_next": i + 1})
    from . import autopilot
    fast = autopilot.fast_live(job, clip, c) or c.get("post_mode") == "instant"   # instant upload
    made = enqueue(job, clip, targets, now=fast)
    if made:
        creators.log(c["id"], f"{'Posting now' if fast else 'Queued'} for {len(made)} account(s): {clip.get('title') or clip.get('hook')}")
        if c.get("hook_test") and len(made) > 1:
            try:
                autopilot.apply_hook_test(job, clip, made)
            except Exception:  # noqa: BLE001 - the clip still goes out with its own title everywhere
                pass


EMOJI = re.compile("[\U0001F000-\U0001FAFF\u2600-\u27BF\u2B00-\u2BFF\uFE0F\u200D\u2190-\u21FF\u2300-\u23FF]+")


def no_emoji(text: str) -> str:
    return re.sub(r"[ \t]{2,}", " ", EMOJI.sub("", text or "")).strip()


def _caption(clip, creator, desc_override="", extra_tags=()):
    # A description the person wrote themselves is posted as it is, without the AI's hashtags added to it, and
    # one that already ends with its hashtags does not get them twice.
    mine = [t.lstrip("#") for t in str(creator.get("always_tags") or "").split() if t.strip("#")]
    own = list(mine)                                   # your own hashtags first, then the clip's, then trending
    own += [t for t in clip.get("hashtags", []) if t.lower() not in {x.lower() for x in own}]
    own += [t for t in extra_tags if t.lower() not in {x.lower() for x in own}]
    tags = "" if clip.get("fixed_description") or clip.get("hashtags_in_description") else " ".join("#" + h for h in own)
    desc = desc_override or clip.get("description", "")
    if creator.get("caption_style") == "clean" and not clip.get("fixed_description"):
        desc = no_emoji(desc)
    return "\n\n".join(x for x in (desc, creator.get("cta_text", ""), tags, creator.get("post_footer", "")) if x)


def cap_hashtags(text: str, n):
    """Instagram takes at most 5 hashtags on a Reel (since December 2025) and Threads 1: keep the first n."""
    if not n:
        return text
    seen = [0]

    def keep(m):
        seen[0] += 1
        return m.group(0) if seen[0] <= n else ""
    out = re.sub(r"(?<![\w&])#\w+", keep, text)
    return re.sub(r"[ \t]{2,}", " ", out).strip()


def short_text(title, cap, n):
    """Title plus as many hashtags as fit (Bluesky allows 300 characters)."""
    tags = " ".join(w for w in cap.split() if w.startswith("#"))
    out = title
    for t in tags.split():
        if len(out) + len(t) + 1 > n:
            break
        out += (" " if out.endswith(tuple("#abcdefghijklmnopqrstuvwxyz0123456789")) or "#" in out else "\n\n") + t
    return out[:n]


def _wants_english(acc, creator) -> bool:
    lang = acc.get("lang", "auto")
    if lang == "english":
        return creator.get("audience", "india") == "india"      # the clip was written in Hinglish
    return False


def _english(job, clip, title, cap):
    """The same title and caption in plain English, made once per clip and kept with it."""
    key = f"{title}\n{cap}"
    en = clip.get("english") or {}
    if en.get("key") == key:
        return en["title"], en["cap"]
    from . import brain
    try:
        out, _, _ = brain.ask_ai(
            "Rewrite this gaming clip's title and caption in natural, punchy English for a worldwide audience. "
            "Keep the meaning, the emojis and every hashtag exactly. Do not add links or @ names.\n\nTITLE:\n"
            + brain._safe(title, 300) + "\n\nCAPTION:\n" + brain._safe(cap, 2500),
            schema={"type": "OBJECT", "properties": {"title": {"type": "STRING"}, "caption": {"type": "STRING"}},
                    "required": ["title", "caption"]}, purpose="translate")
        t, c = brain._text(out.get("title", ""), 100) or title, "\n\n".join(x for x in (brain._text(part, 2200) for part in str(out.get("caption", "")).split("\n\n")) if x)[:2200] or cap
    except Exception:  # noqa: BLE001 - no AI right now: post the original rather than nothing
        return title, cap
    clip["english"] = {"key": key, "title": t, "cap": c}
    try:
        jobs.save(job)
    except Exception:  # noqa: BLE001
        pass
    return t, c


def affiliate_block(creator) -> str:
    """The creator's gear links, through the app's own short links when it has a public address (to count clicks)."""
    from . import affiliate
    return affiliate.block(creator)


def _title(clip, creator):
    t = clip.get("title") or clip.get("hook") or "Clip"
    return no_emoji(t) or "Clip" if creator.get("caption_style") == "clean" else t


def _post(p):
    job = jobs.get(p["job"])
    clip = next((c for c in job["clips"] if c["id"] == p["clip"]), None) if job else None
    acc = accounts.get(p["account"])
    try:
        if not clip or clip.get("status") != "done":
            raise RuntimeError("The clip no longer exists or is not finished.")
        if not acc:
            raise RuntimeError("That account was disconnected.")
        path = Path(job["dir"]) / "clips" / clip["file"]
        creator = creators.get(job["creator"]) or dict(creators.DEFAULTS, name="clips")
        from . import autopilot
        yt_tags, cv = clip.get("hashtags", []), clip      # cv: the clip as this post shows it
        if creator.get("yt_seo", True) and config.ai_ready() and not clip.get("fixed_description") and not clip.get("long"):
            try:                                   # the YouTube strategy's SEO package (studio/ytstrategy.py)
                from . import ytstrategy
                seo = ytstrategy.seo_for(job, clip, creator)
                cv = ytstrategy.apply(clip, seo)
                yt_tags = seo["tags"] or yt_tags
            except Exception:  # noqa: BLE001 - no AI right now: the clip's own title and caption go out
                pass
        title = p.get("title_override") or _title(cv, creator)
        if creator.get("series") and not p.get("title_override"):
            title = autopilot.series_title(job, clip, title)
        if _wants_english(acc, creator) and clip.get("file_en") and (path.parent / clip["file_en"]).is_file():
            path = path.parent / clip["file_en"]          # the version with English subtitles
        trend = []
        if creator.get("trend_tags") and creator.get("game") and not autopilot.slowed(acc["id"]):
            try:
                from . import trends
                trend = trends.tags_for(creator["game"])[:3]
            except Exception:  # noqa: BLE001 - posting never waits on hashtags
                trend = []
        cap = _caption(cv, creator, p.get("desc_override", ""), trend)
        cap = cap_hashtags(cap, {"instagram": 5, "threads": 1}.get(acc["platform"]))
        if _wants_english(acc, creator) and not p.get("desc_override") and not p.get("title_override"):
            title, cap = _english(job, clip, title, cap)
        if acc["platform"] in ("youtube", "facebook") and creator.get("affiliate"):
            cap += "\n\n" + affiliate_block(creator)
        early = acc["platform"] == "youtube" and p["due_at"] > time.time() + 60
        if clip.get("long") and acc["platform"] != "youtube":
            raise RuntimeError("Compilations are long 16:9 videos: they go to YouTube only.")
        if acc["platform"] == "youtube":
            rid, url = accounts.youtube_upload(acc, path, title, cap if clip.get("long") else cap + "\n\n#Shorts",
                                               yt_tags, creator["privacy"],
                                               category=creator.get("yt_category", "20"), notify=creator.get("yt_notify", True),
                                               publish_at=p["due_at"] if early else 0)
        elif acc["platform"] == "instagram":
            cover = autopilot.best_cover_ms(path) if creator.get("best_cover", True) else 1200
            rid, url = accounts.instagram_upload(acc, path, f"{title}\n\n{cap}", job["id"], cover_ms=cover,
                                                 collaborators=creator.get("ig_collab", ""))
            if creator.get("ig_story"):
                try:
                    accounts.instagram_upload(acc, path, "", job["id"], kind="STORIES")
                except Exception as e:  # noqa: BLE001 - the Reel is up; the Story is extra
                    p["note"] = f"Reel posted, Story not: {str(e)[:150]}"
        elif acc["platform"] == "tiktok":
            rid, url = accounts.tiktok_upload(acc, path, f"{title}\n\n{cap}", creator["privacy"])
        elif acc["platform"] == "facebook":
            rid, url = accounts.facebook_upload(acc, path, f"{title}\n\n{cap}", title)
        elif acc["platform"] == "threads":
            rid, url = accounts.threads_upload(acc, path, f"{title}\n\n{cap}", job["id"])
        elif acc["platform"] == "bluesky":
            rid, url = accounts.bluesky_upload(acc, path, short_text(title, cap, 300))
        elif acc["platform"] == "telegram":
            rid, url = accounts.telegram_upload(acc, path, f"{title}\n\n{cap}")
        elif acc["platform"] == "discord":
            rid, url = accounts.discord_upload(acc, path, f"**{title}**\n{no_emoji(cap)[:600]}")
        else:
            raise RuntimeError("That kind of account is no longer supported.")
        p.update(status="posted", posted_at=p["due_at"] if early else time.time(), remote_id=rid, url=url, error=None)
        if early:
            p["publish_at"] = p["due_at"]
            creators.log(p["creator"], f"Uploaded to {acc['name']}; YouTube makes it public {time.strftime('%d %b %H:%M', time.localtime(p['due_at']))}: {title}")
        else:
            creators.log(p["creator"], f"Posted to {acc['name']}: {title}")
        if acc["platform"] == "youtube":
            _youtube_extras(p, acc, creator)
            if clip.get("long") and clip.get("cover"):
                try:
                    accounts.youtube_thumbnail(acc, rid, path.parent / clip["cover"])
                except Exception as e:  # noqa: BLE001
                    p["note"] = f"Posted; thumbnail not set (verify your channel's phone number on YouTube): {str(e)[:100]}"
    except Exception as e:  # noqa: BLE001
        p["tries"] += 1
        p["error"] = str(e)[-300:]
        if p["tries"] < 3 and clip and acc:
            p.update(status="scheduled", due_at=time.time() + 600)  # try again in 10 minutes
        else:
            p["status"] = "failed"
            creators.log(p["creator"], f"Post failed on {p['account_name']}: {p['error']}")
            alerts.notify(f"post failed on {p['account_name']} ({p['title']}): {p['error'][:200]}", kind="post")
    _save()
    _mirror(p)


def _youtube_extras(p, acc, creator):
    """After a Short is up: add it to the creator's playlist, and post the first comment (when the Short is public:
    straight away, or at the time YouTube makes a scheduled one public). A problem here never undoes the post."""
    notes = []
    if creator.get("yt_playlist"):
        try:
            accounts.youtube_playlist_add(acc, creator["yt_playlist"], p["remote_id"])
        except Exception as e:  # noqa: BLE001
            notes.append(_scope_hint(e, "Not added to the playlist"))
    if creator.get("yt_comment"):
        p["comment"] = creator["yt_comment"]
        p["comment_due"] = max(time.time(), p.get("publish_at") or 0) + 30
    if notes:
        p["note"] = " ".join(notes)[:300]
        creators.log(p["creator"], f"{acc['name']}: {p['note']}")


def _scope_hint(e, what):
    s = str(e)
    if "403" in s and ("scope" in s.lower() or "insufficient" in s.lower() or "forbidden" in s.lower()):
        return f"{what}: connect YouTube again in Settings and tick every box."
    return f"{what}: {s[:150]}"


def _comment(p):
    acc = accounts.get(p["account"])
    text = p.pop("comment", "")
    p.pop("comment_due", None)
    if acc and text:
        try:
            accounts.youtube_comment(acc, p["remote_id"], text)
        except Exception as e:  # noqa: BLE001
            p["note"] = _scope_hint(e, "First comment not posted")
            creators.log(p["creator"], f"{p['account_name']}: {p['note']}")
    _save()


def _early(p) -> bool:
    """A YouTube post due later that can be uploaded now: YouTube keeps it private and makes it public at its time,
    so the computer does not have to be on then. Only public posts, up to a week ahead, when the creator allows it."""
    if p["platform"] != "youtube" or not (time.time() + 900 < p["due_at"] < time.time() + 7 * 86400):
        return False
    c = creators.get(p["creator"]) or {}
    return bool(c.get("yt_early", True)) and c.get("privacy", "public") == "public"


def _run():
    while True:
        time.sleep(15)
        now = time.time()
        for p in [p for p in list(_posts) if p["status"] == "posted" and p.get("comment_due") and p["comment_due"] <= now and p.get("user")]:
            try:
                with ctx.as_user(p["user"]):
                    _comment(p)
            except Exception:  # noqa: BLE001
                pass
        due = [p for p in list(_posts) if p["status"] == "scheduled" and p.get("user")
               and (p["due_at"] <= now or (p["platform"] == "youtube" and p["due_at"] > now + 900))]
        for p in due:
            try:
                with ctx.as_user(p["user"]):
                    if accounts.settings()["paused"]:
                        continue
                    if p["due_at"] > time.time() and not _early(p):
                        continue
                    from . import autopilot, limits
                    if p["due_at"] <= time.time() and autopilot.hold_if_slowed(p):
                        _save()
                        continue
                    if limits.hold(p):           # this page already has its posts for that day
                        _save()
                        continue
                    with _lock:
                        if p["status"] != "scheduled":
                            continue
                        p["status"] = "posting"
                    _post(p)
            except Exception:  # noqa: BLE001
                pass


def _stats_for(recent):
    for aid in {p["account"] for p in recent if p["platform"] == "youtube"}:
        acc = accounts.get(aid)
        if acc:
            views = accounts.youtube_views(acc, [p["remote_id"] for p in recent if p["account"] == aid])
            for p in recent:
                if p["account"] == aid and p["remote_id"] in views:
                    p["views"] = views[p["remote_id"]]
    for p in recent:
        acc = accounts.get(p["account"]) if p["platform"] in ("instagram", "facebook") else None
        if acc:
            v = (accounts.instagram_views if p["platform"] == "instagram" else accounts.facebook_views)(acc, p["remote_id"])
            if v is not None:
                p["views"] = v


def _stats():
    while True:
        for uid in {p.get("user") for p in _posts if p.get("user")}:
            try:
                with ctx.as_user(uid):
                    _stats_for([p for p in _mine() if p["status"] == "posted" and time.time() - p["posted_at"] < 14 * 86400])
            except Exception:  # noqa: BLE001
                pass
        _save()
        time.sleep(1800)


def cancel(pid):
    with _lock:
        p = next((p for p in _mine() if p["id"] == pid), None)
        if not p or p["status"] != "scheduled":
            raise ValueError("Only posts that are still waiting can be cancelled.")
        p["status"] = "cancelled"
        _save()
    _mirror(p)


def reschedule(pid, at):
    """Move a post that is still waiting to another time."""
    at = float(at)
    if at < time.time() - 120:
        raise ValueError("That time has already passed. Pick a time in the future.")
    if at > time.time() + 366 * 86400:
        raise ValueError("Pick a time within the next year.")
    with _lock:
        p = next((p for p in _mine() if p["id"] == pid), None)
        if not p or p["status"] not in ("scheduled", "cancelled", "failed"):
            raise ValueError("Only posts that have not gone out yet can be moved.")
        p.update(status="scheduled", due_at=max(time.time(), at), tries=0, error=None, pinned=True)   # smart queue leaves it
        _save()
    _mirror(p)
    return p


def calendar(start: float, end: float) -> list:
    """Every post of the signed-in user that is due, or went out, between start and end: for the calendar."""
    names = {c["id"]: c["name"] for c in creators.all_creators()}
    out = []
    for p in _mine():
        if p["status"] in ("deleted",):
            continue
        t = p.get("posted_at") if p["status"] == "posted" else p["due_at"]
        if t and start <= t < end:
            out.append({**{k: p.get(k) for k in ("id", "job", "clip", "title", "platform", "account_name", "status",
                                                    "url", "error", "views", "due_at", "posted_at", "publish_at", "note")},
                        "at": t, "creator_name": names.get(p["creator"], "")})
    return sorted(out, key=lambda x: x["at"])


def retry(pid):
    with _lock:
        p = next((p for p in _mine() if p["id"] == pid), None)
        if not p or p["status"] not in ("failed", "cancelled"):
            raise ValueError("Only failed or cancelled posts can be retried.")
        p.update(status="scheduled", due_at=time.time(), tries=0, error=None)
        _save()
    _mirror(p)


def overview() -> dict:
    today = _day(time.time())
    _posts = _mine()  # everything below is about the signed-in user only
    rows = []
    all_cs, all_js = creators.all_creators(), jobs.list_jobs()
    for c in all_cs:
        js = [j for j in all_js if j["creator"] == c["id"]]
        clips = [k for j in js for k in j["clips"] if k.get("status") == "done"]
        ps = [p for p in _posts if p["creator"] == c["id"]]
        views = sum(p["views"] or 0 for p in ps)
        rows.append({
            "id": c["id"], "name": c["name"],
            "state": "recording" if live.active_for(c["id"]) else "waiting" if c["auto_watch"] and c["channel"] else "idle",
            "autopost": c["autopost"] and bool(c["accounts"]),
            "clips_today": sum(1 for k in clips if _day(k.get("made_at", 0)) == today), "clips_total": len(clips),
            "posted_today": sum(1 for p in ps if p["status"] == "posted" and _day(p["posted_at"]) == today),
            "posted_total": sum(1 for p in ps if p["status"] == "posted"),
            "queued": sum(1 for p in ps if p["status"] in OPEN), "failed": sum(1 for p in ps if p["status"] == "failed"),
            "views": views, "earnings": round(views / 1000 * c["rate_per_1k"], 2)})
    names = {c["id"]: c["name"] for c in all_cs}
    queue = sorted((p for p in _posts if p["status"] in OPEN), key=lambda p: p["due_at"])
    done = sorted((p for p in _posts if p["status"] in ("posted", "failed")), key=lambda p: -(p.get("posted_at") or p["due_at"]))[:15]
    show = [{**{k: v for k, v in p.items() if k != "user"}, "creator_name": names.get(p["creator"], "")} for p in queue + done]
    # last 14 days, oldest first, for the home graph
    days = [_day(time.time() - 86400 * i) for i in range(13, -1, -1)]
    made, posted, views = {d: 0 for d in days}, {d: 0 for d in days}, {d: 0 for d in days}
    for j in all_js:
        for k in j["clips"]:
            d = _day(k.get("made_at") or j["created"])
            if k.get("status") == "done" and d in made:
                made[d] += 1
    for p in _posts:
        if p["status"] == "posted" and _day(p["posted_at"]) in posted:
            posted[_day(p["posted_at"])] += 1
            views[_day(p["posted_at"])] += p["views"] or 0
    daily = [{"day": d, "clips": made[d], "posted": posted[d], "views": views[d]} for d in days]
    return {"paused": accounts.settings()["paused"], "creators": rows, "posts": show, "daily": daily,
            "alerts": alerts.configured(), "recording": len(live.active_mine())}


def digest_text() -> str:
    o = overview()
    lines = ["Clip Cut AI daily summary"]
    for r in o["creators"]:
        lines.append(f"- {r['name']}: {r['state']}, {r['clips_today']} clips today, {r['posted_today']} posted today, "
                     f"{r['queued']} waiting, {r['failed']} failed, {r['views']} views")
    if not o["creators"]:
        lines.append("No creators set up yet.")
    if o["paused"]:
        lines.append("Posting is paused.")
    return "\n".join(lines)


def start():
    with _lock:
        for p in _posts:
            if p["status"] == "posting":  # interrupted mid-upload last time
                p.update(status="failed", error="The studio closed during this upload. Check the account, then retry.")
        _save()
    jobs.on_clip_ready.append(on_clip_ready)
    threading.Thread(target=_run, daemon=True).start()
    threading.Thread(target=_stats, daemon=True).start()
    threading.Thread(target=alerts.digest_loop, args=(digest_text,), daemon=True).start()
    threading.Thread(target=alerts.keep_awake_loop,
                     args=(lambda: bool(live.active()) or any(p["status"] in OPEN for p in _posts),), daemon=True).start()
