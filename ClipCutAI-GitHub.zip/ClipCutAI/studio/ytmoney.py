"""YouTube money and the road to monetization: earnings (when the channel is in the Partner Program), views,
watch hours and Shorts views, and how far the channel is from the YPP thresholds. Uses the YouTube Analytics API;
channels connected before this feature must press Connect again once (to allow "view YouTube Analytics")."""
import datetime as dt

import httpx

from . import accounts

# YouTube's published thresholds (support.google.com/youtube/answer/72851). New entry rules from 1 Feb 2027.
CHANGE_DAY = dt.date(2027, 2, 1)
TIERS = {
    "fan": {"name": "Fan funding (memberships, Super Thanks)", "subs": 500, "uploads_90d": 3,
            "hours": 3000, "shorts_90d": 3_000_000},
    "ads": {"name": "Ad revenue", "subs": 1000, "hours": 4000, "shorts_90d": 10_000_000},
    "ads_2027": {"name": "Ad revenue (new rules from 1 Feb 2027)", "subs": 1000, "hours": 8000, "shorts_90d": 20_000_000},
}
API = "https://youtubeanalytics.googleapis.com/v2/reports"


def _report(tok, start, end, metrics, dims=""):
    params = {"ids": "channel==MINE", "startDate": start.isoformat(), "endDate": end.isoformat(), "metrics": metrics}
    if dims:
        params["dimensions"] = dims
    r = httpx.get(API, params=params, headers={"Authorization": f"Bearer {tok}"}, timeout=30)
    if r.status_code == 403:
        raise PermissionError(r.text[:200])
    accounts._check(r, "YouTube Analytics")
    d = r.json()
    names = [h["name"] for h in d.get("columnHeaders", [])]
    return [dict(zip(names, row)) for row in d.get("rows", [])]


def progress(subs, hours, shorts, uploads, tier) -> dict:
    t = TIERS[tier]
    parts = {"subs": min(1.0, subs / t["subs"]), "hours": min(1.0, hours / t["hours"]),
             "shorts": min(1.0, shorts / t["shorts_90d"])}
    ok = subs >= t["subs"] and (hours >= t["hours"] or shorts >= t["shorts_90d"]) and uploads >= t.get("uploads_90d", 0)
    return {"tier": tier, "name": t["name"], "need": t, "ok": ok,
            "percent": round(100 * min(parts["subs"], max(parts["hours"], parts["shorts"]))), "parts": parts}


def report(aid: str, today=None) -> dict:
    acc = accounts.get(aid)
    if not acc or acc["platform"] != "youtube":
        raise KeyError(aid)
    tok = accounts._yt_token(acc)
    today = today or dt.date.today()
    end = today - dt.timedelta(days=1)
    ch = accounts._check(httpx.get("https://www.googleapis.com/youtube/v3/channels",
                                   params={"part": "statistics", "mine": "true"},
                                   headers={"Authorization": f"Bearer {tok}"}, timeout=30), "Reading the channel").json()
    st = (ch.get("items") or [{}])[0].get("statistics", {})
    subs = int(st.get("subscriberCount", 0) or 0)
    out = {"account": acc["name"], "subs": subs, "videos": int(st.get("videoCount", 0) or 0), "needs_reconnect": False}
    try:
        by = _report(tok, today - dt.timedelta(days=365), end, "views,estimatedMinutesWatched", "creatorContentType")
        hours = sum(float(r.get("estimatedMinutesWatched", 0)) for r in by if r.get("creatorContentType") != "SHORTS") / 60
        s90 = _report(tok, today - dt.timedelta(days=90), end, "views", "creatorContentType")
        shorts = sum(int(r.get("views", 0)) for r in s90 if r.get("creatorContentType") == "SHORTS")
        last28 = _report(tok, today - dt.timedelta(days=28), end, "views,estimatedMinutesWatched,subscribersGained,subscribersLost")
        out.update(hours_365d=round(hours), shorts_90d=shorts, last_28=last28[0] if last28 else {})
    except PermissionError:
        out["needs_reconnect"] = True
        return out
    try:
        money = _report(tok, today - dt.timedelta(days=28), end, "estimatedRevenue,estimatedAdRevenue,cpm,playbackBasedCpm")
        out["earnings_28d"] = money[0] if money else {}
        out["monetized"] = True
    except (PermissionError, RuntimeError):
        out["monetized"] = False         # not in YPP yet (or the money box wasn't ticked when connecting)
    uploads = min(out["videos"], 3)       # (uploads in 90 days: the channel count is a stand-in when unknown)
    tiers = ["fan", "ads" if today < CHANGE_DAY else "ads_2027"]
    if today < CHANGE_DAY:
        tiers.append("ads_2027")
    out["ypp"] = [progress(subs, out["hours_365d"], shorts, uploads, t) for t in tiers]
    return out
