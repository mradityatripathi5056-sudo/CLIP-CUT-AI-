"""Clip Cut AI web server. Run with:  python -m studio.server

Public pages:  /  /login  /signup          The app:  /app  (signed-in users only)
Everything under /api, /media and /oauth needs a session, except /api/auth/* and /api/public."""
import contextlib
import hashlib
import hmac
import ipaddress
import json
import os
import re
import shutil
import threading
import time
from pathlib import Path
from urllib.parse import quote, urlparse

import sqlalchemy as sa
import uvicorn
from fastapi import Body, FastAPI, File, Form, HTTPException, Request, UploadFile
from fastapi.concurrency import run_in_threadpool
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, RedirectResponse, Response

from . import admin as admins
from . import account, load
from . import (accounts, ai, alerts, auth, brain, config, creators, ctx, db, jobs, live, media, posting,
               profiles, render, safe, transcribe, usage)

from . import tools as _tools  # noqa: E402


def _quiet(fn):
    try:
        fn()
    except Exception as e:  # noqa: BLE001 - said again, in plain words, when a video needs it
        print(f"  {e}", flush=True)


app = FastAPI(title="Clip Cut AI", docs_url=None, redoc_url=None, openapi_url=None)
WEB = config.ROOT / "web"
OPEN = ("/api/auth/", "/pub/", "/api/public", "/auth/google/", "/auth/verify", "/brand/", "/assets/", "/healthz", "/favicon.ico", "/robots.txt", "/sitemap.xml",
        "/manifest.webmanifest", "/sw.js", "/go/", "/c/")
PAGES = {"/": "landing.html", "/login": "auth.html", "/signup": "auth.html", "/reset": "reset.html",
         "/privacy": "legal.html", "/terms": "legal.html", "/acceptable-use": "legal.html"}
VIDEO_TYPES = {".mp4", ".mov", ".mkv", ".webm", ".m4v", ".ts", ".flv"}
CSP = ("default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; "
       "font-src 'self' https://fonts.gstatic.com; img-src 'self' data: https://i.ytimg.com; media-src 'self' blob:; connect-src 'self'; "
       "frame-src https://player.twitch.tv https://www.youtube-nocookie.com https://player.kick.com; "
       "frame-ancestors 'none'; base-uri 'self'; form-action 'self' https://accounts.google.com")


BOOT = f"{int(time.time()) % 100000:x}"     # part of every sync token, so pages reload their data after a restart


@app.on_event("startup")
async def _more_threads():
    import anyio.to_thread
    anyio.to_thread.current_default_thread_limiter().total_tokens = int(config.env("CLIPCUT_REQUEST_THREADS", "64"))


@app.on_event("startup")
def _startup():
    db.init()
    for f in (config.TMP_DIR / "uploads").glob("*"):      # uploads cut short by a restart
        try:
            f.unlink()
        except OSError:
            pass
    render.install_fonts()
    if _tools.missing():
        print("\n  " + _tools.HELP + "\n", flush=True)
    if not transcribe.REMOTE and config.env("CLIPCUT_FETCH_MODEL", "1") != "0":     # the speech model: fetched now, in the background, if it was never downloaded
        from . import fetch_model
        threading.Thread(target=lambda: _quiet(fetch_model.ensure), daemon=True).start()
    jobs.start()
    live.start()
    posting.start()
    from . import mailsetup
    mailsetup.apply()                # email details saved in Settings, Login
    from . import autopilot, limits, tunnel
    tunnel.start()                   # online with ngrok, when switched on (Settings, Online)
    threading.Thread(target=_startup_sweep, daemon=True).start()
    autopilot.start()
    limits.start()                   # daily limits: checks each page now, then every 2 hours
    from . import growth
    growth.start()                   # best times, second titles, reposting hits, the weekly report
    from . import autofetch
    autofetch.start()                # new uploads on creators' channels, clipped by themselves
    from . import manager
    manager.start()                  # the AI Manager's hourly round, when switched on
    from . import telebot
    telebot.start()                  # Telegram buttons for new clips and comment replies, when switched on
    from . import replies
    replies.start()                  # replies to comments, when switched on in Comments
    from . import backup
    backup.start()                   # a backup of settings, accounts, creators and posts, once a day
    from . import updates
    updates.start()                  # looks for a newer Clip Cut AI every minute, in the background


# ================================================================ the gate: who is asking, and are they allowed
class Gate:
    """Runs before every request: finds the signed-in user, blocks what needs sign-in, blocks cross-site form
    posts, caps upload size and adds security headers."""

    def __init__(self, app):
        self.inner = app

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http":
            return await self.inner(scope, receive, send)
        req = Request(scope)
        path, method = scope["path"], scope["method"]

        async def deny(status, msg, redirect=None):
            no_keep = {"Cache-Control": "private, no-store"}      # never kept by a browser or CDN
            resp = RedirectResponse(redirect, 303, headers=no_keep) if redirect else JSONResponse({"detail": msg}, status, headers=no_keep)
            await resp(scope, receive, send)

        if method not in ("GET", "HEAD", "OPTIONS"):
            if not _from_here(req):
                return await deny(403, "Cross-site requests are not allowed.")
            # Only the upload may be big. Everything else is a small form, and is cut off at 256 KB whatever its
            # headers claim, so nobody can fill the server's memory by posting junk (signed in or not).
            piece = method == "PUT" and path.startswith("/api/upload/")
            cap = ((min(config.MAX_UPLOAD_MB, config.UPLOAD_PART_MB) if piece else config.MAX_UPLOAD_MB) + 8) * 1024 * 1024 \
                if path == "/api/upload" or piece else 256 * 1024
            try:
                if int(req.headers.get("content-length") or 0) > cap:
                    return await deny(413, f"That file is too big. The limit is {config.MAX_UPLOAD_MB} MB." if path == "/api/upload" else "That request is too large.")
            except ValueError:
                return await deny(400, "Bad request.")
            seen, inner_receive = 0, receive

            async def receive():
                nonlocal seen
                m = await inner_receive()
                if m["type"] == "http.request":
                    seen += len(m.get("body", b""))
                    if seen > cap:
                        raise HTTPException(413, "That request is too large.")
                return m

        is_open = path in PAGES or any(path.startswith(p) for p in OPEN)
        admin_area = path == "/admin" or path.startswith(("/admin/", "/api/admin/"))
        if config.ACCOUNTS:
            cookie = req.cookies.get(auth.COOKIE, "")
            user = auth._sess.get(auth._h(cookie)) if cookie and not admin_area else None      # remembered: no database, no thread hop
            user = user[1] if user and time.time() - user[0] < auth.SESS_FOR else (
                await run_in_threadpool(auth.user_for, cookie, admin_area) if cookie else None)
        else:
            # No sign-in: whoever opens the page is the owner. Because nothing else stands in the way, the page
            # must have been asked for by its real address (a number, "localhost", or the address in settings),
            # so another website cannot reach it through a made-up name that points at this machine.
            if not _own_address(req.headers.get("host", "")):
                return await deny(403, "Open Clip Cut AI by its own address.")
            if path == "/" or path == "/reset" or path.startswith("/auth/"):
                return await deny(303, "", redirect="/app")
            if path.startswith("/api/auth/") and path != "/api/auth/me":
                return await deny(404, "Not Found")
            user = auth._local or await run_in_threadpool(auth.local_user)
        if admin_area:
            # The admin area does not exist for anyone else: same "not found" whether signed out or a normal user.
            if not user or not user.is_admin:
                return await deny(404, "Not Found")
            if method not in ("GET", "HEAD"):
                # changes must come from our own pages: the browser has to say so, and it has to match
                if not _from_here(req, must_say=True):
                    return await deny(403, "Cross-site requests are not allowed.")
        if not user and not is_open:
            if path == "/app" or path.startswith("/app/"):
                return await deny(401, "", redirect="/login")
            return await deny(401, "Please sign in.")
        if user and path in ("/login", "/signup"):
            return await deny(303, "", redirect="/app")
        scope.setdefault("state", {})["user"] = user
        if user and path in ("/api/upload", "/api/upload/start") and method == "POST":
            # decided before a single byte of the file is accepted: verified, has a free slot, has disk space
            def allowed():
                from . import team
                with ctx.as_user(team.workspace_of(user)):
                    _need_verified(); _job_slots(); _quota()                     # noqa: E702
            try:
                await run_in_threadpool(allowed)
            except HTTPException as e:
                return await deny(e.status_code, e.detail)
        if user and path.startswith("/api/") and not auth.seen_recently(user.id):
            await run_in_threadpool(auth.touch, user.id)

        unchanged = False

        async def send_with_headers(message):
            nonlocal unchanged
            if unchanged:                       # the browser's copy is current: send no body at all
                if message["type"] == "http.response.body" and not message.get("more_body"):
                    await send({"type": "http.response.body", "body": b""})
                return
            if message["type"] == "http.response.start":
                h = message.setdefault("headers", [])
                if method == "GET" and message.get("status") == 200:
                    tag = next((v.decode("latin-1") for k, v in h if k.lower() == b"etag"), "")
                    have = req.headers.get("if-none-match", "")
                    if tag and have and tag.removeprefix("W/") in [x.strip().removeprefix("W/") for x in have.split(",")]:
                        unchanged = True
                        message["status"] = 304
                        h[:] = [(k, v) for k, v in h if k.lower() not in (b"content-length", b"content-type", b"content-encoding")]
                h += [(b"x-content-type-options", b"nosniff"), (b"x-frame-options", b"DENY"),
                      (b"referrer-policy", b"strict-origin-when-cross-origin"), (b"content-security-policy", CSP.encode()),
                      (b"permissions-policy", b"camera=(), microphone=(), geolocation=()")]
                if config.HTTPS:
                    h.append((b"strict-transport-security", b"max-age=31536000; includeSubDomains"))
                if path.startswith("/api/"):
                    h.append((b"cache-control", b"no-store"))
                elif message.get("status", 200) >= 300 and not any(k.lower() == b"cache-control" for k, _ in h):
                    # redirects and errors are never kept by a CDN: a "not found" for a clip that is still being
                    # made, or a sign-in redirect, must not be shown to anyone later
                    h.append((b"cache-control", b"private, no-store"))
                if path.startswith(("/app", "/admin", "/api/", "/auth/", "/reset", "/media/")):
                    h.append((b"x-robots-tag", b"noindex, nofollow"))
            await send(message)

        from . import team
        if user and path.startswith("/api/") and not team.allowed(user, path, method):
            return await JSONResponse({"detail": "Your role in this team (editor) can't change this. Ask the owner."},
                                      403)(scope, receive, send_with_headers)
        token = ctx._uid.set(team.workspace_of(user) if user else None)     # a teammate works in the owner's workspace
        try:
            if user and path == "/api/sync" and method == "GET":
                # By far the most common request. When nothing of this user's changed it is answered right here:
                # no worker thread, no database, no disk. Anything else falls through to the normal route.
                quick = _sync_unchanged(req.query_params.get("v", ""))
                if quick is not None:
                    return await JSONResponse(quick)(scope, receive, send_with_headers)
            await self.inner(scope, receive, send_with_headers)
        finally:
            ctx._uid.reset(token)


app.add_middleware(Gate)


class Compress:
    """gzip for text responses. Videos and images are already compressed and need byte ranges, so they pass through."""
    def __init__(self, app):
        from starlette.middleware.gzip import GZipMiddleware
        self.plain, self.gzip = app, GZipMiddleware(app, minimum_size=800, compresslevel=6)

    async def __call__(self, scope, receive, send):
        path = scope.get("path", "") if scope["type"] == "http" else ""
        media = path.startswith(("/media/", "/api/upload")) or path.endswith((".mp4", ".jpg", ".png", ".webp", ".ico"))
        await (self.plain if scope["type"] != "http" or media else self.gzip)(scope, receive, send)


app.add_middleware(Compress)


# Cloudflare's published address ranges (cloudflare.com/ips). CLIPCUT_CDN_RANGES replaces them if they ever change.
_CDN_RANGES = None


def _from_cdn(addr: str) -> bool:
    global _CDN_RANGES
    import ipaddress
    if _CDN_RANGES is None:
        ranges = config.env("CLIPCUT_CDN_RANGES") or (
            "173.245.48.0/20 103.21.244.0/22 103.22.200.0/22 103.31.4.0/22 141.101.64.0/18 108.162.192.0/18 "
            "190.93.240.0/20 188.114.96.0/20 197.234.240.0/22 198.41.128.0/17 162.158.0.0/15 104.16.0.0/13 "
            "104.24.0.0/14 172.64.0.0/13 131.0.72.0/22 2400:cb00::/32 2606:4700::/32 2803:f800::/32 2405:b500::/32 "
            "2405:8100::/32 2a06:98c0::/29 2c0f:f248::/32")
        _CDN_RANGES = [ipaddress.ip_network(r) for r in ranges.replace(",", " ").split()]
    try:
        ip = ipaddress.ip_address(addr)
    except ValueError:
        return False
    return any(ip in n for n in _CDN_RANGES)


# Private and local addresses: the only places a reverse proxy in front of Clip Cut AI can sit.
_PROXY_CIDRS = ("127.0.0.0/8", "10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "100.64.0.0/10", "169.254.0.0/16",
                "::1/128", "fc00::/7", "fe80::/10")
_PROXY_RANGES = [ipaddress.ip_network(r) for r in _PROXY_CIDRS]


def _trust_proxy() -> bool:
    return (config.env("CLIPCUT_TRUST_PROXY") or "").strip().lower() not in ("", "0", "false", "no")


def _valid_ip(text: str) -> str:
    """The address as text if it really is an IP address, otherwise ""."""
    try:
        ip = ipaddress.ip_address(text)
    except ValueError:
        return ""
    if isinstance(ip, ipaddress.IPv6Address) and ip.ipv4_mapped:
        ip = ip.ipv4_mapped
    return str(ip)


def _from_proxy(addr: str) -> bool:
    clean = _valid_ip(addr)
    if not clean:
        return False
    ip = ipaddress.ip_address(clean)
    return any(ip in n for n in _PROXY_RANGES)


def _ip(request: Request) -> str:
    """The visitor's address, used for rate limits. The connection's own address, or the one the proxy in front
    reports (CLIPCUT_TRUST_PROXY). If that connection comes from the CDN, the CDN's header names the real visitor
    (CLIPCUT_CLIENT_IP_HEADER). The header is believed only when the CDN really sent the request, so nobody can
    pick their own address by sending it themselves.

    The proxy adds the address it saw at the END of X-Forwarded-For. Everything before that was written by the
    visitor, so only the last entry is believed, and only when the connection came from a proxy on a private address."""
    direct = request.client.host if request.client else ""
    peer = direct
    fwd = ",".join(request.headers.getlist("x-forwarded-for"))
    if _trust_proxy() and fwd and _from_proxy(direct):
        peer = _valid_ip(fwd.rsplit(",", 1)[-1].strip()) or direct
    named = config.env("CLIPCUT_CLIENT_IP_HEADER")
    if named and request.headers.get(named) and _from_cdn(peer):
        return _valid_ip(request.headers[named].split(",")[0].strip()[:64]) or peer
    return peer


def _from_here(req, must_say=False) -> bool:
    """Did this change come from Clip Cut AI's own page, and not from another website?

    The browser's own answer is trusted first: it marks every request "same-origin" or not, and a web page cannot
    fake that mark. Comparing the page's address with the address the request arrived at is only the fallback,
    because that comparison goes wrong when something in between rewrites either of them (a proxy, an antivirus
    web shield, a browser extension), which made every save fail with "Cross-site requests are not allowed"."""
    if (req.headers.get("sec-fetch-site") or "").lower() == "same-origin":
        return True
    origin = (req.headers.get("origin") or "").rstrip("/").lower()
    if not origin:
        return not must_say
    return urlparse(origin).netloc == (req.headers.get("host") or "").lower() or origin == config.PUBLIC_URL.lower()


def _own_address(host: str) -> bool:
    """Is this the address Clip Cut AI is really reached by? A number (127.0.0.1, 192.168.1.20), "localhost", or the
    host in CLIPCUT_PUBLIC_URL."""
    import ipaddress
    name = host.strip().lower()
    name = name[1:name.index("]")] if name.startswith("[") and "]" in name else name.rsplit(":", 1)[0] if ":" in name else name
    if name in ("localhost", urlparse(config.PUBLIC_URL).hostname or "") or name.endswith(".localhost"):
        return True
    try:
        ipaddress.ip_address(name)
        return True
    except ValueError:
        return False


def _me(request: Request):
    return request.state.user


def _admin(request: Request):
    """The signed-in admin, read from the database for this very request. Anyone else gets "not found"."""
    u = getattr(request.state, "user", None)
    if not u or not u.is_admin or u.disabled:
        raise HTTPException(404)
    return u


def _need_verified():
    if not auth.is_verified(ctx.uid()):
        raise HTTPException(403, "Confirm your email first. We sent you a link when you signed up; you can send a new one from the banner at the top.")


# ================================================================ pages
def _page(name, shared=False):
    """A page. The browser keeps its copy and asks each time whether it has changed; when it has not, the answer
    is a few bytes ("not modified") instead of the whole page again. Signed-in pages are never kept by anything
    in between (a proxy or CDN), only by the person's own browser."""
    return FileResponse(WEB / name, headers={"Cache-Control": ("public" if shared else "private") + ", no-cache"})


_LANDING: dict = {}


@app.get("/")
def landing():
    f = WEB / "landing.html"
    m = f.stat().st_mtime
    if _LANDING.get("m") != m:
        html = f.read_text(encoding="utf-8").replace("{{SITE}}", config.PUBLIC_URL)
        _LANDING.update(m=m, html=html, etag='"' + hashlib.md5(html.encode()).hexdigest() + '"')
    # fresh for five minutes; after that a CDN or browser may show its copy while it quietly fetches the new one
    return HTMLResponse(_LANDING["html"], headers={"Cache-Control": "public, max-age=300, stale-while-revalidate=86400",
                                                   "ETag": _LANDING["etag"]})


@app.get("/robots.txt")
def robots():
    return Response("User-agent: *\nAllow: /\nDisallow: /app\nDisallow: /api/\nDisallow: /auth/\nDisallow: /reset\nDisallow: /media/\n"
                    f"\nSitemap: {config.PUBLIC_URL}/sitemap.xml\n", media_type="text/plain",
                    headers={"Cache-Control": "public, max-age=86400"})


@app.get("/sitemap.xml")
def sitemap():
    day = time.strftime("%Y-%m-%d")
    pages = [("/", "1.0", "weekly"), ("/signup", "0.8", "monthly"), ("/login", "0.4", "monthly"), ("/terms", "0.3", "yearly"),
             ("/privacy", "0.3", "yearly"), ("/acceptable-use", "0.2", "yearly")]
    body = "".join(f"<url><loc>{config.PUBLIC_URL}{u}</loc><lastmod>{day}</lastmod><changefreq>{c}</changefreq>"
                   f"<priority>{p}</priority></url>" for u, p, c in pages)
    return Response('<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'
                    + body + "</urlset>", media_type="application/xml", headers={"Cache-Control": "public, max-age=86400"})


@app.get("/login")
@app.get("/signup")
def auth_page():
    return _page("auth.html", shared=True)


@app.get("/reset")
def reset_page():
    return _page("reset.html", shared=True)


LEGAL = {
    "privacy": ("Privacy Policy", "How Clip Cut AI collects, uses and protects your data, including Google user data, cookies and your privacy rights."),
    "terms": ("Terms of Service", "The terms for using Clip Cut AI, the AI clipping tool for streams and videos: accounts, availability and liability."),
    "acceptable-use": ("Acceptable Use Policy", "What you may and may not do with Clip Cut AI, the AI stream clipping tool."),
}


@app.get("/privacy")
@app.get("/terms")
@app.get("/acceptable-use")
def legal_page(request: Request):
    """Public, so Google's app review (and anyone) can read them. Business name, law and contact come from settings."""
    import html as _h
    page = request.url.path.strip("/")
    title, desc = LEGAL[page]
    contact = config.CONTACT_EMAIL
    who = (f'<a href="mailto:{_h.escape(contact)}">{_h.escape(contact)}</a>' if contact
           else "the contact details on our website")
    name = _h.escape(config.LEGAL_NAME or "Clip Cut AI")
    law = (f"the laws of {_h.escape(config.LEGAL_COUNTRY)}" if config.LEGAL_COUNTRY
           else "the laws of the country where Clip Cut AI's operator is established")
    out = (_LEGAL_HTML or (WEB / "legal.html").read_text(encoding="utf-8"))
    for k, v in {"{{CONTACT}}": who, "{{PAGE}}": page, "{{PAGE_PATH}}": page, "{{SITE}}": _h.escape(config.PUBLIC_URL),
                 "{{NAME}}": name, "{{LAW}}": law, "{{TITLE}}": title, "{{DESC}}": desc}.items():
        out = out.replace(k, v)
    return HTMLResponse(out, headers={"Cache-Control": "public, max-age=3600"})


_LEGAL_HTML = ""


@app.get("/app")
@app.get("/app/{rest:path}")
def app_page(rest: str = ""):
    """Every app address (/app/videos, /app/creators/<id>/setup ...) is the same page; it shows the right view."""
    return _page("index.html")


@app.get("/admin")
@app.get("/admin/{rest:path}")
def admin_page(request: Request, rest: str = ""):
    _admin(request)
    return _page("admin.html")


@app.get("/healthz")
def healthz():
    with db.engine.connect() as c:
        c.execute(sa.text("select 1"))
    return {"ok": True}


@app.get("/manifest.webmanifest")
def manifest():
    """What a phone needs to put Clip Cut AI on its home screen."""
    return FileResponse(WEB / "manifest.webmanifest", media_type="application/manifest+json",
                        headers={"Cache-Control": "public, max-age=86400"})


@app.get("/sw.js")
def service_worker():
    return FileResponse(WEB / "sw.js", media_type="text/javascript", headers={"Cache-Control": "no-cache", "Service-Worker-Allowed": "/"})


@app.get("/brand/{name}")
def brand(name: str):
    if not re.fullmatch(r"[\w\-]+\.(svg|png|ico|webp|jpg|mp4)", name) or not (WEB / "brand" / name).is_file():
        raise HTTPException(404)
    return FileResponse(WEB / "brand" / name, headers={"Cache-Control": "public, max-age=604800, stale-while-revalidate=86400"})


@app.get("/assets/{name}")
def asset(name: str):
    if not re.fullmatch(r"[\w\-]+\.js", name) or not (WEB / name).is_file():
        raise HTTPException(404)
    return FileResponse(WEB / name, media_type="text/javascript", headers={"Cache-Control": "public, max-age=86400, stale-while-revalidate=604800"})


@app.get("/favicon.ico")
def favicon():
    return RedirectResponse("/brand/favicon.svg", 308)


# ================================================================ sign up, sign in, sign out
@app.get("/api/public")
def public_config():
    from . import mailer
    return {"google": auth.google_ready(), "mail": mailer.ready(), "verify_email": config.VERIFY_EMAIL}


def _signed_in(request: Request, user, first: bool, redirect=None):
    token = auth.start_session(user.id, _ip(request), request.headers.get("user-agent", ""))
    resp = RedirectResponse(redirect, 303) if redirect else JSONResponse({"user": auth.public(user)})
    resp.set_cookie(**auth.cookie_args(token))
    return resp


@app.post("/api/auth/signup")
def signup(request: Request, body: dict = Body(...)):
    try:
        auth.throttle("signup:" + _ip(request), 8, 3600)
        user, first = auth.signup(str(body.get("email", "")), str(body.get("password", "")), str(body.get("name", "")))
    except auth.AuthError as e:
        raise HTTPException(400, str(e))
    if not auth.is_verified(user.id):
        auth.send_verify(user)
    return _signed_in(request, user, first)


@app.post("/api/auth/resend-verification")
def resend_verification(request: Request):
    u = _me(request)
    if not u:
        raise HTTPException(401, "Please sign in.")
    if auth.is_verified(u.id):
        return {"verified": True}
    try:
        auth.throttle("verify:" + u.id, 3, 900)
    except auth.AuthError:
        raise HTTPException(429, "We've sent a few already. Check your spam folder, or try again in 15 minutes.")
    from . import mailer
    return {"sent": auth.send_verify(u), "mail_ready": mailer.ready()}


@app.get("/auth/verify")
def verify_email(request: Request, t: str = ""):
    try:
        auth.verify_link(t)
    except auth.AuthError as e:
        return RedirectResponse("/app?verify_error=" + quote(str(e)), status_code=303)
    return RedirectResponse("/app?verified=1", status_code=303)


@app.post("/api/auth/forgot")
def forgot_password(request: Request, body: dict = Body(...)):
    email = str(body.get("email", "")).strip().lower()
    try:
        auth.throttle("forgot-ip:" + _ip(request), 10, 3600)
        auth.throttle("forgot:" + email, 3, 3600)
    except auth.AuthError as e:
        raise HTTPException(429, str(e))
    auth.forgot(email)
    return {"ok": True}   # the same answer whether or not the account exists


@app.post("/api/auth/reset")
def reset_password(request: Request, body: dict = Body(...)):
    try:
        auth.throttle("reset-ip:" + _ip(request), 20, 3600)
        user = auth.reset_password(str(body.get("token", "")), str(body.get("password", "")))
    except auth.AuthError as e:
        raise HTTPException(400, str(e))
    return _signed_in(request, user, False)


@app.post("/api/auth/login")
def login(request: Request, body: dict = Body(...)):
    email = str(body.get("email", ""))
    try:
        auth.throttle("login-ip:" + _ip(request), 30, 600)
        auth.throttle(f"login:{email.strip().lower()[:254]}:{_ip(request)}", 8, 600)
        auth.throttle("login:" + email.strip().lower()[:254], 60, 600)
        user = auth.login(email, str(body.get("password", "")))
    except auth.AuthError as e:
        raise HTTPException(400, str(e))
    from . import mailer, mailsetup, team
    with ctx.as_user(team.workspace_of(user)):
        two_step = bool(accounts.settings().get("two_step"))
    if two_step and mailer.ready():   # (if email stops working, the password alone still signs in: nobody is locked out)                      # the password was right; now a code sent to their email
        try:
            ticket = mailsetup.send_code(user.email, "sign in", {"uid": user.id})
        except RuntimeError as e:
            raise HTTPException(503, str(e))
        return {"two_step": True, "ticket": ticket, "to": mailsetup.mask(user.email)}
    return _signed_in(request, user, False)


@app.post("/api/auth/code")
def login_code(request: Request, body: dict = Body(...)):
    """The second step of signing in: the code from the email."""
    from . import mailsetup
    auth.throttle("code-ip:" + _ip(request), 30, 600)
    try:
        data = mailsetup.check_code(str(body.get("ticket", "")), str(body.get("code", "")), "sign in")
    except ValueError as e:
        raise HTTPException(400, str(e))
    user = auth.get_user(data["uid"])
    if not user or user.disabled:
        raise HTTPException(400, "That account can't sign in.")
    return _signed_in(request, user, False)


@app.post("/api/auth/logout")
def logout(request: Request):
    auth.end_session(request.cookies.get(auth.COOKIE, ""))
    resp = JSONResponse({"ok": True})
    resp.delete_cookie(auth.COOKIE, path="/")
    return resp


@app.get("/api/auth/me")
def me(request: Request):
    return {"user": auth.public(_me(request)) if _me(request) else None}


@app.post("/api/auth/password")
def change_password(request: Request, body: dict = Body(...)):
    if not _me(request):
        raise HTTPException(401, "Please sign in.")
    try:
        auth.throttle("pw:" + _me(request).id, 6, 600)
        auth.change_password(_me(request).id, str(body.get("current", "")), str(body.get("new", "")),
                             keep_token=request.cookies.get(auth.COOKIE, ""))
    except auth.AuthError as e:
        raise HTTPException(400, str(e))
    return {"ok": True}


@app.get("/api/owner-login")
def owner_login_get(request: Request):
    """While sign-in is off: whether the owner has an email and password ready for when sign-in is switched on."""
    _admin(request)
    u = auth.get_user(auth.owner_id())
    ready = bool(u and u.password_hash and auth.EMAIL_RE.match(u.email or ""))
    return {"ready": ready, "email": u.email if ready else "", "accounts_on": bool(config.ACCOUNTS)}


@app.put("/api/owner-login")
def owner_login_put(request: Request, body: dict = Body(...)):
    """Save the owner's login. When email is set up, the email is checked first: a code is sent to it, and the
    login is saved only with that code, so the account can always be recovered through that inbox."""
    from . import mailer, mailsetup
    _admin(request)
    if config.ACCOUNTS:
        raise HTTPException(400, "Sign-in is already on. Change your password in Settings, Security.")
    try:
        auth.throttle("ownerlogin", 10, 600)
        if body.get("ticket"):
            data = mailsetup.check_code(str(body["ticket"]), str(body.get("code", "")), "check your email for Clip Cut AI")
            u = auth.set_owner_login(data["email"], data["password"], data["name"])
            auth.mark_verified(u["id"])
            ctx.bump()
            return {"ready": True, "email": u["email"], "accounts_on": False, "verified": True}
        if str(body.get("password", "")) != str(body.get("again", "")):
            raise auth.AuthError("The two passwords are not the same.")
        email, pw, name = str(body.get("email", "")).strip().lower(), str(body.get("password", "")), str(body.get("name", ""))
        if not auth.EMAIL_RE.match(email):
            raise auth.AuthError("Enter a valid email address.")
        auth._check_password_rules(pw)
        if mailer.ready():
            ticket = mailsetup.send_code(email, "check your email for Clip Cut AI", {"email": email, "password": pw, "name": name})
            return {"need_code": True, "ticket": ticket, "to": mailsetup.mask(email)}
        u = auth.set_owner_login(email, pw, name)
    except (auth.AuthError, ValueError, RuntimeError) as e:
        raise HTTPException(400, str(e))
    ctx.bump()
    return {"ready": True, "email": u["email"], "accounts_on": False, "verified": False}


@app.get("/api/online")
def online_get(request: Request):
    from . import tunnel
    _admin(request)
    return tunnel.public()


@app.put("/api/online")
def online_put(request: Request, body: dict = Body(...)):
    from . import tunnel
    _admin(request)
    try:
        out = tunnel.save(str(body.get("token", "")), str(body.get("domain", "")), bool(body.get("enabled")))
        if "autostart" in body:
            tunnel.set_autostart(bool(body["autostart"]))
            out = tunnel.public()
    except ValueError as e:
        raise HTTPException(400, str(e))
    return out


@app.post("/api/restart")
def restart(request: Request):
    """Close and start again (START-WINDOWS.bat / ClipCutAI.exe start it again when it exits with RESTART_CODE)."""
    _admin(request)

    def bye():
        time.sleep(1.5)
        os._exit(RESTART_CODE)
    threading.Thread(target=bye, daemon=True).start()
    return {"restarting": True}


@app.get("/api/mail-setup")
def mail_setup_get(request: Request):
    from . import mailsetup
    _admin(request)
    return mailsetup.public()


@app.put("/api/mail-setup")
def mail_setup_put(request: Request, body: dict = Body(...)):
    from . import mailsetup
    _admin(request)
    try:
        return mailsetup.save(str(body.get("host", "")), body.get("port"), str(body.get("user", "")),
                              str(body.get("password", "")), str(body.get("from", "")))
    except ValueError as e:
        raise HTTPException(400, str(e))


@app.post("/api/mail-setup/test")
def mail_setup_test(request: Request):
    from . import mailer
    me_ = _admin(request)
    _throttle("mailtest:" + ctx.uid(), 5, 600)
    to = me_.email if auth.EMAIL_RE.match(me_.email or "") else config.MAIL_FROM
    ok = mailer.send(to, "Clip Cut AI: email works", "Email works", "Clip Cut AI can send you codes and backups now.",
                     "Open Clip Cut AI", config.PUBLIC_URL or "http://127.0.0.1:8765", "")
    if not ok:
        raise HTTPException(502, "The email couldn't be sent. Check the address and the app password.")
    return {"sent_to": to}


@app.get("/auth/google/start")
def google_start(next: str = "/app"):
    if not auth.google_ready():
        raise HTTPException(404)
    url, state = auth.google_url(next)
    resp = RedirectResponse(url)
    # the sign-in can only be finished by the browser that started it
    resp.set_cookie("g_state", state, max_age=900, httponly=True, samesite="lax", secure=config.HTTPS, path="/auth/google")
    return resp


@app.get("/auth/google/callback")
def google_callback(request: Request, code: str = "", state: str = "", error: str = ""):
    if error or not code or not state or not hmac.compare_digest(request.cookies.get("g_state", ""), state):
        return RedirectResponse("/login?error=google", 303)
    try:
        auth.throttle("google:" + _ip(request), 30, 600)
        user, first, nxt = auth.google_finish(code, state)
    except auth.AuthError:
        return RedirectResponse("/login?error=google", 303)
    return _signed_in(request, user, first, redirect=nxt)


# ================================================================ app status
@app.get("/api/status")
def status(request: Request):
    from . import notices
    from . import updates
    me_ = _me(request)
    return {"user": auth.public(me_), "update": updates.latest() if me_.is_admin else None, "accounts": config.ACCOUNTS, "disk_full": load.disk_full(), "no_ffmpeg": bool(_tools.missing()), "links": {"repo": config.REPO_URL, "follow": config.FOLLOW_URL}, "ai": usage.brief(), "unread": notices.unread(),
            "tour": not accounts.settings()["tour_done"],
            "youtube": accounts.youtube_ready(), "connect": {p: accounts.can_connect(p) for p in accounts.CONNECT_PLATFORMS}, "max_upload_mb": config.MAX_UPLOAD_MB, "upload_part_mb": config.UPLOAD_PART_MB, "max_batch": config.MAX_ACTIVE_JOBS_PER_USER,
            "styles": {k: v["label"] for k, v in render.STYLES.items()}, "layouts": render.LAYOUTS, "speech": _speech_brief()}


def _speech_brief() -> dict:
    """Which spoken languages can be transcribed here: for the language choice when adding a video."""
    from . import fetch_model
    return {k: {"label": m[0], "size_mb": m[3], "state": fetch_model.status(k)} for k, m in fetch_model.MODELS.items()}


# ================================================================ videos
def _job_or_404(jid: str):
    job = jobs.get(jid) if re.fullmatch(r"[\w\-]{8,60}", jid) else None
    if not job:
        raise HTTPException(404, "No such video")
    return job


def _job_slots():
    from . import tools
    if tools.missing():
        raise HTTPException(503, tools.HELP)
    if jobs.busy_count() >= config.MAX_ACTIVE_JOBS_PER_USER:
        raise HTTPException(429, f"You already have {config.MAX_ACTIVE_JOBS_PER_USER} videos in progress. Wait for one to finish.")


_create_lock = threading.Lock()      # "do I have a free slot?" and "take it" happen together, so bursts cannot slip past the limit
_lookups = threading.BoundedSemaphore(8)   # link and channel previews running at once, whole server
_disk: dict = {}


def _quota():
    """Each account has a fixed amount of disk space. Measured at most once a minute."""
    if load.disk_full():
        from . import storage
        raise HTTPException(507, storage.full_message())
    uid = ctx.uid()
    got = _disk.get(uid)
    if not got or time.time() - got[0] > 60:
        total = 0
        for root, _dirs, files in os.walk(config.user_dir(uid)):
            for f in files:
                try:
                    total += os.path.getsize(os.path.join(root, f))
                except OSError:
                    pass
        got = _disk[uid] = (time.time(), total)
    if got[1] > config.MAX_USER_GB * 1e9:
        raise HTTPException(507, "Your storage is full. Delete some older videos to make room.")


def _throttle(key, limit, window, msg="Too many requests at once. Wait a moment."):
    try:
        auth.throttle(key, limit, window)
    except auth.AuthError:
        raise HTTPException(429, msg)


def _lookup(fn, *a):
    """Run a preview lookup, unless the server is already doing as many as it should."""
    if not _lookups.acquire(blocking=False):
        raise HTTPException(429, "Lots of people are looking things up right now. Try again in a few seconds.")
    try:
        return fn(*a)
    finally:
        _lookups.release()


def _creator_rows():
    out = []
    for c in creators.all_creators():
        if profiles.needs_refresh(c):
            profiles.refresh(c["id"])
        s = live.active_for(c["id"])
        out.append({**c, "live_job": s.job["id"] if s else None, "log": creators.read_log(c["id"], 30)})
    return out


def _sync_token() -> str:
    return f"{BOOT}.{ctx.version()}.{jobs.queue_epoch() if jobs.busy_count() else 0}"


def _sync_unchanged(v: str):
    """{"v": token} if the page is up to date and this user's creators are already in memory, else None."""
    mine = creators._mem.get(ctx.uid())
    if mine is None or not v or v != _sync_token():
        return None
    for c in list(mine.values()):                      # still keep live status fresh while the page is open
        if profiles.needs_refresh(c):
            profiles.refresh(c["id"])
    return {"v": v}


@app.get("/api/sync")
def sync(v: str = ""):
    """What the page asks every couple of seconds. It sends the token it got last time; when nothing of this
    user's has changed, the answer is just that token: no files read, nothing built."""
    token = _sync_token()
    if v == token:
        return _sync_unchanged(v) or {"v": token}
    from . import notices
    return {"v": token, "jobs": [jobs.public(j) for j in jobs.list_jobs()], "creators": _creator_rows(),
            "accounts": accounts.list_accounts(), "ai": usage.brief(), "unread": notices.unread()}


@app.get("/api/jobs")
def list_jobs():
    return [jobs.public(j) for j in jobs.list_jobs()]


@app.get("/api/jobs/{jid}")
def get_job(jid: str):
    return jobs.public(_job_or_404(jid))


@app.get("/api/preview")
def link_preview(request: Request, url: str = ""):
    url = url.strip()[:500]
    if not media.site_allowed(url):
        raise HTTPException(400, "Paste a full link to a YouTube, Twitch or Kick video.")
    try:
        auth.throttle(f"preview:{_me(request).id}", 12, 60)
    except auth.AuthError:
        raise HTTPException(429, "Too many links at once. Wait a moment.")
    try:
        return _lookup(media.preview, url)
    except media.YouTubeBlocked as e:
        raise HTTPException(503, str(e))
    except ValueError as e:
        raise HTTPException(422, str(e))
    except HTTPException:
        raise
    except Exception:
        raise HTTPException(422, "Couldn't open that video. Check the link is public and complete.")


@app.post("/api/jobs")
def create_from_link(body: dict = Body(...)):
    _need_verified()
    _quota()
    _throttle("newjob:" + ctx.uid(), 30, 600)
    url = str(body.get("url", "")).strip()[:500]
    if not media.site_allowed(url):
        raise HTTPException(400, "Paste a full link to a YouTube, Twitch or Kick video.")
    from . import autofetch
    if autofetch.is_list_link(url):          # a channel or playlist link: clip its newest finished video
        try:
            url = autofetch.newest_video(url)["url"]
        except Exception:  # noqa: BLE001
            raise HTTPException(400, "That's a channel link and its newest video couldn't be read. Use Pick a video, "
                                     "or paste the link of one video.")
    try:
        media.check_youtube(url)          # YouTube is refusing us right now: say so, rather than queue a job that fails
    except media.YouTubeBlocked as e:
        raise HTTPException(503, str(e))
    creator = str(body.get("creator") or "") or None
    if creator and not creators.get(creator):
        raise HTTPException(404, "No such creator")
    try:
        with _create_lock:
            _job_slots()
            job = jobs.create({"type": "url", "url": url, "name": url}, body.get("options") or {}, creator=creator)
    except (ValueError, TypeError) as e:
        raise HTTPException(400, str(e) if isinstance(e, ValueError) else "Those options aren't valid.")
    seen = media._PREVIEWS.get(url)  # already looked up while the user was typing: show it straight away
    if seen:
        job.update(title=seen["title"], uploader=seen["uploader"], duration=seen["duration"])
        if media.save_thumb(jobs.job_dir(job["id"]), url=url):
            job["thumb"] = True
        jobs.save(job)
    return jobs.public(job)


@app.post("/api/upload")
def create_from_file(file: UploadFile = File(...), options: str = Form("{}"), creator: str = Form("")):
    _need_verified()
    _job_slots()
    name = re.sub(r"[^\w.\- ]", "_", Path(file.filename or "video.mp4").name)[:120]
    ext = Path(name).suffix.lower()
    if ext not in VIDEO_TYPES:
        raise HTTPException(400, "Upload a video file (mp4, mov, mkv or webm).")
    if creator and not creators.get(creator):
        raise HTTPException(404, "No such creator")
    try:
        opts = json.loads(options)
        opts = opts if isinstance(opts, dict) else {}
    except ValueError:
        opts = {}
    updir = config.TMP_DIR / "uploads"
    updir.mkdir(exist_ok=True)
    tmp = updir / f"{os.urandom(8).hex()}{ext}"
    limit, size = config.MAX_UPLOAD_MB * 1024 * 1024, 0
    try:
        with tmp.open("wb") as f:
            while chunk := file.file.read(4 * 1024 * 1024):
                size += len(chunk)
                if size > limit:
                    raise HTTPException(413, f"That file is too big. The limit is {config.MAX_UPLOAD_MB} MB.")
                f.write(chunk)
        try:
            with _create_lock:
                _job_slots()
                job = jobs.create({"type": "file", "path": str(tmp), "name": name}, opts, enqueue=False, creator=creator or None)
        except (ValueError, TypeError):
            raise HTTPException(400, "Those options aren't valid.")
        _disk.pop(ctx.uid(), None)
        dest = jobs.job_dir(job["id"]) / ("source" + ext)
        shutil.move(str(tmp), dest)
    finally:
        tmp.unlink(missing_ok=True)
    job["source"]["path"] = str(dest)
    jobs.enqueue(job)
    return jobs.public(job)


# ---------------------------------------------------------------- big files, sent in pieces
# The page cuts a large file into pieces, sends each one, and asks for them to be joined. Each piece is small enough
# for anything standing in front of the app. Nothing is trusted from the page: the sizes are fixed when the upload
# starts, every piece must be exactly its size, and only the account that started an upload can add to it.
_UP_ID = re.compile(r"[0-9a-f]{24}")
_up_lock = threading.Lock()


def _up_root() -> Path:
    d = config.TMP_DIR / "uploads"
    d.mkdir(parents=True, exist_ok=True)
    return d


UP_IDLE_SEC = 15 * 60     # an upload of your own that hasn't moved for this long was left behind (tab closed, page reloaded)


def _up_active(d: Path) -> float:
    """When this upload last moved: its folder, or any piece in it (a piece being sent grows as it arrives)."""
    newest = d.stat().st_mtime
    for f in d.iterdir():
        try:
            newest = max(newest, f.stat().st_mtime)
        except OSError:
            pass
    return newest


def _up_sweep():
    """Forget uploads that were started and never finished: anyone's after six hours, and the asker's own once
    they have stood still for UP_IDLE_SEC. An upload cut short by closing the tab or reloading the page never
    says it stopped, and it must not keep counting against the limit of uploads at once."""
    me = ctx.uid()
    for d in _up_root().glob("up-*"):
        try:
            if not d.is_dir():
                continue
            idle = time.time() - _up_active(d)
            if idle > 6 * 3600:
                shutil.rmtree(d, ignore_errors=True)
            elif idle > UP_IDLE_SEC and json.loads((d / "meta.json").read_text(encoding="utf-8")).get("user") == me:
                shutil.rmtree(d, ignore_errors=True)
        except (OSError, ValueError):
            pass


def _up_get(upid: str) -> dict:
    """The upload, only if it belongs to whoever is asking."""
    if not _UP_ID.fullmatch(upid or ""):
        raise HTTPException(404, "No such upload")
    try:
        meta = json.loads((_up_root() / f"up-{upid}" / "meta.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        raise HTTPException(404, "This upload has expired. Start it again.")
    if meta.get("user") != ctx.uid():
        raise HTTPException(404, "No such upload")
    return meta


@app.post("/api/upload/start")
def upload_start(body: dict = Body(...)):
    _need_verified()
    _job_slots()
    _quota()
    _throttle("upstart:" + ctx.uid(), 30, 600)
    name = re.sub(r"[^\w.\- ]", "_", Path(str(body.get("name") or "video.mp4")).name)[:120]
    ext = Path(name).suffix.lower()
    if ext not in VIDEO_TYPES:
        raise HTTPException(400, "Upload a video file (mp4, mov, mkv or webm).")
    size = body.get("size")
    if isinstance(size, bool) or not isinstance(size, int) or size <= 0:
        raise HTTPException(400, "Bad file size.")
    if size > config.MAX_UPLOAD_MB * 1024 * 1024:
        raise HTTPException(413, f"That file is too big. The limit is {config.MAX_UPLOAD_MB} MB.")
    if _disk.get(ctx.uid(), (0, 0))[1] + size > config.MAX_USER_GB * 1e9:
        raise HTTPException(507, "There isn't room for this file in your storage. Delete some older videos to make room.")
    creator = str(body.get("creator") or "")
    if creator and not creators.get(creator):
        raise HTTPException(404, "No such creator")
    opts = body.get("options") if isinstance(body.get("options"), dict) else {}
    try:
        jobs.clean_options(opts)                 # refused now rather than after the whole file has been sent
    except (ValueError, TypeError):
        raise HTTPException(400, "Those options aren't valid.")
    _up_sweep()
    mine = 0
    for d in _up_root().glob("up-*"):
        try:
            mine += json.loads((d / "meta.json").read_text(encoding="utf-8")).get("user") == ctx.uid()
        except (OSError, ValueError):
            pass
    if mine >= config.MAX_ACTIVE_JOBS_PER_USER:
        raise HTTPException(429, f"You already have {mine} uploads in progress. Let one finish first.")
    part = config.UPLOAD_PART_MB * 1024 * 1024
    upid = os.urandom(12).hex()
    d = _up_root() / f"up-{upid}"
    d.mkdir()
    meta = {"user": ctx.uid(), "name": name, "ext": ext, "size": size, "part": part, "parts": -(-size // part),
            "options": opts, "creator": creator, "t": time.time()}
    (d / "meta.json").write_text(json.dumps(meta), encoding="utf-8")
    return {"id": upid, "part": part, "parts": meta["parts"]}


@app.put("/api/upload/{upid}/{n}")
async def upload_part(request: Request, upid: str, n: int):
    meta = await run_in_threadpool(_up_get, upid)
    if not 0 <= n < meta["parts"]:
        raise HTTPException(400, "No such piece.")
    want = meta["part"] if n < meta["parts"] - 1 else meta["size"] - meta["part"] * (meta["parts"] - 1)
    d = _up_root() / f"up-{upid}"
    tmp = d / f"{n:05d}.{os.urandom(4).hex()}.tmp"
    got = 0
    try:
        with tmp.open("wb") as f:
            async for chunk in request.stream():
                got += len(chunk)
                if got > want:
                    raise HTTPException(400, "That piece is the wrong size.")
                await run_in_threadpool(f.write, chunk)
        if got != want:
            raise HTTPException(400, "That piece is the wrong size.")
        tmp.replace(d / f"{n:05d}.part")           # sending a piece again simply replaces it
    finally:
        tmp.unlink(missing_ok=True)
    return {"ok": True, "n": n}


@app.post("/api/upload/{upid}/finish")
def upload_finish(upid: str):
    meta = _up_get(upid)
    _need_verified()
    d = _up_root() / f"up-{upid}"
    with _up_lock:                                    # two "finish" calls for one upload make one video, not two
        if not (d / "meta.json").is_file():
            raise HTTPException(404, "This upload has expired. Start it again.")
        parts = [d / f"{i:05d}.part" for i in range(meta["parts"])]
        missing = [i for i, p in enumerate(parts) if not p.is_file()]
        if missing:
            raise HTTPException(409, f"Piece {missing[0] + 1} of {meta['parts']} has not arrived yet.")
        if sum(p.stat().st_size for p in parts) != meta["size"]:
            raise HTTPException(400, "The pieces do not add up to the file.")
        try:
            with _create_lock:
                _job_slots()
                job = jobs.create({"type": "file", "path": "", "name": meta["name"]}, meta["options"], enqueue=False,
                                  creator=meta["creator"] or None)
        except (ValueError, TypeError):
            raise HTTPException(400, "Those options aren't valid.")
        dest = jobs.job_dir(job["id"]) / ("source" + meta["ext"])
        try:
            with dest.open("wb") as out:
                for p in parts:
                    with p.open("rb") as src:
                        shutil.copyfileobj(src, out, 4 * 1024 * 1024)
        except OSError:
            jobs.delete(job["id"])
            raise HTTPException(507, "There wasn't room to save this file. Delete some older videos and try again.")
        shutil.rmtree(d, ignore_errors=True)
    _disk.pop(ctx.uid(), None)
    job["source"]["path"] = str(dest)
    jobs.enqueue(job)
    return jobs.public(job)


@app.delete("/api/upload/{upid}")
def upload_cancel(upid: str):
    _up_get(upid)
    shutil.rmtree(_up_root() / f"up-{upid}", ignore_errors=True)
    return {"ok": True}


@app.post("/api/jobs/{jid}/clips/{cid}/render")
def rerender(jid: str, cid: str, body: dict = Body(...)):
    job = _job_or_404(jid)
    clip = next((c for c in job["clips"] if c["id"] == cid), None)
    if not clip:
        raise HTTPException(404, "No such clip")
    if job["status"] in ("queued", "running") or clip.get("status") in ("queued", "rendering"):
        raise HTTPException(409, "This clip is still being made. Try again when it has finished.")
    _throttle("render:" + ctx.uid(), 20, 600, "That's a lot of re-makes in a short time. Wait a few minutes.")
    try:
        jobs.request_render(jid, cid, body)
    except (ValueError, TypeError) as e:
        raise HTTPException(400, str(e))
    return jobs.public(job)


def _clip_or_404(jid: str, cid: str):
    job = _job_or_404(jid)
    clip = next((c for c in job["clips"] if c["id"] == cid), None)
    if not clip:
        raise HTTPException(404, "No such clip")
    return job, clip


@app.put("/api/jobs/{jid}/clips/{cid}/text")
def clip_text(jid: str, cid: str, body: dict = Body(...)):
    """Save a clip's title, description and hashtags. The video is not made again."""
    job, clip = _clip_or_404(jid, cid)
    _throttle("cliptext:" + ctx.uid(), 120, 600)
    try:
        jobs.save_post_text(job, clip, body)
    except (ValueError, TypeError) as e:
        raise HTTPException(400, str(e))
    return jobs.public(job)


@app.post("/api/jobs/{jid}/clips/{cid}/review")
def clip_review(jid: str, cid: str, body: dict = Body(...)):
    """From the swipe review: "skip" sets a clip aside (it stays in All videos); "post" queues it for the accounts
    picked on the phone, or the creator's own accounts."""
    job, clip = _clip_or_404(jid, cid)
    _throttle("review:" + ctx.uid(), 300, 600)
    action = str(body.get("action", ""))
    if action == "skip":
        clip["reviewed"] = "skip"
        jobs.save(job)
        ctx.bump()
        return {"ok": True}
    if action != "post":
        raise HTTPException(400, "Choose post or skip.")
    if clip.get("status") != "done":
        raise HTTPException(400, "That clip isn't finished yet.")
    accs = [str(a) for a in (body.get("accounts") or [])][:20]
    if not accs:
        c = creators.get(job.get("creator")) if job.get("creator") else None
        accs = (c or {}).get("accounts") or []
    if not accs:
        raise HTTPException(400, "Pick the accounts to post to, at the top of this page.")
    made = posting.enqueue(job, clip, accs)
    clip["reviewed"] = "post"
    jobs.save(job)
    ctx.bump()
    return {"queued": len(made), "when": min((p["due_at"] for p in made), default=0)}


@app.post("/api/jobs/{jid}/clips/{cid}/write")
def clip_write(jid: str, cid: str):
    """Ask the AI for a new title, description and hashtags for one clip. Returned to the page, not saved."""
    job, clip = _clip_or_404(jid, cid)
    _throttle("clipwrite:" + ctx.uid(), 20, 600, "That's a lot of rewrites in a short time. Wait a few minutes.")
    usage.set_context(job.get("creator"), job.get("title") or "")
    try:
        return brain.post_text(jobs.spoken_in(job, clip), job.get("title") or "", job.get("uploader") or "",
                               game=job.get("game") or None)
    except ValueError as e:
        raise HTTPException(400, str(e))
    except RuntimeError as e:
        raise HTTPException(503, str(e))


@app.delete("/api/jobs/{jid}")
def delete_job(jid: str):
    job = _job_or_404(jid)
    if job["status"] in ("queued", "running", "live") or jid in live.SESSIONS:
        raise HTTPException(409, "This is still being worked on. Stop it or wait for it to finish first.")
    jobs.delete(jid)
    return {"ok": True}


def _pairs(v, limit=300) -> list:
    """[[video id, clip id], ...] from the page, checked."""
    out = []
    for x in (v if isinstance(v, list) else [])[:limit]:
        if isinstance(x, (list, tuple)) and len(x) == 2 and all(isinstance(y, str) and re.fullmatch(r"[\w\-]{1,60}", y) for y in x):
            out.append((x[0], x[1]))
    return out


@app.delete("/api/jobs/{jid}/clips/{cid}")
def delete_clip(jid: str, cid: str):
    _job_or_404(jid)
    try:
        if not account.delete_clip(jid, cid):
            raise HTTPException(404, "No such clip")
    except account.Busy as e:
        raise HTTPException(409, str(e))
    return {"ok": True}


@app.post("/api/bulk/delete")
def bulk_delete(body: dict = Body(...)):
    _throttle("bulkdel:" + ctx.uid(), 30, 600)
    vids = [x for x in (body.get("videos") if isinstance(body.get("videos"), list) else [])[:300]
            if isinstance(x, str) and re.fullmatch(r"[\w\-]{8,60}", x)]
    return account.delete_many(vids, _pairs(body.get("clips")))


@app.get("/api/clips.zip")
def clips_zip(ids: str = ""):
    """Many clips as one download. `ids` is video.clip pairs separated by commas."""
    _throttle("zip:" + ctx.uid(), 12, 600, "Give it a moment: you just downloaded several groups of clips.")
    pairs = _pairs([p.split(".", 1) for p in ids.split(",") if "." in p][:300])
    try:
        f = account.zip_clips(pairs)
    except ValueError as e:
        raise HTTPException(400, str(e))
    from starlette.background import BackgroundTask
    return FileResponse(f, filename=f"clipcut-clips-{len(pairs)}.zip", media_type="application/zip",
                        headers={"Cache-Control": "private, no-store"}, background=BackgroundTask(lambda: f.unlink(missing_ok=True)))


@app.delete("/api/creators/{cid}")
def delete_creator(cid: str):
    _throttle("cdel:" + ctx.uid(), 30, 600)
    try:
        r = account.delete_creator(cid)
    except account.Busy as e:
        raise HTTPException(409, str(e))
    if not r.get("ok"):
        raise HTTPException(404, "No such creator")
    return r


@app.post("/api/account/delete")
def delete_my_account(request: Request, body: dict = Body(...)):
    """Deletes the signed-in account and everything in it. The page asks for the email to be typed, so it cannot
    happen by a stray click or a request the person did not mean to make."""
    me_ = _me(request)
    if str(body.get("confirm") or "").strip().lower() != me_.email.lower():
        raise HTTPException(400, "Type your email address exactly to confirm.")
    try:
        account.delete_account(me_.id)
    except account.Busy as e:
        raise HTTPException(409, str(e))
    resp = JSONResponse({"ok": True})
    resp.delete_cookie(auth.cookie_args("x")["key"], path="/")
    return resp


@app.get("/media/{jid}/{name}")
def media_file(jid: str, name: str, download: int = 0):
    if not re.fullmatch(r"[\w\-]+\.(mp4|jpg)", name):
        raise HTTPException(404)
    job = _job_or_404(jid)
    f = Path(job["dir"]) / "clips" / name
    if not f.is_file():
        raise HTTPException(404)
    save_as = name
    if download and name.endswith(".mp4"):
        # a clip is saved under its title, not "clip01.mp4", the same as when several are downloaded as a zip
        clip = next((c for c in job.get("clips", []) if Path(str(c.get("file") or "")).name == name), None)
        if clip:
            save_as = account.clip_title_name(clip, Path(name).stem) + ".mp4"
    return FileResponse(f, filename=save_as if download else None, headers={"Cache-Control": "private, max-age=300"})


# ================================================================ creators and live recording
def _channel_ok(body: dict):
    links = [str(body.get("channel") or "").strip()]
    chs = body.get("channels")
    if chs is not None and not isinstance(chs, dict):
        raise HTTPException(400, "Bad channel list.")
    for plat, url in (chs or {}).items():
        url = str(url or "").strip()
        if url and creators.platform_key(url) != plat:
            raise HTTPException(400, f"That link isn't a {plat.title()} channel.")
        links.append(url)
    for ch in links:
        if ch and not media.site_allowed(live.normalize(ch)):
            raise HTTPException(400, "Channel links must be from YouTube, Twitch or Kick.")


@app.get("/api/admin/email-preview")
def email_preview(request: Request, kind: str = "verify"):
    """What account emails look like, for admins."""
    from . import mailer
    _admin(request)
    if kind == "reset":
        page = mailer.preview("Reset your password", "Someone asked to reset the password for this Clip Cut AI account. If that was you, choose a new one below.",
                              "Choose a new password", config.PUBLIC_URL + "/reset?t=example",
                              "The link works for one hour. If you didn't ask for this, ignore this email and your password stays the same.")
    else:
        page = mailer.preview()
    return HTMLResponse(page, headers={"Cache-Control": "no-store"})


@app.post("/api/admin/test-email")
def test_email(request: Request):
    """Send the confirm-email template to the admin, to check the email service works."""
    from . import mailer
    me_ = _admin(request)
    if not mailer.ready():
        raise HTTPException(400, "No email service is set up yet. Add the CLIPCUT_SMTP settings to .env first.")
    mailer.send(me_.email, "Clip Cut AI test email", "Your emails are working",
                "This is a test from your Clip Cut AI server. Account emails like this one will now reach people.",
                "Open Clip Cut AI", config.PUBLIC_URL + "/app", "You can ignore this message.")
    return {"sent_to": me_.email}


@app.post("/api/feedback")
def send_feedback(request: Request, body: dict = Body(...)):
    from . import feedback
    u = _me(request)
    try:
        auth.throttle("feedback:" + u.id, 10, 3600)
        return feedback.submit(u.id, str(body.get("kind", "")), str(body.get("message", "")),
                               str(body.get("page", "")), str(body.get("context", "")))
    except auth.AuthError:
        raise HTTPException(429, "You've sent a lot of messages in the last hour. Try again a bit later.")
    except feedback.Refused as e:
        raise HTTPException(400, str(e))


@app.get("/api/admin/feedback")
def admin_feedback(request: Request, status: str = ""):
    from . import feedback
    _admin(request)
    return feedback.listing(status)


@app.post("/api/admin/feedback/{fid}")
def admin_feedback_status(request: Request, fid: int, body: dict = Body(...)):
    from . import feedback
    _admin(request)
    try:
        feedback.set_status(fid, str(body.get("status", "")))
    except feedback.Refused as e:
        raise HTTPException(400, str(e))
    return {"ok": True}


@app.get("/api/notifications")
def notifications_list():
    from . import notices
    return notices.mine()


@app.post("/api/notifications/read")
def notifications_read():
    from . import notices
    notices.read_all()
    return {"ok": True}


@app.get("/api/me/photo")
def my_photo(request: Request):
    u = _me(request)
    got = auth.photo(u.id) if u else None
    if not got:
        raise HTTPException(404)
    return FileResponse(got[0], media_type=got[1], headers={"Cache-Control": "private, max-age=86400"})


@app.get("/api/channel-preview")
def channel_preview(request: Request, url: str = ""):
    url = url.strip()[:300]
    if not url or not media.site_allowed(live.normalize(url)):
        raise HTTPException(400, "Paste a YouTube, Twitch or Kick channel link.")
    try:
        auth.throttle(f"chanprev:{_me(request).id}", 12, 60)
    except auth.AuthError:
        raise HTTPException(429, "Too many lookups at once. Wait a moment.")
    try:
        return _lookup(profiles.preview, url)
    except ValueError as e:
        raise HTTPException(422, str(e))
    except HTTPException:
        raise
    except Exception:
        raise HTTPException(422, "Couldn't open that channel. Check the link.")


@app.get("/api/creators/{cid}/avatar")
def creator_avatar(cid: str, p: str = ""):
    c = creators.get(cid)
    if not c:
        raise HTTPException(404)
    key = p if p in creators.PLATFORMS else creators.platform_key(c["channel"])
    prof = (c.get("profiles") or {}).get(key) or {}
    f = creators.root(cid) / f"avatar-{key}.img"
    if not f.is_file() or prof.get("pic") not in ("image/jpeg", "image/png", "image/webp"):
        raise HTTPException(404)
    return FileResponse(f, media_type=prof["pic"], headers={"Cache-Control": "private, max-age=86400"})


@app.get("/api/creators")
def list_creators():
    return _creator_rows()


@app.post("/api/creators")
def new_creator(body: dict = Body(...)):
    _channel_ok(body)
    if len(creators.all_creators()) >= config.MAX_CREATORS:
        raise HTTPException(400, f"This server allows {config.MAX_CREATORS} creators per account.")
    try:
        c = creators.create(body)
    except ValueError as e:
        raise HTTPException(400, str(e))
    if c.get("channels"):
        profiles.refresh(c["id"], force=True)
    return c


@app.put("/api/creators/{cid}")
def edit_creator(cid: str, body: dict = Body(...)):
    _throttle("cedit:" + ctx.uid(), 60, 600)
    _channel_ok(body)
    had_uploads = bool((creators.get(cid) or {}).get("auto_uploads"))
    try:
        c = creators.update(cid, body)
    except KeyError:
        raise HTTPException(404, "No such creator")
    except ValueError as e:
        raise HTTPException(400, str(e))
    s = live.active_for(cid)
    if s:
        s.settings = c  # new settings apply to the running recording straight away
    if "channels" in body or "channel" in body:
        profiles.refresh(cid, force=True)
    if body.get("auto_watch") and c.get("auto_watch") and not s:
        live.check_now(cid)    # if they are live right now, recording starts within seconds
    if c.get("auto_uploads") and not had_uploads:
        from . import autofetch
        autofetch.turned_on(cid)   # what is on the channel now is left alone; only new uploads get clipped
    return c


# ---------------------------------------------------------------- a creator's logo, for the corner of their clips
@app.get("/api/creators/{cid}/logo")
def creator_logo(cid: str):
    try:
        f = creators.root(cid) / "logo.png"
    except ValueError:
        raise HTTPException(404)
    if not creators.get(cid) or not f.is_file():
        raise HTTPException(404)
    return FileResponse(f, media_type="image/png", headers={"Cache-Control": "no-store"})


@app.post("/api/creators/{cid}/logo")
def creator_logo_put(cid: str, file: UploadFile = File(...)):
    if not creators.get(cid):
        raise HTTPException(404, "No such creator")
    data = file.file.read(5_000_001)
    if len(data) > 5_000_000:
        raise HTTPException(400, "Use a logo smaller than 5 MB.")
    try:
        import io
        from PIL import Image
        with Image.open(io.BytesIO(data)) as im:
            im = im.convert("RGBA")
            im.thumbnail((600, 600))
            im.save(creators.root(cid) / "logo.png", "PNG")
    except Exception:  # noqa: BLE001
        raise HTTPException(400, "That file isn't a picture. Use a PNG or JPG logo.")
    ctx.bump()
    return {"ok": True}


@app.delete("/api/creators/{cid}/logo")
def creator_logo_delete(cid: str):
    if not creators.get(cid):
        raise HTTPException(404)
    (creators.root(cid) / "logo.png").unlink(missing_ok=True)
    ctx.bump()
    return {"ok": True}


# ---------------------------------------------------------------- quick add: paste a channel, get a daily plan
@app.post("/api/quick-add")
def quick_add(request: Request, body: dict = Body(...)):
    from . import autofetch, quickadd
    _throttle("quickadd:" + ctx.uid(), 20, 3600)
    try:
        out = quickadd.quick_add(str(body.get("url", "")), str(body.get("audience", "india")), str(body.get("name", "")),
                                 read_feed=autofetch.list_feed)
    except ValueError as e:
        raise HTTPException(400, str(e))
    autofetch.turned_on(out["creator"]["id"])
    return out


@app.get("/api/quick-add/plan")
def quick_add_plan(audience: str = "india", per_day: int = 3):
    from . import quickadd
    return quickadd.plan(audience, max(1, min(5, per_day)))


# ---------------------------------------------------------------- autopilot
@app.get("/api/creators/{cid}/autopilot")
def autopilot_get(cid: str):
    from . import autopilot
    if not creators.get(cid):
        raise HTTPException(404)
    return autopilot.summary(cid)


@app.post("/api/creators/{cid}/autopilot/learn")
def autopilot_learn(cid: str):
    from . import autopilot
    if not creators.get(cid):
        raise HTTPException(404)
    _throttle("learn:" + ctx.uid(), 6, 3600)
    notes = autopilot.learn_style(cid)
    if not notes:
        raise HTTPException(400, "Not enough yet: it needs at least 10 posted clips with views.")
    return autopilot.summary(cid)


@app.put("/api/creators/{cid}/autopilot")
def autopilot_all(cid: str, body: dict = Body(...)):
    from . import autopilot
    if not creators.get(cid):
        raise HTTPException(404)
    on = bool(body.get("on", True))
    return creators.update(cid, {k: on for k in autopilot.SWITCHES})


@app.get("/api/ytstrategy/audit")
def ytstrategy_audit():
    """yt-audit: ONE fix per YouTube channel, from its recent titles and upload rhythm."""
    from . import ytstrategy
    return {"channels": [dict(ytstrategy.audit(a["id"]), account=a["name"]) for a in accounts.list_accounts()
                         if a["platform"] in ("youtube", "instagram", "facebook")],
            "best_days": ytstrategy.best_days()}


@app.post("/api/ytstrategy/lint")
def ytstrategy_lint(body: dict = Body(...)):
    """yt-package's title check, for a title you're writing yourself."""
    from . import ytstrategy
    return ytstrategy.lint_title(str(body.get("title", ""))[:200], str(body.get("thumb", ""))[:80] or None)


@app.get("/api/streamers")
def streamers(game: str = ""):
    from . import autopilot
    _throttle("streamers:" + ctx.uid(), 20, 3600)
    try:
        return {"streamers": autopilot.find_streamers(game)}
    except ValueError as e:
        raise HTTPException(400, str(e))
    except Exception:  # noqa: BLE001
        raise HTTPException(502, "YouTube didn't answer. Try again in a minute.")


@app.get("/api/competitors")
def competitors_get():
    from . import autopilot
    _throttle("comp:" + ctx.uid(), 20, 3600)
    return {"pages": autopilot.competitors(), "list": accounts.settings().get("competitors") or []}


# ---------------------------------------------------------------- the reaction sticker
@app.get("/api/creators/{cid}/reaction")
def creator_reaction(cid: str):
    try:
        f = creators.root(cid) / "reaction.png"
    except ValueError:
        raise HTTPException(404)
    if not creators.get(cid) or not f.is_file():
        raise HTTPException(404)
    return FileResponse(f, media_type="image/png", headers={"Cache-Control": "no-store"})


@app.post("/api/creators/{cid}/reaction")
def creator_reaction_put(cid: str, file: UploadFile = File(...)):
    if not creators.get(cid):
        raise HTTPException(404, "No such creator")
    data = file.file.read(5_000_001)
    if len(data) > 5_000_000:
        raise HTTPException(400, "Use a picture smaller than 5 MB.")
    try:
        import io
        from PIL import Image
        with Image.open(io.BytesIO(data)) as im:
            im = im.convert("RGBA")
            im.thumbnail((720, 720))
            im.save(creators.root(cid) / "reaction.png", "PNG")
    except Exception:  # noqa: BLE001
        raise HTTPException(400, "That file isn't a picture. Use a PNG (see-through background looks best).")
    ctx.bump()
    return {"ok": True}


@app.delete("/api/creators/{cid}/reaction")
def creator_reaction_delete(cid: str):
    if not creators.get(cid):
        raise HTTPException(404)
    (creators.root(cid) / "reaction.png").unlink(missing_ok=True)
    ctx.bump()
    return {"ok": True}


# ---------------------------------------------------------------- background music library
@app.get("/api/music")
def music_list():
    from . import musiclib
    return musiclib.listing()


@app.post("/api/music/{mood}")
def music_add(mood: str, file: UploadFile = File(...)):
    from . import musiclib
    try:
        name = musiclib.add(mood, file.filename or "track.mp3", file.file.read(25_000_001))
    except ValueError as e:
        raise HTTPException(400, str(e))
    return {"name": name, "music": musiclib.listing()}


@app.delete("/api/music/{mood}/{name}")
def music_remove(mood: str, name: str):
    from . import musiclib
    try:
        musiclib.remove(mood, name)
    except ValueError as e:
        raise HTTPException(400, str(e))
    return musiclib.listing()


# ---------------------------------------------------------------- permission from streamers
@app.get("/api/permissions")
def permissions_board():
    from . import permission
    return {"creators": permission.board(), "template": accounts.settings().get("permission_template", ""),
            "default": permission.DEFAULT}


@app.get("/api/creators/{cid}/permission-message")
def permission_message(cid: str):
    from . import permission
    c = creators.get(cid)
    if not c:
        raise HTTPException(404)
    return {"text": permission.message(c)}


# ---------------------------------------------------------------- page language, Threads/Bluesky/Discord
@app.put("/api/accounts/{aid}/lang")
def account_lang(aid: str, body: dict = Body(...)):
    try:
        accounts.set_lang(aid, str(body.get("lang", "auto")))
    except KeyError:
        raise HTTPException(404)
    except ValueError as e:
        raise HTTPException(400, str(e))
    return accounts.list_accounts()


@app.get("/api/limits")
def limits_get():
    from . import limits
    return {"accounts": limits.status(), "every_hours": limits.EVERY // 3600}


@app.post("/api/limits/check")
def limits_check():
    from . import limits
    _throttle("limcheck:" + ctx.uid(), 20, 3600)
    limits.check_all()
    return {"accounts": limits.status(), "every_hours": limits.EVERY // 3600}


@app.put("/api/accounts/{aid}/limit")
def account_limit(aid: str, body: dict = Body(...)):
    from . import limits
    try:
        accounts.set_limit(aid, body.get("limit"))
    except KeyError:
        raise HTTPException(404)
    except ValueError as e:
        raise HTTPException(400, str(e))
    return {"accounts": limits.status(), "every_hours": limits.EVERY // 3600}


@app.post("/api/accounts/facebook-token")
def account_facebook_token(body: dict = Body(...)):
    _throttle("keyacc:" + ctx.uid(), 20, 600)
    try:
        a = accounts.facebook_by_token(str(body.get("token", "")))
    except ValueError as e:
        raise HTTPException(400, str(e))
    except RuntimeError as e:
        raise HTTPException(400, f"Facebook didn't accept that token: {str(e)[-200:]}")
    return {"name": a["name"]}


@app.post("/api/accounts/key/{platform}")
def account_by_key(platform: str, body: dict = Body(...)):
    _throttle("keyacc:" + ctx.uid(), 20, 600)
    if platform not in accounts.KEY_PLATFORMS:
        raise HTTPException(404)
    try:
        return accounts.connect_key(platform, body)
    except ValueError as e:
        raise HTTPException(400, str(e))
    except RuntimeError as e:
        raise HTTPException(400, f"{accounts.PLATFORM_NAMES[platform]} didn't accept that key. Check it and try again.")


# ---------------------------------------------------------------- money: links, sponsors, YouTube earnings
@app.get("/api/affiliate")
def affiliate_stats():
    from . import affiliate
    return {"links": affiliate.stats(), "public": (config.PUBLIC_URL or "").startswith("https://")}


@app.get("/go/{code}")
def go_link(code: str):
    from . import affiliate
    url = affiliate.click(code)
    if not url:
        raise HTTPException(404)
    return RedirectResponse(url, 302, headers={"Cache-Control": "no-store", "Referrer-Policy": "no-referrer"})


@app.get("/api/bio")
def bio_get():
    from . import affiliate
    return affiliate.my_bio()


@app.put("/api/bio")
def bio_put(body: dict = Body(...)):
    from . import affiliate
    try:
        return affiliate.set_bio(str(body.get("slug", "")), str(body.get("title", "")), str(body.get("about", "")))
    except ValueError as e:
        raise HTTPException(400, str(e))


@app.get("/c/{slug}")
def bio_page(slug: str):
    from . import affiliate
    page = affiliate.bio_html(slug)
    if page is None:
        raise HTTPException(404)
    return HTMLResponse(page, headers={"Cache-Control": "public, max-age=300"})


@app.get("/api/sponsors")
def sponsors_list():
    from . import sponsors
    return sponsors.listing()


@app.post("/api/sponsors")
def sponsors_add(body: dict = Body(...)):
    from . import sponsors
    try:
        sponsors.save(body)
    except ValueError as e:
        raise HTTPException(400, str(e))
    return sponsors.listing()


@app.put("/api/sponsors/{sid}")
def sponsors_edit(sid: str, body: dict = Body(...)):
    from . import sponsors
    try:
        sponsors.save(body, sid)
    except KeyError:
        raise HTTPException(404)
    except ValueError as e:
        raise HTTPException(400, str(e))
    return sponsors.listing()


@app.delete("/api/sponsors/{sid}")
def sponsors_remove(sid: str):
    from . import sponsors
    sponsors.remove(sid)
    return sponsors.listing()


@app.get("/api/money/youtube/{aid}")
def money_youtube(aid: str):
    from . import ytmoney
    try:
        return ytmoney.report(aid)
    except KeyError:
        raise HTTPException(404)
    except RuntimeError as e:
        raise HTTPException(502, str(e)[:200])


@app.get("/api/creators/{cid}/best-length")
def best_length(cid: str):
    from . import growth
    if not creators.get(cid):
        raise HTTPException(404)
    return growth.best_length(cid)


# ---------------------------------------------------------------- phone notifications (web push)
@app.get("/api/push")
def push_info():
    from . import webpush
    return {"key": webpush.public_key(), "phones": len(webpush.subs())}


@app.post("/api/push")
def push_add(body: dict = Body(...)):
    from . import webpush
    try:
        webpush.add(body)
    except ValueError as e:
        raise HTTPException(400, str(e))
    return {"phones": len(webpush.subs())}


@app.post("/api/push-test")
def push_test():
    from . import webpush
    n = webpush.send("Phone alerts work! You'll get one when a clip is ready or a post fails.", "/app")
    if not n:
        raise HTTPException(400, "No phone got it. Turn on alerts on your phone first (and allow notifications).")
    return {"sent": n}


# ---------------------------------------------------------------- a shared workspace (Settings, Team)
@app.get("/api/team")
def team_get(request: Request):
    from . import team
    return team.listing(_me(request))


@app.post("/api/team")
def team_add(request: Request, body: dict = Body(...)):
    from . import team
    if not config.ACCOUNTS:
        raise HTTPException(400, "Switch sign-in on first (Settings, Login), so each teammate can sign in.")
    _throttle("team:" + _me(request).id, 20, 600)
    try:
        return team.invite(_me(request), str(body.get("email", "")), str(body.get("role", "manager")))
    except ValueError as e:
        raise HTTPException(400, str(e))


@app.delete("/api/team/{who}")
def team_remove(request: Request, who: str):
    from . import team
    return team.remove(_me(request), who)


@app.put("/api/team/{who}/role")
def team_role(request: Request, who: str, body: dict = Body(...)):
    from . import team
    try:
        return team.set_role(_me(request), who, str(body.get("role", "")))
    except ValueError as e:
        raise HTTPException(400, str(e))


@app.post("/api/team/leave")
def team_leave(request: Request):
    from . import team
    team.leave(_me(request))
    return {"ok": True}


@app.get("/api/creators/{cid}/best-times")
def creator_best_times(cid: str):
    from . import growth
    c = creators.get(cid)
    if not c:
        raise HTTPException(404)
    return {**growth.best_hours(c.get("accounts") or None), "suggest": growth.suggest_times(c)}


@app.post("/api/report/weekly")
def weekly_report_now():
    from . import growth
    if not alerts.configured():
        raise HTTPException(400, "Save a Discord webhook or Telegram details first.")
    _throttle("weekly:" + ctx.uid(), 5, 600)
    problems = alerts.send(growth.weekly_text())
    if problems:
        raise HTTPException(502, "; ".join(problems))
    return {"ok": True}


@app.post("/api/creators/{cid}/compilation")
def creator_compilation(cid: str, body: dict = Body(default={})):
    from . import compilation
    if not creators.get(cid):
        raise HTTPException(404)
    _throttle("compile:" + ctx.uid(), 4, 3600)
    days = max(1, min(31, int(body.get("days") or 7)))
    count = max(3, min(15, int(body.get("count") or 10)))
    got = compilation.pick(cid, days, count)
    if len(got) < 3:
        raise HTTPException(400, f"Only {len(got)} finished clip{'s' if len(got) != 1 else ''} from the last {days} days. A compilation needs at least 3.")
    compilation.make_in_background(cid, days, count)
    return {"started": True, "clips": len(got)}


@app.get("/api/creators/{cid}/campaign.csv")
def creator_campaign_csv(cid: str, days: int = 30):
    """Every post of this creator in the last days, with views and the estimated pay, for a clipping campaign."""
    import csv
    import io
    c = creators.get(cid)
    if not c:
        raise HTTPException(404)
    days = max(1, min(366, days))
    since = time.time() - days * 86400
    rows = [p for p in posting._mine() if p.get("creator") == cid and p["status"] == "posted" and (p.get("posted_at") or 0) >= since]
    rows.sort(key=lambda p: p.get("posted_at") or 0)
    rate = float(c.get("rate_per_1k") or 0)
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["Posted", "Platform", "Account", "Title", "Link", "Views", "Estimated pay ($)"])
    total_v = 0
    for p in rows:
        v = int(p.get("views") or 0)
        total_v += v
        w.writerow([time.strftime("%Y-%m-%d %H:%M", time.localtime(p["posted_at"])), accounts.PLATFORM_NAMES.get(p["platform"], p["platform"]),
                    p.get("account_name", ""), p.get("title", ""), p.get("url", ""), v, round(v / 1000 * rate, 2)])
    w.writerow([])
    w.writerow(["Total", "", "", f"{len(rows)} posts", "", total_v, round(total_v / 1000 * rate, 2)])
    name = re.sub(r"[^\w\-]+", "-", c["name"]).strip("-") or "creator"
    return Response("\ufeff" + buf.getvalue(), media_type="text/csv",
                    headers={"Content-Disposition": f'attachment; filename="{name}-campaign-{time.strftime("%Y-%m-%d")}.csv"'})


# ---------------------------------------------------------------- the AI Manager
@app.get("/api/manager")
def manager_get():
    from . import manager
    return manager.state()


@app.put("/api/manager")
def manager_put(body: dict = Body(...)):
    from . import manager
    return manager.switch(bool(body.get("on")))


@app.post("/api/manager/chat")
def manager_chat(body: dict = Body(...)):
    from . import manager
    _throttle("manager:" + ctx.uid(), 40, 600, "That's a lot of messages. Wait a few minutes.")
    try:
        reply = manager.chat(str(body.get("text", "")), source="app")
    except ValueError as e:
        raise HTTPException(400, str(e))
    except Exception as e:  # noqa: BLE001
        raise HTTPException(502, "The Manager couldn't answer: " + safe.friendly(e, 150))
    return {"reply": reply, **manager.state()}


# ---------------------------------------------------------------- trending, analytics
@app.get("/api/trending")
def trending_get(game: str = ""):
    from . import trends
    _throttle("trend:" + ctx.uid(), 30, 600)
    try:
        vids = trends.trending(game)
    except ValueError as e:
        raise HTTPException(400, str(e))
    except Exception as e:  # noqa: BLE001
        raise HTTPException(502, "Couldn't reach YouTube's search right now: " + safe.friendly(e, 150))
    return {"game": trends.clean_game(game), "videos": vids, "tags": trends.tags_from([v["title"] for v in vids], game)}


@app.get("/api/insights")
def insights_get(days: int = 30):
    from . import insights
    return insights.summary(max(1, min(365, days)))


@app.post("/api/insights/advice")
def insights_advice(body: dict = Body(default={})):
    from . import insights
    _throttle("advice:" + ctx.uid(), 6, 3600)
    try:
        return {"tips": insights.advice(max(1, min(365, int(body.get("days") or 30))))}
    except ValueError as e:
        raise HTTPException(400, str(e))
    except RuntimeError as e:
        raise HTTPException(502, str(e))


@app.get("/api/creators/{cid}/uploads")
def creator_uploads(cid: str):
    from . import autofetch
    if not creators.get(cid):
        raise HTTPException(404)
    return autofetch.status(cid)


_vid_cache: dict = {}


@app.get("/api/creators/{cid}/videos")
def creator_videos(cid: str, fresh: int = 0):
    """The creator's newest videos and past streams, read from their channels (YouTube /videos and /streams, Twitch
    past broadcasts), so a video can be picked here instead of pasting its link. Kept 10 minutes."""
    from . import autofetch
    c = creators.get(cid)
    if not c:
        raise HTTPException(404)
    key = (ctx.uid(), cid)
    hit = _vid_cache.get(key)
    if hit and not fresh and time.time() - hit[0] < 600:
        rows = hit[1]
    else:
        _throttle("vids:" + ctx.uid(), 30, 600)
        rows, problems = [], []
        for url in autofetch.feeds(c):
            kind = "Live stream" if "/streams" in url else "Twitch" if "twitch.tv" in url else "Video"
            try:
                for v in autofetch.list_feed(url, 15):
                    if not v["live"] or kind == "Live stream":
                        rows.append(dict(v, kind=kind))
            except Exception as e:  # noqa: BLE001
                problems.append(str(e)[-120:])
        if not rows and problems:
            raise HTTPException(502, "Couldn't read their channel right now. Check the internet and the channel link in "
                                     "Setup, then press Refresh. You can still paste a video link.")
        _vid_cache[key] = (time.time(), rows)
    done = " ".join(str((j.get("source") or {}).get("url") or j.get("url") or "") for j in jobs.list_jobs() if j.get("creator") == cid)
    return {"videos": [dict(v, clipped=bool(v["id"]) and v["id"] in done) for v in rows], "channels": list(c.get("channels", {}).values())}


@app.post("/api/creators/{cid}/live")
def go_live(cid: str, body: dict = Body(default={})):
    _need_verified()
    try:
        c = creators.get(cid)
    except ValueError:
        c = None
    if not c:
        raise HTTPException(404, "No such creator")
    # the stream the user is watching, else where they are live right now, else the channel chosen in Setup
    on_air = [p["channel"] for k, p in (c.get("profiles") or {}).items() if p.get("live") and c["channels"].get(k) == p.get("channel")]
    asked = str((body or {}).get("channel") or "")
    url = asked if asked in c["channels"].values() else c["channel"] if c["channel"] in on_air or not on_air else on_air[0]
    try:
        return jobs.public(live.start_session(c, url))
    except ValueError as e:
        raise HTTPException(400, str(e))


@app.post("/api/live/{jid}/stop")
def stop_live(jid: str):
    s = live.mine(jid)
    if not s:
        raise HTTPException(404, "This recording has already ended")
    s.stop()
    return {"ok": True}


@app.post("/api/live/{jid}/clip")
def clip_now(jid: str, body: dict = Body(...)):
    s = live.mine(jid)
    if not s or s.ended:
        raise HTTPException(404, "This recording has already ended")
    _throttle("clipnow:" + ctx.uid(), 6, 60, "Give it a moment: your last clips are still being made.")
    if len(s.manual) >= 3:
        raise HTTPException(429, "Give it a moment: your last clips are still being made.")
    try:
        s.clip_last(max(5, min(180, float(body.get("seconds", 30)))))
    except (ValueError, TypeError) as e:
        raise HTTPException(400, str(e))
    return {"ok": True}


# ================================================================ AI usage
@app.get("/api/usage")
def ai_usage():
    return usage.summary({c["id"]: c["name"] for c in creators.all_creators()})


# ---------------------------------------------------------------- the AI key and model, set from the dashboard
# Only the owner (or an admin, when accounts are on) reaches these. The key is never sent back to the page.
def _ai_error(e) -> str:
    return safe.friendly(e, 300).replace(ai.key() or "\0", "<key>")


@app.get("/api/ai")
def ai_get(request: Request):
    _admin(request)
    return ai.public()


@app.put("/api/ai")
def ai_put(request: Request, body: dict = Body(...)):
    _admin(request)
    k = body.get("key")
    try:
        out = ai.save(body.get("provider"), body.get("models"), body.get("base_url") or "",
                      None if k is None or (isinstance(k, str) and not k.strip() and not body.get("remove_key")) else str(k))
    except (ValueError, TypeError) as e:
        raise HTTPException(400, str(e))
    usage.forget_all()
    ctx.bump()
    return out


@app.post("/api/ai/models")
def ai_models(request: Request, body: dict = Body(default={})):
    _admin(request)
    _throttle("aimodels:" + ctx.uid(), 30, 600)
    try:
        return {"models": ai.list_models(body.get("provider"), body.get("base_url"), body.get("key"))}
    except ValueError as e:
        raise HTTPException(400, str(e))
    except Exception as e:  # noqa: BLE001
        reason = ai.explain(e)
        raise HTTPException(502, f"The service did not give its list of models. {reason}" if reason else
                            "The service did not give its list of models. Check the key, or type the model yourself. " + _ai_error(e)[:160])


@app.post("/api/ai/test")
def ai_test(request: Request):
    _admin(request)
    _throttle("aitest:" + ctx.uid(), 20, 600)
    try:
        return ai.test()
    except ValueError as e:
        raise HTTPException(400, str(e))
    except Exception as e:  # noqa: BLE001
        raise HTTPException(502, ai.explain(e) or "The AI did not answer: " + _ai_error(e))


# ---------------------------------------------------------------- speech models, one per spoken language
# Only the owner (or an admin, when accounts are on) can download or delete them: they are shared by everyone here.
def _speech_lang(lang: str) -> str:
    from . import fetch_model
    if not fetch_model.known(lang):
        raise HTTPException(400, "Clip Cut AI has no speech model for that language.")
    return lang


@app.get("/api/speech")
def speech_list(request: Request):
    _admin(request)
    from . import fetch_model
    return {"models": [{"lang": k, "label": m[0], "size_mb": m[3], "credit": m[4], "state": fetch_model.status(k),
                        "percent": fetch_model.state[k]["percent"], "error": fetch_model.state[k]["error"],
                        "default": k == fetch_model.DEFAULT} for k, m in fetch_model.MODELS.items()]}


@app.post("/api/speech/{lang}")
def speech_download(request: Request, lang: str):
    _admin(request)
    from . import fetch_model
    fetch_model.start(_speech_lang(lang))
    ctx.bump()
    return speech_list(request)


@app.delete("/api/speech/{lang}")
def speech_remove(request: Request, lang: str):
    _admin(request)
    from . import fetch_model
    try:
        fetch_model.remove(_speech_lang(lang))
    except ValueError as e:
        raise HTTPException(400, str(e))
    except RuntimeError as e:
        raise HTTPException(409, str(e))
    ctx.bump()
    return speech_list(request)


# ================================================================ posting, accounts, settings
@app.get("/api/overview")
def overview():
    return posting.overview()


@app.get("/api/settings")
def get_settings():
    return accounts.public_settings()


@app.put("/api/settings")
def put_settings(body: dict = Body(...)):
    try:
        accounts.save_settings(body)
    except (ValueError, TypeError) as e:
        raise HTTPException(400, str(e))
    return accounts.public_settings()


@app.get("/api/accounts")
def list_accounts():
    return accounts.list_accounts()


@app.delete("/api/accounts/{aid}")
def remove_account(aid: str):
    accounts.remove(aid)
    return {"ok": True}


# ---------------------------------------------------------------- connecting YouTube, Instagram and TikTok
# Connect sends the browser to the platform's own sign-in page; the platform sends it back here, and the person lands
# on Settings, Connected apps, with the account added (or a message saying what went wrong).
def _back(**q):
    from urllib.parse import urlencode as _ue
    return RedirectResponse("/app/settings/apps?" + _ue(q), 303)


@app.get("/oauth/{platform}/start")
def connect_start(platform: str):
    if platform not in accounts.CONNECT_PLATFORMS:
        raise HTTPException(404)
    try:
        return RedirectResponse(accounts.connect_url(platform), 303)
    except ValueError as e:
        return _back(connect_error=str(e))


@app.get("/oauth/{platform}/callback")
def connect_callback(platform: str, code: str = "", state: str = "", error: str = "", error_description: str = "",
                     error_reason: str = ""):
    if platform not in accounts.CONNECT_PLATFORMS:
        raise HTTPException(404)
    name = accounts.PLATFORM_NAMES[platform]
    if error or not code:
        why = "you cancelled" if error in ("access_denied",) or error_reason == "user_denied" else (error_description or error or "no sign-in code came back")
        return _back(connect_error=f"{name} was not connected: {why[:160]}.")
    try:
        _throttle("connect:" + ctx.uid(), 30, 600)
        acc = accounts.connect_finish(platform, code, state)
    except HTTPException:
        raise
    except Exception as e:  # noqa: BLE001
        return _back(connect_error=f"{name} was not connected: {safe.friendly(e, 240)}")
    return _back(connected=platform, name=acc["name"])


@app.get("/pub/{token}.mp4")
def public_clip(token: str):
    """A clip for a platform to fetch while posting it: one clip, one hour, signed (see accounts.clip_link)."""
    got = accounts.read_clip_link(token)
    if not got:
        raise HTTPException(404)
    uid, job_id, name = got
    with ctx.as_user(uid):
        job = jobs.get(job_id) if re.fullmatch(r"[\w\-]{8,60}", job_id) else None
        f = Path(job["dir"]) / "clips" / name if job else None
    if not f or not f.is_file():
        raise HTTPException(404)
    return FileResponse(f, media_type="video/mp4", headers={"Cache-Control": "private, no-store"})


# ---------------------------------------------------------------- where Clip Cut AI keeps everything (Settings, Storage)
def _on_this_computer(request: Request) -> bool:
    """Is the person sitting at the computer Clip Cut AI runs on? Only then can a folder window be opened for them."""
    host = request.client.host if request.client else ""
    return host in ("127.0.0.1", "::1", "localhost") and not config.env("CLIPCUT_TRUST_PROXY")


@app.get("/api/storage")
def storage_get(request: Request):
    from . import storage
    _admin(request)
    return storage.info(_on_this_computer(request))


@app.post("/api/storage/open")
def storage_open(request: Request):
    from . import storage
    _admin(request)
    if not _on_this_computer(request):
        raise HTTPException(400, "The folder can only be opened on the computer Clip Cut AI runs on.")
    try:
        storage.open_folder()
    except OSError as e:
        raise HTTPException(500, "Couldn't open the folder: " + safe.friendly(e, 200))
    return {"ok": True}


@app.post("/api/storage/pick")
def storage_pick(request: Request):
    from . import storage
    _admin(request)
    if not _on_this_computer(request):
        raise HTTPException(400, "Type the folder's path instead: a folder window can only be shown on the computer Clip Cut AI runs on.")
    return {"path": storage.pick_folder()}


@app.put("/api/storage")
def storage_put(request: Request, body: dict = Body(...)):
    from . import storage
    _admin(request)
    try:
        if body.get("cancel"):
            storage.cancel_change()
            return storage.info(_on_this_computer(request))
        storage.change(str(body.get("path") or ""), bool(body.get("move", True)))
    except ValueError as e:
        raise HTTPException(400, str(e))
    return storage.info(_on_this_computer(request))


# ---------------------------------------------------------------- replies to comments (the Comments page)
@app.get("/api/replies")
def replies_list():
    from . import replies
    return replies.listing()


@app.put("/api/replies/settings")
def replies_settings(body: dict = Body(...)):
    from . import replies
    try:
        accounts.save_settings({k: body[k] for k in ("reply_mode", "reply_cap", "reply_tone", "reply_days", "dm_rules", "tg_control", "reply_all") if k in body})
    except (ValueError, TypeError) as e:
        raise HTTPException(400, str(e))
    return replies.listing()


@app.post("/api/replies/check")
def replies_check():
    from . import replies
    _throttle("replycheck:" + ctx.uid(), 10, 600)
    replies.check_in_background()
    return {"started": True}


@app.post("/api/replies/{item_id}/{action}")
def replies_action(item_id: str, action: str, body: dict = Body(default={})):
    from . import replies
    _throttle("reply:" + ctx.uid(), 120, 600)
    try:
        if action == "send":
            text = body.get("text")
            replies.send(item_id, None if text is None else str(text))
        elif action == "skip":
            replies.skip(item_id)
        else:
            raise HTTPException(404)
    except ValueError as e:
        raise HTTPException(400, str(e))
    return replies.listing()


# ---------------------------------------------------------------- backups (Settings, Storage)
@app.get("/api/backups")
def backups_list(request: Request):
    from . import backup
    _admin(request)
    return {"backups": backup.listing(), "folder": str(backup.folder())}


@app.post("/api/backups")
def backups_make(request: Request):
    from . import backup
    _admin(request)
    _throttle("backup:" + ctx.uid(), 6, 600)
    try:
        f = backup.make(label="by-hand")
    except OSError as e:
        raise HTTPException(500, "Couldn't make the backup: " + safe.friendly(e, 200))
    return {"name": f.name, "backups": backup.listing()}


@app.get("/api/backups/{name}")
def backups_download(request: Request, name: str):
    from . import backup
    _admin(request)
    f = backup.path_of(name)
    if not f:
        raise HTTPException(404)
    return FileResponse(f, media_type="application/zip", filename=f.name, headers={"Cache-Control": "no-store"})


@app.get("/api/apps")
def apps_get(request: Request):
    _admin(request)
    return accounts.apps_public()


@app.put("/api/apps")
def apps_put(request: Request, body: dict = Body(...)):
    _admin(request)
    try:
        return accounts.save_app(str(body.get("platform", "")), body.get("client_id"), body.get("client_secret"),
                                 body.get("config_id"))
    except ValueError as e:
        raise HTTPException(400, str(e))


# ---------------------------------------------------------------- YouTube cookies, for servers YouTube refuses
# A secret like a password: it is saved to a file only this server reads, and never sent back to the page.
@app.get("/api/youtube-cookies")
def yt_cookies_get(request: Request):
    _admin(request)
    f = config.YT_COOKIES
    return {"saved": f.is_file(), "updated": int(f.stat().st_mtime) if f.is_file() else 0}


@app.put("/api/youtube-cookies")
def yt_cookies_put(request: Request, body: dict = Body(...)):
    _admin(request)
    f, text = config.YT_COOKIES, str(body.get("text") or "")
    if body.get("remove"):
        f.unlink(missing_ok=True)
    else:
        rows = [l.split("\t") for l in text.splitlines() if l.strip() and not l.startswith("# ")]
        if len(text) > 1_000_000 or not any(len(r) == 7 and "youtube.com" in r[0] for r in rows):
            raise HTTPException(400, "That doesn't look like a cookies.txt file with YouTube cookies in it. Export it "
                                     "from a browser signed in to YouTube, with an extension such as \"Get cookies.txt LOCALLY\".")
        text = text if text.startswith("# Netscape") else "# Netscape HTTP Cookie File\n" + text
        f.write_text(text, encoding="utf-8")
        with contextlib.suppress(OSError):
            f.chmod(0o600)
    media._yt_refused_until = 0.0        # try YouTube again straight away
    return yt_cookies_get(request)


@app.post("/api/posts")
def add_posts(body: dict = Body(...)):
    job = jobs.get(str(body.get("job")))
    clip = next((c for c in job["clips"] if c["id"] == body.get("clip")), None) if job else None
    if not clip or clip.get("status") != "done":
        raise HTTPException(404, "That clip is not ready")
    at = body.get("at")
    try:
        at = None if at in (None, "") else float(at)
        made = posting.enqueue(job, clip, [str(a) for a in body.get("accounts", [])][:20], now=bool(body.get("now")) and at is None, at=at)
    except (ValueError, TypeError) as e:
        raise HTTPException(400, str(e) if isinstance(e, ValueError) and "time" in str(e) else "Pick a valid date and time.")
    if not made:
        raise HTTPException(400, "Nothing was queued. Pick at least one account this clip has not already gone to.")
    return {"queued": len(made)}


@app.post("/api/posts/{pid}/reschedule")
def post_reschedule(pid: str, body: dict = Body(...)):
    try:
        posting.reschedule(pid, float(body.get("at")))
    except (TypeError, ValueError) as e:
        raise HTTPException(400, str(e) if isinstance(e, ValueError) and ("time" in str(e) or "posts" in str(e)) else "Pick a valid date and time.")
    return {"ok": True}


@app.get("/api/calendar")
def post_calendar(start: float, end: float):
    """Posts between two moments (seconds since 1970), at most about six weeks at a time."""
    if end <= start or end - start > 45 * 86400:
        raise HTTPException(400, "Ask for at most six weeks at a time.")
    return {"posts": posting.calendar(start, end)}


@app.post("/api/posts/{pid}/{action}")
def post_action(pid: str, action: str):
    try:
        {"cancel": posting.cancel, "retry": posting.retry}[action](pid)
    except KeyError:
        raise HTTPException(404)
    except ValueError as e:
        raise HTTPException(400, str(e))
    return {"ok": True}


@app.post("/api/alerts/find-chat")
def find_telegram_chat(body: dict = Body(default={})):
    """The chat id of whoever last wrote to the bot: so nobody has to look it up by hand. The token typed in the
    page is used if there is one, else the saved one; it is never sent back."""
    import httpx as _hx
    _throttle("findchat:" + ctx.uid(), 10, 600)
    token = str(body.get("token") or "").strip() or accounts.settings()["telegram_token"]
    if not re.fullmatch(r"\d{5,15}:[\w\-]{20,60}", token or ""):
        raise HTTPException(400, "Paste the bot token from @BotFather first.")
    try:
        r = _hx.get(f"https://api.telegram.org/bot{token}/getUpdates", params={"limit": 20}, timeout=15)
        ups = r.json().get("result", []) if r.status_code == 200 else None
    except Exception:  # noqa: BLE001 - never echo the token
        ups = None
    if ups is None:
        raise HTTPException(400, "Telegram didn't accept that bot token. Copy it again from @BotFather.")
    chats = [((u.get("message") or {}).get("chat") or {}) for u in ups if u.get("message")]
    if not chats:
        raise HTTPException(400, "Open your bot in Telegram, send it any message (like hi), then press this again.")
    ch = chats[-1]
    return {"chat": str(ch.get("id")), "name": ch.get("first_name") or ch.get("title") or ""}


@app.post("/api/alerts/test")
def test_alert():
    if not alerts.configured():
        raise HTTPException(400, "Save a Discord webhook or Telegram details first.")
    auth_problem = None
    try:
        auth.throttle("alert:" + ctx.uid(), 10, 600)
    except auth.AuthError as e:
        auth_problem = str(e)
    if auth_problem:
        raise HTTPException(429, auth_problem)
    problems = alerts.send("Clip Cut AI: test message. Alerts are working.")
    if problems:
        raise HTTPException(400, "; ".join(problems))
    return {"ok": True}


# ================================================================ admin (only accounts marked as admin in the database)
# The gate above already answers "not found" to everyone else; each route checks again so neither can be forgotten.
def _uid_ok(uid: str) -> str:
    if not re.fullmatch(r"[A-Za-z0-9_]{6,40}", uid):
        raise HTTPException(404)
    return uid


@app.get("/api/admin/overview")
def admin_overview(request: Request):
    _admin(request)
    return admins.overview()


@app.get("/api/admin/users/{uid}")
def admin_user(request: Request, uid: str):
    _admin(request)
    try:
        return admins.user_detail(_uid_ok(uid))
    except admins.Refused as e:
        raise HTTPException(e.status, str(e))


@app.post("/api/admin/users/{uid}/disabled")
def admin_disable(request: Request, uid: str, body: dict = Body(...)):
    me_ = _admin(request)
    try:
        return admins.set_disabled(me_, _uid_ok(uid), body.get("disabled"))
    except admins.Refused as e:
        raise HTTPException(e.status, str(e))


@app.post("/api/admin/users/{uid}/delete")
def admin_delete_user(request: Request, uid: str, body: dict = Body(...)):
    me_ = _admin(request)
    target = auth.get_user(_uid_ok(uid))
    if not target:
        raise HTTPException(404, "No such account")
    if target.id == me_.id:
        raise HTTPException(400, "You can't delete your own account from here.")
    if str(body.get("confirm") or "").strip().lower() != target.email.lower():
        raise HTTPException(400, "Type the account's email address exactly to confirm.")
    try:
        account.delete_account(target.id)
    except account.Busy as e:
        raise HTTPException(409, str(e))
    with db.engine.begin() as c:
        admins._log(c, me_.id, "delete", target.id, "account deleted")
    return {"ok": True}


def _startup_sweep():
    """Right after the app opens: check everything once (pages and daily limits, new uploads, comments, autopilot,
    the Manager), instead of waiting for each one's first timer."""
    time.sleep(12)
    from . import autofetch, autopilot, limits, manager, replies
    for uid in auth.user_ids():
        try:
            with ctx.as_user(uid):
                for part in (limits.check_all, lambda: autofetch._user(uid), replies.check, autopilot.round_for_user,
                             getattr(manager, "round_once", lambda: None)):
                    try:
                        part()
                    except Exception:  # noqa: BLE001 - one part failing never stops the rest
                        pass
        except Exception:  # noqa: BLE001
            pass


def _open_browser():
    """Started from START-WINDOWS.bat or ClipCutAI.exe: open the app, at its online address when it has one."""
    import webbrowser
    from . import tunnel
    for _ in range(30):                           # wait (up to ~30 s) for the online address
        if tunnel._state["url"] or not tunnel.saved().get("enabled"):
            break
        time.sleep(1)
    webbrowser.open((tunnel._state["url"] or f"http://127.0.0.1:{config.PORT}") + "/app")


RESTART_CODE = 42          # START-WINDOWS.bat starts the app again on this code (uvicorn itself uses 3 for "couldn't start")


def _port_busy() -> bool:
    import socket
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        s.bind((config.HOST if config.HOST not in ("", "0.0.0.0") else "127.0.0.1", config.PORT))
        return False
    except OSError:
        return True
    finally:
        s.close()


def _already_running():
    print(f"\n  Clip Cut AI pehle se chal raha hai (port {config.PORT} busy hai).\n"
          "  Purani Clip Cut AI window dhoondh ke band karo, ya Task Manager mein 'Python' band karo,\n"
          "  phir ClipCutAI.exe dobara kholo.\n", flush=True)
    if config.env("CLIPCUT_OPEN_BROWSER") == "1":
        import webbrowser
        webbrowser.open(f"http://127.0.0.1:{config.PORT}/app")
    raise SystemExit(2)


def main():
    if config.env("CLIPCUT_RESTARTED") == "1":      # just restarted: give the old copy a few seconds to let go of the port
        for _ in range(20):
            if not _port_busy():
                break
            time.sleep(0.5)
    try:
        _serve()
    except SystemExit as e:                          # uvicorn ends with 1 or 3 when it couldn't take the port
        if e.code in (1, 3) and _port_busy():
            _already_running()
        raise


def _serve():
    print(f"\n  Clip Cut AI is running:  {config.PUBLIC_URL}\n")
    if config.env("CLIPCUT_OPEN_BROWSER") == "1":
        threading.Thread(target=lambda: (time.sleep(3), _open_browser()), daemon=True).start()
    if not config.ACCOUNTS and (config.HTTPS or config.HOST not in ("127.0.0.1", "localhost", "::1")):
        print("  Sign-in is off, so anyone who can reach this address can use Clip Cut AI and its AI key.\n"
              "  On a server other people can reach, set CLIPCUT_ACCOUNTS=1 in .env.\n", flush=True)
    if config.env("CLIPCUT_AUTO_RELOAD") == "1":
        # restart by itself whenever the server code changes (pages in web/ never need a restart)
        uvicorn.run("studio.server:app", host=config.HOST, port=config.PORT, log_level="warning", backlog=4096, reload=True,
                    reload_dirs=[str(config.ROOT / "studio")], reload_includes=["*.py"],
                    proxy_headers=_trust_proxy(), forwarded_allow_ips=list(_PROXY_CIDRS))
        return
    uvicorn.run(app, host=config.HOST, port=config.PORT, log_level="warning", backlog=4096,
                proxy_headers=_trust_proxy(), forwarded_allow_ips=list(_PROXY_CIDRS))


if __name__ == "__main__":
    main()
