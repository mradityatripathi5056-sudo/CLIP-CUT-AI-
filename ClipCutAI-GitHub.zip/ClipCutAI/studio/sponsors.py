"""Brand deals: who pays, how much, what you promised (clips, mentions), when it is due and whether it is paid."""
import time
import uuid

from . import accounts

STATUSES = ("talking", "agreed", "posted", "paid")


def listing() -> dict:
    rows = accounts._read("sponsors.json", [])
    rows.sort(key=lambda r: (r["status"] == "paid", r.get("due") or "9999"))
    by = {s: 0.0 for s in STATUSES}
    for r in rows:
        by[r["status"]] += float(r.get("amount") or 0)
    return {"deals": rows, "totals": by, "due_soon": [r for r in rows if r["status"] in ("agreed", "posted") and r.get("due")
                                                     and r["due"] <= time.strftime("%Y-%m-%d", time.localtime(time.time() + 7 * 86400))]}


def _clean(d: dict) -> dict:
    brand = str(d.get("brand", "")).strip()[:60]
    if not brand:
        raise ValueError("Write the brand's name.")
    try:
        amount = round(max(0.0, float(d.get("amount") or 0)), 2)
    except (TypeError, ValueError):
        raise ValueError("The amount is a number, like 5000.")
    due = str(d.get("due") or "")[:10]
    if due and not (len(due) == 10 and due[4] == "-" and due[7] == "-"):
        raise ValueError("Pick the due date from the calendar.")
    st = d.get("status") if d.get("status") in STATUSES else "talking"
    return {"brand": brand, "amount": amount, "currency": str(d.get("currency") or "INR")[:3].upper(), "due": due,
            "status": st, "deliver": str(d.get("deliver", ""))[:200], "contact": str(d.get("contact", ""))[:120],
            "notes": str(d.get("notes", ""))[:500]}


def save(d: dict, sid: str = "") -> dict:
    rows = accounts._read("sponsors.json", [])
    row = _clean(d)
    if sid:
        old = next((r for r in rows if r["id"] == sid), None)
        if not old:
            raise KeyError(sid)
        old.update(row)
        row = old
    else:
        row.update(id=uuid.uuid4().hex[:10], added=time.time())
        rows.append(row)
    accounts._write("sponsors.json", rows)
    return row


def remove(sid: str):
    accounts._write("sponsors.json", [r for r in accounts._read("sponsors.json", []) if r["id"] != sid])
