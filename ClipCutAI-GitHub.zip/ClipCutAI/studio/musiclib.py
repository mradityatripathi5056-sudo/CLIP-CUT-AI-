"""Your own background music: upload royalty-free tracks (YouTube Audio Library, Pixabay Music, or music you own)
into three moods. A clip gets a track of the mood that fits it, mixed quietly under the game sound, and it never
contains music you didn't add yourself. Also the reaction sticker: a picture (your face reacting, a meme
sticker) that pops up on the clip's biggest moment."""
import random
import re
import subprocess
from pathlib import Path

import numpy as np

from . import config, ctx

MOODS = ("hype", "funny", "chill")
CATEGORY_MOOD = {"fail": "funny", "funny": "funny", "rage": "hype", "clutch": "hype", "shock": "hype", "take": "chill",
                 "story": "chill", "other": "hype"}
EXT = (".mp3", ".m4a", ".wav", ".ogg", ".aac")


def folder(uid=None) -> Path:
    d = config.user_dir(uid or ctx.uid()) / "music"
    for m in MOODS:
        (d / m).mkdir(parents=True, exist_ok=True)
    return d


def listing() -> dict:
    d = folder()
    return {m: sorted(f.name for f in (d / m).iterdir() if f.suffix.lower() in EXT) for m in MOODS}


def safe_name(name: str) -> str:
    stem, ext = Path(name or "track").stem, Path(name or "").suffix.lower()
    if ext not in EXT:
        raise ValueError("Use an MP3, M4A, WAV, OGG or AAC file.")
    return (re.sub(r"[^\w\-. ]+", "", stem).strip()[:60] or "track") + ext


def add(mood: str, name: str, data: bytes) -> str:
    if mood not in MOODS:
        raise ValueError("Pick hype, funny or chill.")
    if len(data) > 25_000_000:
        raise ValueError("Use a track smaller than 25 MB.")
    n = safe_name(name)
    (folder() / mood / n).write_bytes(data)
    ctx.bump()
    return n


def remove(mood: str, name: str):
    if mood not in MOODS:
        raise ValueError("Pick hype, funny or chill.")
    (folder() / mood / safe_name(name)).unlink(missing_ok=True)
    ctx.bump()


def pick(music_dir: str, category: str):
    """A random track for this kind of moment (any mood when that one is empty)."""
    d = Path(music_dir)
    mood = CATEGORY_MOOD.get(category or "other", "hype")
    for m in (mood, *[x for x in MOODS if x != mood]):
        files = [f for f in (d / m).glob("*") if f.suffix.lower() in EXT] if (d / m).is_dir() else []
        if files:
            return random.choice(files)
    return None


def bed(track: Path, dur: float, sr: int) -> np.ndarray:
    """The track decoded to mono at sr, looped to the clip length, quiet (-20 dB) with a fade in and out."""
    raw = subprocess.run(["ffmpeg", "-v", "error", "-i", str(track), "-t", f"{dur + 1:.2f}", "-ac", "1", "-ar", str(sr),
                          "-f", "s16le", "-"], capture_output=True, timeout=120).stdout
    x = np.frombuffer(raw, dtype="<i2").astype(np.float32) / 32768.0
    n = int(sr * (dur + 0.5))
    if not len(x):
        return np.zeros(0, dtype=np.float32)
    x = np.tile(x, int(np.ceil(n / len(x))))[:n]
    peak = float(np.max(np.abs(x))) or 1.0
    x = x / peak * 0.1                                    # about -20 dB under full scale: the game stays on top
    f = min(len(x) // 4, int(sr * 1.2))
    if f:
        x[:f] *= np.linspace(0, 1, f)
        x[-f:] *= np.linspace(1, 0, f)
    return x
