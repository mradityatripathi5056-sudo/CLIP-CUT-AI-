"""Sending email without editing .env: an admin saves the SMTP details in Settings, Login (Gmail with an app
password works: smtp.gmail.com, port 587). Used for email codes (checking an email address, two-step sign-in),
account emails, and backups sent by email. Values in .env still win; the password is kept in smtp.json (only
readable by this user on the machine) and is never sent back to the page."""
import json
import os
import random
import re
import secrets
import threading
import time

from . import config

_lock = threading.Lock()
_codes: dict = {}          # ticket -> {code_hash, exp, tries, data}
GMAIL = {"host": "smtp.gmail.com", "port": 587}


def _file():
    return config.DATA_DIR / "smtp.json"


def saved() -> dict:
    try:
        return json.loads(_file().read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def apply():
    """Use the saved details where .env has none."""
    s = saved()
    if not s or config.env("CLIPCUT_SMTP_HOST"):
        return
    config.SMTP_HOST = s.get("host", "")
    config.SMTP_PORT = int(s.get("port") or 587)
    config.SMTP_USER = s.get("user", "")
    config.MAIL_FROM = s.get("from") or s.get("user", "")
    pw = s.get("password", "")
    config.smtp_password = lambda: pw


def public() -> dict:
    s = saved()
    from . import mailer
    return {"ready": mailer.ready(), "from_env": bool(config.env("CLIPCUT_SMTP_HOST")), "host": s.get("host", ""),
            "port": s.get("port", 587), "user": s.get("user", ""), "has_password": bool(s.get("password"))}


def save(host: str, port, user: str, password: str, sender: str = "") -> dict:
    host = (host or "").strip() or GMAIL["host"]
    user = (user or "").strip()
    if not re.fullmatch(r"[\w.\-]{3,120}", host):
        raise ValueError("That mail server name doesn't look right. For Gmail it is smtp.gmail.com.")
    if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", user):
        raise ValueError("Enter the email address that sends the mail.")
    try:
        port = int(port or 587)
    except (TypeError, ValueError):
        raise ValueError("The port is a number, usually 587.")
    old = saved()
    password = re.sub(r"\s+", "", password or "") or (old.get("password", "") if old.get("user") == user else "")
    if len(password) < 8:
        raise ValueError("Paste the app password (for Gmail: Google Account, Security, App passwords).")
    data = {"host": host, "port": port, "user": user, "password": password, "from": (sender or user).strip()}
    with _lock:
        f = _file()
        tmp = f.with_suffix(".tmp")
        tmp.write_text(json.dumps(data), encoding="utf-8")
        try:
            os.chmod(tmp, 0o600)
        except OSError:
            pass
        tmp.replace(f)
    apply()
    return public()


def send_file(to: str, subject: str, text: str, path) -> bool:
    """A plain email with one file attached (the weekly backup)."""
    import smtplib
    import ssl
    from email.message import EmailMessage
    from pathlib import Path
    from . import mailer
    if not mailer.ready():
        return False
    p = Path(path)
    msg = EmailMessage()
    msg["From"], msg["To"], msg["Subject"] = config.MAIL_FROM, to, subject
    msg.set_content(text)
    msg.add_attachment(p.read_bytes(), maintype="application", subtype="zip", filename=p.name)
    try:
        if config.SMTP_PORT == 465:
            with smtplib.SMTP_SSL(config.SMTP_HOST, 465, context=ssl.create_default_context(), timeout=60) as s:
                if config.SMTP_USER:
                    s.login(config.SMTP_USER, config.smtp_password())
                s.send_message(msg)
        else:
            with smtplib.SMTP(config.SMTP_HOST, config.SMTP_PORT, timeout=60) as s:
                s.starttls(context=ssl.create_default_context())
                if config.SMTP_USER:
                    s.login(config.SMTP_USER, config.smtp_password())
                s.send_message(msg)
        return True
    except Exception:  # noqa: BLE001
        return False


# ------------------------------------------------------------------ one-time email codes
def _h(code: str) -> str:
    import hashlib
    return hashlib.sha256(code.encode()).hexdigest()


def send_code(email: str, purpose: str, data: dict) -> str:
    """Email a 6-digit code; returns a ticket that, with the code, proves the person reads that inbox (10 minutes,
    5 tries)."""
    from . import mailer
    if not mailer.ready():
        raise RuntimeError("Email isn't set up yet: save the email details in Settings, Login first.")
    code = f"{random.SystemRandom().randint(0, 999999):06d}"
    ticket = secrets.token_urlsafe(24)
    with _lock:
        now = time.time()
        for k in [k for k, v in _codes.items() if v["exp"] < now]:
            _codes.pop(k, None)
        _codes[ticket] = {"code": _h(code), "exp": now + 600, "tries": 0, "data": data, "purpose": purpose, "email": email}
    ok = mailer.send(email, f"Your Clip Cut AI code: {code}", f"Your code is {code}",
                     f"Use this code to {purpose}. It works for 10 minutes. If this wasn't you, ignore this email "
                     "and nobody can use it.", "Open Clip Cut AI", config.PUBLIC_URL or "http://127.0.0.1:8765",
                     "Never share this code with anyone.")
    if not ok:
        with _lock:
            _codes.pop(ticket, None)
        raise RuntimeError("The email couldn't be sent. Check the email details in Settings, Login.")
    return ticket


def check_code(ticket: str, code: str, purpose: str) -> dict:
    """The data saved with the ticket, if the code is right. Each ticket works once."""
    code = re.sub(r"\D", "", str(code or ""))
    with _lock:
        t = _codes.get(str(ticket or ""))
        if not t or t["exp"] < time.time() or t["purpose"] != purpose:
            _codes.pop(str(ticket or ""), None)
            raise ValueError("That code has run out. Ask for a new one.")
        t["tries"] += 1
        if t["tries"] > 5:
            _codes.pop(ticket, None)
            raise ValueError("Too many wrong tries. Ask for a new code.")
        if not secrets.compare_digest(t["code"], _h(code)):
            raise ValueError("That code isn't right. Check the email and try again.")
        _codes.pop(ticket, None)
        return t["data"]


def mask(email: str) -> str:
    name, _, dom = (email or "").partition("@")
    return (name[:2] + "•" * max(1, len(name) - 2)) + "@" + dom
