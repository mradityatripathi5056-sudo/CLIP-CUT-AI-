"""What is popular right now for a game, from YouTube's own search (no key needed):

- trending(game): the most-watched recent videos for that game, to clip while they are hot. Clip only what you
  have the right to clip; many creators allow it, some don't.
- tags_for(game): the hashtags those videos use most, so a creator's posts can carry the ones people search today.
Answers are kept for an hour (videos) and a day (hashtags), so YouTube is asked rarely."""
import re
import threading
import time
from collections import Counter

from . import media

_cache: dict = {}
_lock = threading.Lock()
VIDEO_TTL, TAG_TTL = 3600, 86400
GENERIC = {"shorts", "short", "youtubeshorts", "ytshorts", "viral", "trending", "fyp", "foryou", "foryoupage", "subscribe",
           "video", "videos", "new", "live", "stream", "reels", "reel", "explore", "explorepage"}


def _search(query: str, n: int) -> list:
    import yt_dlp
    opts = {"quiet": True, "no_warnings": True, "logger": media._Quiet(), "extract_flat": "in_playlist",
            "socket_timeout": 20, **media.cookie_opts()}
    with yt_dlp.YoutubeDL(opts) as ydl:
        i = ydl.extract_info(f"ytsearchdate{n}:{query}", download=False)
    out = []
    for e in (i or {}).get("entries") or []:
        if not isinstance(e, dict) or not e.get("id"):
            continue
        thumbs = e.get("thumbnails") or []
        out.append({"id": e["id"], "title": e.get("title") or "", "url": f"https://www.youtube.com/watch?v={e['id']}",
                    "channel": e.get("channel") or e.get("uploader") or "",
                    "formula": _formula(e.get("title") or ""),
                    "channel_url": e.get("channel_url") or (f"https://www.youtube.com/channel/{e['channel_id']}" if e.get("channel_id") else ""),
                    "views": int(e.get("view_count") or 0),
                    "duration": float(e.get("duration") or 0), "thumb": (thumbs[-1].get("url") if thumbs else "") or ""})
    return out


def _cached(key, ttl, fn):
    with _lock:
        got = _cache.get(key)
        if got and time.time() - got[0] < ttl:
            return got[1]
    val = fn()
    with _lock:
        _cache[key] = (time.time(), val)
    return val


def clean_game(game: str) -> str:
    return re.sub(r"\s+", " ", re.sub(r"[^\w\s\-]", " ", str(game or ""))).strip()[:40]


def _formula(title: str) -> str:
    from . import ytstrategy
    return ytstrategy.classify(title)


def trending(game: str, n: int = 25) -> list:
    """The most-watched of the newest videos for the game, most views first."""
    g = clean_game(game)
    if not g:
        raise ValueError("Type a game, like Valorant or BGMI.")
    vids = _cached(("v", g.lower()), VIDEO_TTL, lambda: _search(f"{g} gameplay highlights", n))
    return sorted(vids, key=lambda v: -v["views"])


def tags_from(titles: list, game: str = "", n: int = 10) -> list:
    """The hashtags used most across these titles, without the generic ones."""
    count = Counter()
    for t in titles:
        for k in dict.fromkeys(tag.lower() for tag in re.findall(r"#(\w{2,30})", t or "")):   # in order, once per title
            if k not in GENERIC:
                count[k] += 1
    g = re.sub(r"\W", "", game.lower())
    tags = [t for t, _ in count.most_common(n + 1)]
    if g and g not in tags:
        tags.insert(0, g)
    return tags[:n]


def tags_for(game: str, n: int = 10) -> list:
    g = clean_game(game)
    if not g:
        return []
    def find():
        try:
            vids = _search(f"{g} #shorts", 30)
        except Exception:  # noqa: BLE001
            return []
        return tags_from([v["title"] for v in vids], g, n)
    return _cached(("t", g.lower()), TAG_TTL, find)
