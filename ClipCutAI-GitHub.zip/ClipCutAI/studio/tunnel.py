"""Clip Cut AI online with ngrok: a public https address for the app running on this computer, so Facebook,
Instagram, Threads and Google can send people back to it, links can be clicked from anywhere, and you can open it
from your phone. Uses ngrok's official library (pip "ngrok"); needs a free ngrok account: its authtoken and the free
static domain from dashboard.ngrok.com (Domains), so the address never changes.

Safety first: going online switches sign-in on (CLIPCUT_ACCOUNTS=1) and closes sign-up (CLIPCUT_SIGNUP=0: only
people you add in Settings, Team can make an account), so only you can get in. The settings are written to .env;
the app then restarts once."""
import json
import os
import re
import threading
import time

from . import config

_state = {"url": "", "error": "", "since": 0, "listener": None}
WINDOWS = os.name == "nt"


def _file():
    return config.DATA_DIR / "ngrok.json"


def saved() -> dict:
    try:
        return json.loads(_file().read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def public() -> dict:
    s = saved()
    return {"enabled": bool(s.get("enabled")), "domain": s.get("domain", ""), "has_token": bool(s.get("token")),
            "url": _state["url"], "error": _state["error"], "public_url": config.PUBLIC_URL,
            "accounts_on": config.ACCOUNTS, "windows": WINDOWS, "autostart": autostart_on()}


def _write_env(updates: dict):
    """Set (or remove, for None) these lines in .env, keeping everything else."""
    f = config.ROOT / ".env"
    lines = f.read_text(encoding="utf-8").splitlines() if f.is_file() else []
    keep = [ln for ln in lines if ln.split("=", 1)[0].strip() not in updates]
    keep += [f"{k}={v}" for k, v in updates.items() if v is not None]
    tmp = f.with_suffix(".tmp")
    tmp.write_text("\n".join(keep) + "\n", encoding="utf-8")
    tmp.replace(f)


def save(token: str, domain: str, enabled: bool) -> dict:
    from . import auth
    s = saved()
    token = (token or "").strip()
    if " " in token:                    # pasted the whole "ngrok config add-authtoken <token>" line: keep the token
        token = token.split()[-1]
    token = token or s.get("token", "")
    domain = re.sub(r"^https?://", "", (domain or "").strip().lower()).strip("/")
    if enabled:
        if not re.fullmatch(r"[A-Za-z0-9_]{20,}", token):
            raise ValueError("Paste your ngrok authtoken (dashboard.ngrok.com, Your Authtoken).")
        if domain and not re.fullmatch(r"[a-z0-9][a-z0-9\-.]{2,120}\.(ngrok-free\.app|ngrok-free\.dev|ngrok\.app|ngrok\.dev|ngrok\.io|[a-z]{2,})", domain):
            raise ValueError("That domain doesn't look right. Copy it from dashboard.ngrok.com, Domains, or leave it empty.")
        owner = auth.get_user(auth.owner_id())
        if not config.ACCOUNTS and not (owner and owner.email and auth.EMAIL_RE.match(owner.email or "")
                                        and owner.password_hash):
            raise ValueError("Save your login (email and password) in Settings, Login first: once Clip Cut AI is online, "
                             "everyone has to sign in, you too.")
    data = {"token": token, "domain": domain, "enabled": bool(enabled)}
    f = _file()
    tmp = f.with_suffix(".tmp")
    tmp.write_text(json.dumps(data), encoding="utf-8")
    try:
        os.chmod(tmp, 0o600)
    except OSError:
        pass
    tmp.replace(f)
    if enabled:                         # with no domain given, ngrok's own dev domain is found on the first start
        _write_env({"CLIPCUT_ACCOUNTS": "1", "CLIPCUT_SIGNUP": "0", "CLIPCUT_TRUST_PROXY": "1",
                    "CLIPCUT_PUBLIC_URL": f"https://{domain}" if domain else None})
    else:
        _write_env({"CLIPCUT_PUBLIC_URL": None})       # sign-in stays on: switching it off is a separate choice
    return public()


def start():
    """Open the tunnel (in the background) if it is switched on and this run already has its public address."""
    s = saved()
    if not s.get("enabled") or not s.get("token"):
        return
    if s.get("domain") and config.PUBLIC_URL != f"https://{s['domain']}":
        _state["error"] = "Restart Clip Cut AI to go online (the new address is read at start)."
        return

    def run():
        for attempt in range(6):
            try:
                import ngrok
                opts = {"authtoken": s["token"]}
                if s.get("domain"):
                    opts["domain"] = s["domain"]
                _state["listener"] = ngrok.forward(f"127.0.0.1:{config.PORT}", **opts)
                url = _state["listener"].url().rstrip("/")
                _adopt(url)
                _state.update(url=url, error="", since=time.time())
                print(f"\n  Online: {_state['url']}\n", flush=True)
                return
            except ImportError:
                _state["error"] = "The ngrok library isn't installed. Run: python -m pip install ngrok"
                return
            except Exception as e:  # noqa: BLE001 - no internet yet, or a wrong token: say why, try a few times
                _state["error"] = _why(str(e))
                time.sleep(min(60, 5 * (attempt + 1)))
    threading.Thread(target=run, daemon=True).start()


def _adopt(url: str):
    """ngrok picked the account's dev domain: use it as this app's address from now on (kept for next starts)."""
    from urllib.parse import urlparse
    host = urlparse(url).hostname or ""
    if not host or config.PUBLIC_URL == f"https://{host}":
        return
    s = saved()
    s["domain"] = host
    f = _file()
    tmp = f.with_suffix(".tmp")
    tmp.write_text(json.dumps(s), encoding="utf-8")
    try:
        os.chmod(tmp, 0o600)
    except OSError:
        pass
    tmp.replace(f)
    _write_env({"CLIPCUT_PUBLIC_URL": f"https://{host}"})
    config.PUBLIC_URL, config.HTTPS = f"https://{host}", True


def _why(e: str) -> str:
    t = e.lower()
    if "authtoken" in t or "authentication" in t or "err_ngrok_105" in t or "err_ngrok_107" in t:
        return "ngrok didn't accept the authtoken. Copy it again from dashboard.ngrok.com."
    if "domain" in t and ("not found" in t or "reserved" in t or "err_ngrok_319" in t or "err_ngrok_320" in t):
        return "That domain isn't on your ngrok account. Copy it from dashboard.ngrok.com, Domains."
    if "already online" in t or "err_ngrok_334" in t or "err_ngrok_108" in t:
        return "This domain is already in use by another ngrok (close the other Clip Cut AI or ngrok window)."
    return "ngrok couldn't connect: " + e[:160]


# ------------------------------------------------------------------ start with Windows
def _startup_file():
    appdata = os.environ.get("APPDATA")
    if not WINDOWS or not appdata:
        return None
    from pathlib import Path
    return Path(appdata) / "Microsoft" / "Windows" / "Start Menu" / "Programs" / "Startup" / "ClipCutAI.bat"


def autostart_on() -> bool:
    f = _startup_file()
    return bool(f and f.is_file())


def set_autostart(on: bool) -> bool:
    f = _startup_file()
    if not f:
        raise ValueError("Starting with Windows works only on Windows.")
    if on:
        f.parent.mkdir(parents=True, exist_ok=True)
        target = config.ROOT / ("ClipCutAI.exe" if (config.ROOT / "ClipCutAI.exe").is_file() else "START-WINDOWS.bat")
        f.write_text(f'@echo off\r\ncd /d "{config.ROOT}"\r\nstart "Clip Cut AI" /min "{target}"\r\n', encoding="utf-8")
    else:
        f.unlink(missing_ok=True)
    return autostart_on()
