"""Asking a streamer for permission to post clips of their streams. Most streamers say yes to clip pages that
credit them; having it in writing protects your page from copyright strikes and takedowns."""
from . import accounts

DEFAULT = {
    "india": ("Hi {name} bhai! 🙏 Main {page} page chalata hoon jahan gaming streams ke best moments ki short edits "
              "(Reels/Shorts) banta hoon. Kya main aapke streams ke clips edit karke post kar sakta hoon? Har clip mein "
              "aapka naam aur channel link credit mein rahega, aur aap jab bhi bolo main koi bhi clip hata dunga. "
              "Isse aapke channel pe bhi naye log aayenge. Permission doge to bahut acha lagega! 🎮"),
    "global": ("Hi {name}! I run {page}, a page that makes short edits (Reels/Shorts) of the best gaming stream moments. "
               "Would you be OK with me clipping and posting moments from your streams? Every clip credits you with "
               "your name and channel link, and I'll take down any clip whenever you ask. It should also send new "
               "viewers your way. Thanks a lot! 🎮"),
}


def message(creator: dict, page: str = "") -> str:
    own = accounts.settings().get("permission_template") or ""
    text = own or DEFAULT["global" if creator.get("audience") == "global" else "india"]
    if not page:
        names = [a["name"] for a in accounts.list_accounts() if a["platform"] in ("instagram", "youtube")]
        page = names[0] if names else "my clips"
    return text.replace("{name}", creator.get("name") or "there").replace("{page}", page)


def board() -> list:
    from . import creators
    return [{"id": c["id"], "name": c["name"], "permission": c.get("permission", "unknown"),
             "note": c.get("permission_note", ""), "only_with_permission": bool(c.get("only_with_permission")),
             "channel": c.get("channel", "")} for c in creators.all_creators()]
