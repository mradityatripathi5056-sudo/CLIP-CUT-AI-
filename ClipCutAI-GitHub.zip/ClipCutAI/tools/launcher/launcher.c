/* ClipCutAI.exe: double-click to start Clip Cut AI.
   - If it is already running (port 8765 answers), it just opens the app in the browser.
   - Otherwise it runs START-WINDOWS.bat (next to this exe) in a small, minimised window: that window IS the app,
     closing it stops Clip Cut AI. The bat installs what is missing, starts the server, goes online with ngrok when
     that is switched on, and opens the browser by itself.
   Build (from Linux or Windows): python -m ziglang cc -target x86_64-windows-gnu -O2 -mwindows launcher.c launcher.rc -lws2_32 -o ClipCutAI.exe */
#define WIN32_LEAN_AND_MEAN
#include <winsock2.h>
#include <windows.h>
#include <shellapi.h>
#include <stdio.h>
#include <string.h>

static int running(void) {
    WSADATA w;
    if (WSAStartup(MAKEWORD(2, 2), &w)) return 0;
    SOCKET s = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (s == INVALID_SOCKET) { WSACleanup(); return 0; }
    struct sockaddr_in a; memset(&a, 0, sizeof a);
    a.sin_family = AF_INET; a.sin_port = htons(8765); a.sin_addr.s_addr = htonl(0x7F000001);
    u_long nb = 1; ioctlsocket(s, FIONBIO, &nb);
    connect(s, (struct sockaddr *)&a, sizeof a);
    fd_set f; FD_ZERO(&f); FD_SET(s, &f);
    struct timeval t = {0, 400000};
    int ok = select(0, NULL, &f, NULL, &t) == 1;
    closesocket(s); WSACleanup();
    return ok;
}

/* CLIPCUT_PUBLIC_URL from .env (the ngrok address), else the local one */
static void app_url(char *out, size_t n) {
    snprintf(out, n, "http://127.0.0.1:8765/app");
    FILE *f = fopen(".env", "r");
    if (!f) return;
    char line[600];
    while (fgets(line, sizeof line, f)) {
        if (strncmp(line, "CLIPCUT_PUBLIC_URL=", 19) == 0) {
            char *v = line + 19; v[strcspn(v, "\r\n")] = 0;
            if (strncmp(v, "https://", 8) == 0 && strlen(v) < n - 6) snprintf(out, n, "%s/app", v);
        }
    }
    fclose(f);
}

int WINAPI WinMain(HINSTANCE h, HINSTANCE p, LPSTR cmd, int show) {
    char dir[MAX_PATH], url[700];
    DWORD len = GetModuleFileNameA(NULL, dir, MAX_PATH);
    if (!len || len >= MAX_PATH) return 1;
    char *slash = strrchr(dir, '\\'); if (slash) *slash = 0;
    SetCurrentDirectoryA(dir);
    if (running()) {
        app_url(url, sizeof url);
        ShellExecuteA(NULL, "open", url, NULL, NULL, SW_SHOWNORMAL);
        return 0;
    }
    if (GetFileAttributesA("START-WINDOWS.bat") == INVALID_FILE_ATTRIBUTES) {
        MessageBoxA(NULL, "START-WINDOWS.bat was not found next to ClipCutAI.exe.\nKeep ClipCutAI.exe inside the Clip Cut AI folder.",
                    "Clip Cut AI", MB_ICONERROR);
        return 1;
    }
    char line[MAX_PATH + 64];
    snprintf(line, sizeof line, "cmd.exe /c \"\"%s\\START-WINDOWS.bat\"\"", dir);
    STARTUPINFOA si; PROCESS_INFORMATION pi;
    memset(&si, 0, sizeof si); si.cb = sizeof si;
    si.dwFlags = STARTF_USESHOWWINDOW; si.wShowWindow = SW_SHOWMINNOACTIVE;
    if (!CreateProcessA(NULL, line, NULL, NULL, FALSE, CREATE_NEW_CONSOLE, NULL, dir, &si, &pi)) {
        MessageBoxA(NULL, "Couldn't start Clip Cut AI. Try START-WINDOWS.bat.", "Clip Cut AI", MB_ICONERROR);
        return 1;
    }
    CloseHandle(pi.hThread); CloseHandle(pi.hProcess);
    return 0;
}
