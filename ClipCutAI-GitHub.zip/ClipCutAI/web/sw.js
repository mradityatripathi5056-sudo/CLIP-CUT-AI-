/* Clip Cut AI on the phone's home screen. Pages always come from the server (so nothing is ever out of date);
   only when there is no connection at all does a small "you're offline" page show instead. Nothing from /api or
   /media is ever kept on the phone. */
const OFFLINE = `<!doctype html><meta name="viewport" content="width=device-width,initial-scale=1"><title>Clip Cut AI</title>
<body style="font-family:system-ui;background:#1E1612;color:#F4EEEA;display:grid;place-items:center;height:100vh;margin:0;text-align:center">
<div><h2>You're offline</h2><p>Clip Cut AI needs a connection to your computer or server.<br>Check the internet and try again.</p>
<button onclick="location.reload()" style="font:inherit;padding:10px 18px;border:0;border-radius:10px;background:#FF8B33;color:#2A1A12">Try again</button></div>`;
self.addEventListener("install", () => self.skipWaiting());
self.addEventListener("activate", e => e.waitUntil(self.clients.claim()));
self.addEventListener("push", e => {
  let d = {};
  try { d = e.data ? e.data.json() : {}; } catch (_) { d = {body: e.data ? e.data.text() : ""}; }
  e.waitUntil(self.registration.showNotification(d.title || "Clip Cut AI", {body: d.body || "", icon: "/brand/icon-192.png",
    badge: "/brand/icon-192.png", data: {url: d.url || "/"}}));
});
self.addEventListener("notificationclick", e => {
  e.notification.close();
  const url = (e.notification.data && e.notification.data.url) || "/";
  e.waitUntil(clients.matchAll({type: "window"}).then(ws => {
    for (const w of ws) if ("focus" in w) { w.navigate(url); return w.focus(); }
    return clients.openWindow(url);
  }));
});
self.addEventListener("fetch", e => {
  const r = e.request;
  if (r.method !== "GET" || r.mode !== "navigate") return;           // everything else goes straight to the network
  e.respondWith(fetch(r).catch(() => new Response(OFFLINE, {headers: {"Content-Type": "text/html; charset=utf-8"}})));
});
