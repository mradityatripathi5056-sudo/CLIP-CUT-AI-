"""The YouTube growth strategy (from Jake Schincariol's MIT YouTube agent skill): title linting, hook formulas,
viral outliers by own-channel median, the SEO package per clip used when posting, posting modes, comment piles and
the ONE-fix channel check. Nothing outside this machine is contacted."""
import os
import sys
import tempfile
import time

os.environ["CLIPCUT_DATA"] = tempfile.mkdtemp(prefix="pc-yts-")
os.environ.update(DATABASE_URL="", CLIPCUT_ACCOUNTS="")
sys.path.insert(0, ".")
from pathlib import Path  # noqa: E402

from studio import accounts, config, creators, ctx, db, jobs, posting, replies, ytstrategy  # noqa: E402

db.init()
fails = []


def check(name, ok, extra=""):
    print(("PASS " if ok else "FAIL ") + name + (f"  {extra}" if extra and not ok else ""))
    ok or fails.append(name)


# ---------------------------------------------------------------- title.py rules
r = ytstrategy.lint_title("Mortal ka 1v4 clutch in Erangel")
check("a short, specific title with a number passes", r["score"] == 100 and not r["issues"], r)
r = ytstrategy.lint_title("THIS IS SO INSANE AND CRAZY you won't believe what happened in this epic game today")
kinds = {k for k, _ in r["issues"]}
check("long, shouting, vague titles are flagged", {"length", "mobile", "shouting", "vague", "no-number"} <= kinds and r["score"] < 40, kinds)
check("the thumbnail mustn't repeat the title", any(k == "duplicate" for k, _ in ytstrategy.lint_title("Mortal 1v4 clutch", "1v4 CLUTCH")["issues"]))
check("21 hook formulas are loaded", len(ytstrategy.HOOKS) == 21)
check("a title's formula is named", ytstrategy.classify("97% of players miss this") == "The Statistic")

# ---------------------------------------------------------------- yt-viral outliers
vids = [{"channel": "A", "title": f"clip {i}", "views": 1000} for i in range(5)] + [{"channel": "A", "title": "Everyone says camp. It's wrong", "views": 9000}]
vids += [{"channel": "Big", "title": "x", "views": 900000}, {"channel": "Big", "title": "y", "views": 1000000}]
o = ytstrategy.outliers(vids)
check("videos are ranked by how far they beat their own channel", o["outliers"][0]["multiple"] == 9.0 and o["outliers"][0]["channel"] == "A")
check("channels with under 4 videos are skipped, not ranked on noise", ("Big", 2) in o["skipped_thin"])
check("the outlier's formula is named", o["formulas"][0][0] == "Contrarian Flip", o["formulas"])

# ---------------------------------------------------------------- SEO package per clip
UID = "owner_yts"
with ctx.as_user(UID):
    accounts._put({"id": "yt_1", "platform": "youtube", "name": "GameXtra", "added": time.time(), "token": "t"})
    c = creators.create({"name": "Mortal", "game": "BGMI", "accounts": ["yt_1"], "autopost": True})
    d = creators.root(c["id"]) / "videos" / "j1"
    (d / "clips").mkdir(parents=True)
    (d / "clips" / "k1.mp4").write_bytes(b"x")
    (d / "words.json").write_text('[{"w":"bhai","s":1,"e":1.2},{"w":"1v4","s":2,"e":2.3},{"w":"clutch","s":3,"e":3.3}]')
    clip = {"id": "k1", "file": "k1.mp4", "status": "done", "start": 0, "end": 20, "score": 90, "title": "INSANE clutch!!",
            "description": "Mortal wins a 1v4 in the final circle", "hashtags": ["bgmi", "mortal"]}
    job = {"id": "j1", "user": UID, "creator": c["id"], "dir": str(d), "clips": [clip], "status": "done", "kind": "video", "created": time.time()}
    jobs._jobs["j1"] = job
    jobs._by_user.setdefault(UID, {})["j1"] = job
    check("the clip's spoken words reach the SEO prompt", "1v4 clutch" in ytstrategy.spoken(job, clip))
    ytstrategy.working_formulas = lambda game="", read=None: ["The Question"]
    ai = {"queries": ["mortal 1v4 clutch", "bgmi final circle clutch", "mortal bgmi"],
          "titles": ["INSANE EPIC CRAZY clutch you won't believe!!!", "Mortal's 1v4 clutch in the BGMI final circle",
                     "Can Mortal win a 1v4?"],
          "first_lines": "Mortal clutches a 1v4 in the BGMI final circle. Watch the last 20 seconds.",
          "tags": ["BGMI", "Battlegrounds Mobile India", "Mortal", "MortaL", "bgmi"], "hashtags": ["#BGMI", "mortal", "Shorts", "clutch"]}
    seo = ytstrategy.seo_for(job, clip, c, ask=lambda: ai)
    check("the best title wins the lint and the query test", seo["title"] == "Mortal's 1v4 clutch in the BGMI final circle", seo["title"])
    check("the query test passes on the chosen title", seo["query_hit"] >= 2 / 3)
    check("tags are de-duplicated and kept to 15", seo["tags"] == ["BGMI", "Battlegrounds Mobile India", "Mortal"], seo["tags"])
    check("hashtags are cleaned (no #, no duplicate #Shorts)", seo["hashtags"] == ["BGMI", "mortal", "clutch"], seo["hashtags"])
    check("the package is kept with the clip (one AI call per clip)", ytstrategy.seo_for(job, clip, c, ask=lambda: 1 / 0)["title"] == seo["title"])

    # posting uses it
    config.ai_ready = lambda: True
    sent = {}

    def fake_upload(acc, path, title, description, tags, privacy, **kw):
        sent.update(title=title, description=description, tags=tags)
        return "vid1", "https://youtu.be/vid1"
    accounts.youtube_upload = fake_upload
    p = posting.enqueue(job, clip, ["yt_1"], now=True)[0]
    posting._post(p)
    check("the YouTube post gets the SEO title", sent.get("title") == seo["title"], sent.get("title"))
    check("...the two search lines first in the description", sent.get("description", "").startswith("Mortal clutches a 1v4"))
    check("...the SEO hashtags and the SEO tags", "#BGMI" in sent.get("description", "") and sent.get("tags") == seo["tags"])
    creators.update(c["id"], {"yt_seo": False})
    clip2 = dict(clip, id="k2", seo=None, start=100, end=120)
    job["clips"].append(clip2)
    p2 = posting.enqueue(job, clip2, ["yt_1"], now=True)[0]
    posting._post(p2)
    check("with the SEO switch off, the clip's own title goes out", sent.get("title") == "INSANE clutch!!")

    # ---------------------------------------------------------------- posting modes
    c = creators.update(c["id"], {"post_mode": "strategy", "post_times": "", "daily_cap": 3})
    check("strategy mode keeps times on the best hours, starting from the prime-time plan", c["auto_times"] and c["post_times"].count(":") == 3)
    c = creators.update(c["id"], {"post_mode": "fixed"})
    check("fixed mode stops moving the times", c["auto_times"] is False)
    c = creators.update(c["id"], {"post_mode": "instant", "post_min_score": 0, "yt_seo": False})
    posting._posts[:] = []
    clip3 = dict(clip, id="k3", seo=None, start=200, end=220)
    job["clips"].append(clip3)
    posting.on_clip_ready(job, clip3)
    q = [x for x in posting._mine() if x["clip"] == "k3"]
    check("instant mode queues the clip to go out now", q and q[0]["due_at"] <= time.time() + 5)

    # ---------------------------------------------------------------- comment piles
    replies.brain.ask_ai = lambda *a, **k: ([{"id": "c1", "reply": "Final circle mein, Erangel 🔥", "skip": False, "pile": "question", "pin": True},
                                             {"id": "c2", "reply": "lol", "skip": False, "pile": "bait", "pin": False}], "m", 0)
    got = replies.write([{"cid": "c1", "author": "a", "text": "kaunsa map tha?"}, {"cid": "c2", "author": "b", "text": "noob streamer"}], "t", "")
    check("bait gets no reply, even if the AI wrote one", got == {"c1": "Final circle mein, Erangel 🔥", "c2": ""})
    check("the question most people have is suggested to pin", replies._meta["c1"] == {"pile": "question", "pin": True})

    # ---------------------------------------------------------------- the ONE fix
    posting._posts[:] = []
    for i in range(8):
        posting._posts.append({"id": f"a{i}", "user": UID, "account": "yt_1", "status": "posted", "job": "j1", "clip": "k1",
                               "posted_at": time.time() - i * 86400 * (5 if i == 4 else 1), "due_at": 0, "views": 100,
                               "title": "INSANE crazy clutch moment you will never ever believe in your life bro"})
    a = ytstrategy.audit("yt_1")
    check("the channel check ends in ONE fix", a["enough"] and a["fix"]["title"] in ("Upload rhythm", "Titles too long", "Vague titles"), a["fix"])
    check("...and says what not to do yet", "tags barely matter" in a["not_yet"])

print(f"\n{len(fails)} failed" if fails else "\nAll passed")
sys.exit(1 if fails else 0)
