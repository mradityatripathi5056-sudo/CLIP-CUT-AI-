"""A shared workspace: the owner adds a teammate by email; the teammate signs in and works on the owner's creators,
clips and posts with their own login; the owner can remove them; deleting the teammate's account never touches
the owner's things."""
import os
import sys
import tempfile

os.environ["CLIPCUT_DATA"] = tempfile.mkdtemp(prefix="pc-team-")
os.environ.update(DATABASE_URL="", CLIPCUT_ACCOUNTS="1", CLIPCUT_PUBLIC_URL="https://clips.example.com", CLIPCUT_VERIFY_EMAIL="0")
sys.path.insert(0, ".")
from fastapi.testclient import TestClient  # noqa: E402

from studio import auth, creators, ctx, db, server  # noqa: E402

db.init()
fails = []


def check(name, ok, extra=""):
    print(("PASS " if ok else "FAIL ") + name + (f"  {extra}" if extra and not ok else ""))
    ok or fails.append(name)


BASE = "https://clips.example.com"
H = {"Origin": BASE}


def person(email):
    u, _ = auth._create(email, email.split("@")[0], password_hash="x")
    cl = TestClient(server.app, base_url=BASE, follow_redirects=False)
    cl.cookies.set(auth.COOKIE, auth.start_session(u.id))
    return u, cl


aditya, a = person("aditya@example.com")
r = a.post("/api/creators", json={"name": "Valorant Pro"}, headers=H)
cid = r.json()["id"]
check("the owner has a creator", r.status_code == 200)
r = a.post("/api/team", json={"email": "anshik@example.com"}, headers=H)
check("the owner adds a teammate who has no account yet", r.status_code == 200 and r.json()["people"] == [{"email": "anshik@example.com", "name": "", "joined": False, "role": "manager"}], r.text)
check("a wrong email is refused", a.post("/api/team", json={"email": "nope"}, headers=H).status_code == 400)
check("adding from another website is refused", a.post("/api/team", json={"email": "x@example.com"}, headers={"Origin": "https://evil.example"}).status_code == 403)

anshik, b = person("anshik@example.com")
check("the teammate signs up and sees the owner's creators", [c["id"] for c in b.get("/api/creators").json()] == [cid])
check("...and is shown whose workspace it is", b.get("/api/team").json()["member_of"]["email"] == "aditya@example.com")
r = b.put(f"/api/creators/{cid}", json={"post_times": "10:00"}, headers=H)
check("the teammate can change the shared creator", r.status_code == 200 and r.json()["post_times"] == "10:00")
check("the owner sees the change", next(c for c in a.get("/api/creators").json() if c["id"] == cid)["post_times"] == "10:00")
check("a teammate cannot add people", b.post("/api/team", json={"email": "z@example.com"}, headers=H).status_code == 400)
check("a teammate keeps their own login", b.get("/api/auth/me").json()["user"]["email"] == "anshik@example.com")
check("a teammate does not get the server's settings", b.get("/api/apps").status_code == 404)
check("the owner's list shows them joined", a.get("/api/team").json()["people"] == [{"email": "anshik@example.com", "name": "anshik", "joined": True, "role": "manager"}])

stranger, s = person("someone@example.com")
check("anyone else still sees only their own things", s.get("/api/creators").json() == [])

r = a.delete("/api/team/anshik@example.com", headers=H)
check("the owner can remove a teammate", r.status_code == 200 and r.json()["people"] == [])
check("...who then sees only their own workspace", b.get("/api/creators").json() == [])

a.post("/api/team", json={"email": "anshik@example.com"}, headers=H)
check("an existing account can be added straight away", [c["id"] for c in b.get("/api/creators").json()] == [cid])
r = b.post("/api/account/delete", json={"password": "x", "confirm": "anshik@example.com"}, headers=H)
with ctx.as_user(aditya.id):
    check("deleting the teammate's account leaves the owner's things alone", r.status_code == 200 and bool(creators.get(cid)), r.text)
check("the owner's list no longer has them", a.get("/api/team").json()["people"] == [])

print("ALL PASSED" if not fails else f"{len(fails)} failed")
import shutil  # noqa: E402
db.engine.dispose()
shutil.rmtree(os.environ["CLIPCUT_DATA"], ignore_errors=True)
sys.exit(1 if fails else 0)
